const fs = require("fs");
const chalk = require("chalk");

module.exports = {
TOKEN: "8530059653:AAGbdrmnedNbOc5PRUDgrM2AU6finnAeeV0", // Token dari @BotFather
OWNER_ID: "7959551372", // ID Telegram owner
urladmin: "https://t.me/AZRAA132",
urlch: "https://t.me/antiheroopart2", 
NOTIF_CHANNEL: -1002892583118, 
botName: "AutoOrder - SKULLHOSTING",
version: "1.0.0",
authorName: "@skullhosting",
  
//==============================================[ SETTING IMAGE ]=======//
ppthumb: "https://files.catbox.moe/34c2ec.jpg",       // Foto utama bot (/start)
ppdigitalocean: "https://files.catbox.moe/34c2ec.jpg",

//==============================================[ SETTING EMOJI ID ]=======//
menuEffects: [
        "5104841245755180586", // Fire 🔥
        "5107584321108051014", // Love ❤️  
        "5159385139981059251", // Trumpet 🎺
        "5046509860389126442"  // Thumbs up 👍
    ],
    
//==============================================[ PREMIUM EMOJI ID ]=======//
premiumEffects: [
   "5103512349875603456", // Premium Emoji 1
   "5109987654321009876", // Premium Emoji 2
   "5198877665544332211", // Premium Emoji 3  
],    
//==============================================[ SETTING IMAGE ]=======//
//==============================================[ SETTING IMAGE ]=======//
tokeninstall: "revan",
bash: "bash <(curl https://raw.githubusercontent.com/zerodevxc/revan/refs/heads/main/install.sh)",

 //==============================================[ SETTING DIGITALOCEAN ]=======//
ApiDO1: "",
ApiDO2: "",
ApiDO3: "",
ApiDO4: "-",
ApiDO5: "-",
ApiDO6: "-",
ApiDO7: "-",
ApiDO8: "-",
ApiDO9: "-",
ApiDO10: "-",

ApiDO11: "-",
ApiDO12: "-",
ApiDO13: "-",
ApiDO14: "-",
ApiDO15: "-",
ApiDO16: "-",
ApiDO17: "-",
ApiDO18: "-",
ApiDO19: "-",
ApiDO20: "-",

ApiDO21: "-",
ApiDO22: "-",
ApiDO23: "-",
ApiDO24: "-",
ApiDO25: "-",
ApiDO26: "-",
ApiDO27: "-",
ApiDO28: "-",
ApiDO29: "-",
ApiDO30: "-",

ApiDO31: "-",
ApiDO32: "-",
ApiDO33: "-",
ApiDO34: "-",
ApiDO35: "-",
ApiDO36: "-",
ApiDO37: "-",
ApiDO38: "-",
ApiDO39: "-",
ApiDO40: "-",

ApiDO41: "-",
ApiDO42: "-",
ApiDO43: "-",
ApiDO44: "-",
ApiDO45: "-",
ApiDO46: "-",
ApiDO47: "-",
ApiDO48: "-",
ApiDO49: "-",
ApiDO50: "-",

// assuiiuuuiiuuuu ///
  cloudflare: {
    token: "e-yuo9hueyou9tbKF5tnLv-ZUBvV5YRgAp_5eg6r",
    zoneId: "b4bc0df89f709f1a9e390a9b4e3bdb5a",
    domain: "wilzzoffc.biz.id" // contoh: wilzz.xy
}, 
//== Pakasir settings ===
pakasirProject: 'skull-hosting',
    pakasirApiKey: '7Fn6ugz0vDWynofsTGeRMd5VwZT12e3j',
    pakasirRedirect: 'https://t.me/BOTAUTOSKULL_BOT',
    pakasirMinDeposit: 1000,
    pakasirExpireMinutes: 60,
    pakasirGraceSec: 20,
//==============================================[ SETTING ATLANTIC ]=======//
FeeTransaksi: 200,
apiAtlantic: "ahh",
nomor_pencairan: "no lu",
type_ewallet: "dana",
atas_nama_ewallet: "wilz"
};

// 🔁 Auto reload jika file config.js diubah
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${__filename}`));
  delete require.cache[file];
  require(file);
});