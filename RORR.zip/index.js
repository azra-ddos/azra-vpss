process.on("unhandledRejection", (reason) => console.log("[ANTI CRASH] Unhandled Rejection:", reason));
process.on("uncaughtException", (err) => console.log("[ANTI CRASH] Uncaught Exception:", err));
process.on("uncaughtExceptionMonitor", (err) => console.log("[ANTI CRASH MONITOR]:", err));

const config = require("./config.js");
// ================================
// 🔧 LOAD 50 API DIGITALOCEAN
// ================================
global.apiDigitalOcean = {};

for (let i = 1; i <= 50; i++) {
    let key = `ApiDO${i}`;
    global.apiDigitalOcean[`akun${i}`] = config[key] || "-";
}

const TelegramBot = require("node-telegram-bot-api");
const moment = require('moment-timezone');
const { Client } = require('ssh2');
const { exec } = require('child_process');
const FormData = require('form-data');
const fetch = require('node-fetch');
const axios = require('axios');
const figlet = require("figlet");
const crypto = require("crypto");
const fs = require("fs");
const chalk = require("chalk");
const P = require("pino");
const path = require("path");
const { execSync } = require('child_process'); 
const { InlineKeyboardButton } = require('telegraf');
let subdomainSelectionContext = {}; // { userId: { host, ip, created, msgId } }
// ==========================================
const { domains } = require("./database/Subdomain.js");
const { cloudflareDomains } = require("./config.js");
const qs = require('qs');
const QRCode = require('qrcode');
const bot = new TelegramBot(config.TOKEN, { polling: true });
const owner = config.OWNER_ID.toString();
const urladmin = config.urladmin;
const channellog = config.idchannel;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const IDR = n => new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
}).format(n);

//##################################//
// Payment Gateway For Atlantic
const apiAtlantic = config.apiAtlantic;
const FeeTrx = config.FeeTransaksi;
const nopencairan = config.nomor_pencairan;
const typeewallet = config.type_ewallet;
const atasnamaewallet = config.atas_nama_ewallet;
console.log("✅ Bot NDY OFFC berjalan tanpa error!");

// Session tempat menyimpan proses pembelian VPS
if (!global.buyvpsSession) global.buyvpsSession = {};
// ====================================================
// 🧱 FILE DATABASE
// ====================================================
// ================== IMPORT MODULE ==================
const BackupManager = require("./database/backupManager.js");

// ================== KONFIGURASI INTERVAL BACKUP ==================
const INTERVAL_HOURS = 1; // Backup tiap 1 jam
const INTERVAL_MS = INTERVAL_HOURS * 60 * 60 * 1000; // dikonversi ke ms

// Pastikan folder ./library ada
const libraryPath = path.join(__dirname, "database");
if (!fs.existsSync(libraryPath)) fs.mkdirSync(libraryPath, { recursive: true });

// Simpan file lastBackup.json di dalam folder ./library/
const BACKUP_FILE = path.join(libraryPath, "lastBackup.json");

// ================== INISIASI BACKUP MANAGER ==================
const backupManager = new BackupManager(bot, owner, INTERVAL_MS, BACKUP_FILE);

// Jalankan auto-backup ketika bot dihidupkan
backupManager.startAutoBackup();

const { 
  getRuntime,
  getTotalUsers,
  getUserSaldo,
  setUserSaldo,
  toIDR,
  toRupiah,
  toIDRSimple,
  formatRupiah,
  generateRandomNumber,
  randomHex,
  generateRandomPassword,
  getWaktuIndonesia,
  dateTime
} = require("./database/Function");

const saldoPath = path.join(__dirname, "./database/saldo.json");

// ====================================================
// 🔧 UTIL
// ====================================================

function logError(err, where = "Unknown") {
  const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  const text = `[${time}] [${where}]\n${err.stack || err}\n\n`;
  console.error(text);
  fs.appendFileSync("error.log", text);
}

function escapeMarkdown(text) {
    return text
        .replace(/_/g, "\\_")
        .replace(/\*/g, "\\*")
        .replace(/`/g, "\\`")
        .replace(/\[/g, "\\[")
        .replace(/#/g, "\\#");
}

// Path file penyimpanan grup
const resellerDomainGroupPath = './database/resellerDomain.json';
let resellerdomainUsers = [];

// Pastikan folder & file ada
if (!fs.existsSync(path.dirname(resellerDomainGroupPath))) {
  fs.mkdirSync(path.dirname(resellerDomainGroupPath), { recursive: true });
}
if (!fs.existsSync(resellerDomainGroupPath)) {
  fs.writeFileSync(resellerDomainGroupPath, '[]');
}

// Baca data awal saat bot start
try {
  resellerdomainUsers = JSON.parse(fs.readFileSync(resellerDomainGroupPath, 'utf8'));
  if (!Array.isArray(resellerdomainUsers)) resellerdomainUsers = [];
} catch (err) {
  console.error('❌ Gagal baca resellerDomain.json:', err);
  resellerdomainUsers = [];
}

// Fungsi untuk simpan daftar grup
function saveResellerDomain() {
  try {
    fs.writeFileSync(resellerDomainGroupPath, JSON.stringify(resellerdomainUsers, null, 2));
  } catch (err) {
    console.error('❌ Gagal simpan resellerDomain.json:', err);
  }
}

//##################################//
// Logs Message In Console
bot.on("message", async (msg) => {
  if (!msg.text) return;
  if (!msg.text.startsWith("/")) return;

  const command = msg.text.split(" ")[0].toLowerCase();
  const userId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
  const chatType = msg.chat.type === "private"
    ? "Private"
    : `Public (${msg.chat.title || "Group Tanpa Nama"})`;

  // Format tanggal Indonesia
  const waktu = moment().tz("Asia/Jakarta");
  const tanggal = waktu.format("DD/MMMM/YYYY"); // contoh: 23/September/2025
  const hari = waktu.format("dddd"); // contoh: Senin

  console.log(
    chalk.blue.bold("Messages Detected 🟢") +
    chalk.white.bold("\n▢ Command : ") + chalk.green.bold(command) +
    chalk.white.bold("\n▢ Pengirim : ") + chalk.magenta.bold(userId) +
    chalk.white.bold("\n▢ Name : ") + chalk.red.bold(username) +
    chalk.white.bold("\n▢ Chat Type : ") + chalk.yellow.bold(chatType) +
    chalk.white.bold("\n▢ Tanggal : ") + chalk.cyan.bold(`${hari}, ${tanggal}\n`)
  );
});

// ==================== ⚡ SYSTEM LOG : AUTO SAVE ID (CYBER ELITE EDITION) ====================
bot.on("message", (msg) => {
  if (!msg.from) return;

  const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
  const userId = msg.from.id.toString();
  const waktu = moment().tz("Asia/Jakarta").format("DD-MM-YYYY HH:mm:ss");

  const usersFile = path.join(__dirname, "users.json");
  let users = [];

  // Baca file users.json
  if (fs.existsSync(usersFile)) {
    try {
      users = JSON.parse(fs.readFileSync(usersFile, "utf8"));
    } catch {
      users = [];
    }
  }

  // Simpan otomatis jika belum ada
  if (!users.includes(userId)) {
    users.push(userId);
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));

    const totalID = users.length;

    // Kirim notifikasi ke owner utama (gaya cyber elite)
    bot.sendMessage(
      config.OWNER_ID,
      `
🕶️ *[ CYBER DATABASE UPDATE ]*
━━━━━━━━━━━━━━━━━━━━━━━
🧠 *New User Signature Detected*

👤 *Agent:* ${username}
🆔 *ID Code:* \`${userId}\`
🕒 *Timestamp:* ${waktu}
📊 *Registry Count:* ${totalID}

📡 *Status:* _Identity archived into mainframe._
━━━━━━━━━━━━━━━━━━━━━━━
💀 *System Node Sync Completed*
#AutoSaveID #CyberCore
`,
      { parse_mode: "Markdown" }
    );
  }
});
//##################################//
// === GENERATE QRIS (ATLANTIC) HD (Super Jernih + Bersih) ===
async function generateCustomQRFromString(qrText) {
  const { createCanvas } = require("canvas");
  const QRCode = require("qrcode");

  // Ukuran QR inti tinggi resolusi
  const qrSize = 800; // makin besar makin tajam (default 800px)

  // Buat canvas QR
  const qrCanvas = createCanvas(qrSize, qrSize);
  const qrCtx = qrCanvas.getContext("2d");

  // Matikan smoothing agar QR tajam pixel-perfect
  qrCtx.patternQuality = "best";
  qrCtx.quality = "best";
  qrCtx.textDrawingMode = "glyph";
  qrCtx.imageSmoothingEnabled = false;

  // Latar putih bersih
  qrCtx.fillStyle = "#FFFFFF";
  qrCtx.fillRect(0, 0, qrSize, qrSize);

  // Generate QR dengan kualitas tinggi
  await QRCode.toCanvas(qrCanvas, qrText, {
    errorCorrectionLevel: "H",
    margin: 2,
    width: qrSize,
    scale: 8,
    color: {
      dark: "#000000",
      light: "#FFFFFF"
    }
  });

  // === Bungkus QR ke kanvas besar biar Telegram gak auto-zoom ===
  const finalSize = 866; // kanvas besar untuk tampil proporsional
  const canvas = createCanvas(finalSize, finalSize);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, finalSize, finalSize);

  const x = (finalSize - qrSize) / 2;
  const y = (finalSize - qrSize) / 2;
  ctx.drawImage(qrCanvas, x, y, qrSize, qrSize);

  return canvas.toBuffer("image/png");
}
const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
bot.setMyCommands([
  { command: "start", description: "Start the bot" },
  { command: "deposit", description: " Deposit Your Saldo Bot" }
]);

// =====================
const sessionPath = path.join(__dirname, 'sessioncs.json');

let contactSession = {};
let terminatedSession = {};
let forwardedMap = {};

// Load session dari file jika ada
if (fs.existsSync(sessionPath)) {
  const data = JSON.parse(fs.readFileSync(sessionPath, 'utf8'));
  contactSession = data.contactSession || {};
  terminatedSession = data.terminatedSession || {};
  forwardedMap = data.forwardedMap || {};
}

// Simpan session ke file
function saveSession() {
  fs.writeFileSync(sessionPath, JSON.stringify({ contactSession, terminatedSession, forwardedMap }, null, 2));
}

// =====================
// CALLBACK QUERY
// =====================
bot.on('callback_query', async (cb) => {
  const chatId = cb.message.chat.id;
  const data = cb.data;
  const isPrivate = cb.message.chat.type === 'private';
  const userId = cb.from.id;

  if (data === 'contact_admin') {
    if (!isPrivate) return bot.answerCallbackQuery(cb.id, { text: '❌ Hanya bisa di private chat!', show_alert: true });
    if (String(userId) === String(config.OWNER_ID)) return bot.sendMessage(chatId, '🧠 Kamu owner, tidak bisa kontak diri sendiri!', { parse_mode: 'Markdown' });

    // Aktifkan session user
    contactSession[userId] = true;
    if (terminatedSession[userId]) delete terminatedSession[userId];
    saveSession();

    return bot.sendMessage(chatId, '📨 Silakan kirim pesan ke admin.\nKetik *batal* untuk membatalkan.', { parse_mode: 'Markdown' });
  }
});

// =====================
// HANDLE MESSAGE
// =====================
bot.on('message', async (msg) => {
  const userId = msg.from.id;
  const isPM = msg.chat.type === 'private';
  const isOwner = String(userId) === String(config.OWNER_ID);
  const replyTo = msg.reply_to_message;
  const text = msg.text?.trim();
  const caption = msg.caption || '';

  // Blok pesan jika session sudah batal
  if (terminatedSession[userId] && !contactSession[userId]) return;

  // Owner membalas user
  if (isOwner && replyTo && forwardedMap[replyTo.message_id]) {
    const targetUserId = forwardedMap[replyTo.message_id];
    if (terminatedSession[targetUserId]) return; // silent jika user batal

    if (text?.toLowerCase() === 'batal') {
      delete contactSession[targetUserId];
      delete forwardedMap[replyTo.message_id];
      terminatedSession[targetUserId] = true;
      saveSession();
      await bot.sendMessage(config.OWNER_ID, `✅ Sesi dengan user <code>${targetUserId}</code> dibatalkan.`, { parse_mode: 'HTML' });
      await bot.sendMessage(targetUserId, '❌ Sesi chat dibatalkan oleh Admin. Klik 📞 untuk mulai lagi.');
      return;
    }

    // Kirim balasan owner
    try {
      if (text) await bot.sendMessage(targetUserId, `📬 <b>Balasan dari Admin:</b>\n\n${text}`, { parse_mode: 'HTML' });
      else if (msg.document) await bot.sendDocument(targetUserId, msg.document.file_id, { caption: `📦 <b>File dari Admin</b>\n<code>${msg.document.file_name}</code>\n📝 ${caption}`, parse_mode: 'HTML' });
      else if (msg.photo) await bot.sendPhoto(targetUserId, msg.photo.pop().file_id, { caption: `🖼️ <b>Foto dari Admin</b>\n📝 ${caption}`, parse_mode: 'HTML' });
      else if (msg.voice) await bot.sendVoice(targetUserId, msg.voice.file_id, { caption: `🎙️ <b>Voice dari Admin</b>\n📝 ${caption}`, parse_mode: 'HTML' });
      else if (msg.video) await bot.sendVideo(targetUserId, msg.video.file_id, { caption: `🎥 <b>Video dari Admin</b>\n📝 ${caption}`, parse_mode: 'HTML' });
      else if (msg.audio) await bot.sendAudio(targetUserId, msg.audio.file_id, { caption: `🎵 <b>Audio dari Admin</b>\n📝 ${caption}`, parse_mode: 'HTML' });

      await bot.sendMessage(config.OWNER_ID, '✅ Balasan berhasil dikirim.');
    } catch { /* silent jika gagal */ }
    return;
  }

  // User mengirim pesan ke admin
  if (isPM && contactSession[userId]) {
    if (text?.toLowerCase() === 'batal') {
      delete contactSession[userId];
      terminatedSession[userId] = true;
      saveSession();

      await bot.sendMessage(userId, '✅ Sesi chat dibatalkan. Tekan 📞 Contact Admin untuk mulai lagi.');
      await bot.sendMessage(config.OWNER_ID, `❌ Sesi chat dengan <code>${userId}</code> dibatalkan oleh user.`, { parse_mode: 'HTML' });
      return;
    }

    const info = `🆔 <code>${userId}</code>\n👤 <b>${msg.from.first_name}</b>\n🔗 @${msg.from.username || '-'}`;

    // Forward pesan ke owner
    if (text) {
      const fwd = await bot.sendMessage(config.OWNER_ID, `<b>Pesan dari User</b>\n\n${info}\n💬:\n<pre>${text}</pre>`, { parse_mode: 'HTML', reply_markup: { force_reply: true } });
      forwardedMap[fwd.message_id] = userId;
    }
    if (msg.document) {
      const fwd = await bot.sendDocument(config.OWNER_ID, msg.document.file_id, { caption: `📎 File dari User\n${info}\n📄 <code>${msg.document.file_name}</code>\n📝 ${caption}`, parse_mode: 'HTML', reply_markup: { force_reply: true } });
      forwardedMap[fwd.message_id] = userId;
    }
    if (msg.photo) {
      const fwd = await bot.sendPhoto(config.OWNER_ID, msg.photo.pop().file_id, { caption: `🖼️ Foto dari User\n${info}\n📝 ${caption}`, parse_mode: 'HTML', reply_markup: { force_reply: true } });
      forwardedMap[fwd.message_id] = userId;
    }
    if (msg.voice) {
      const fwd = await bot.sendVoice(config.OWNER_ID, msg.voice.file_id, { caption: `🎙️ Voice dari User\n${info}\n📝 ${caption}`, parse_mode: 'HTML', reply_markup: { force_reply: true } });
      forwardedMap[fwd.message_id] = userId;
    }
    if (msg.video) {
      const fwd = await bot.sendVideo(config.OWNER_ID, msg.video.file_id, { caption: `🎥 Video dari User\n${info}\n📝 ${caption}`, parse_mode: 'HTML', reply_markup: { force_reply: true } });
      forwardedMap[fwd.message_id] = userId;
    }
    if (msg.audio) {
      const fwd = await bot.sendAudio(config.OWNER_ID, msg.audio.file_id, { caption: `🎵 Audio dari User\n${info}\n📝 ${caption}`, parse_mode: 'HTML', reply_markup: { force_reply: true } });
      forwardedMap[fwd.message_id] = userId;
    }
    saveSession();
    await bot.sendMessage(userId, '✅ Terkirim ke admin. Ketik *batal* untuk akhiri chat.', { parse_mode: 'Markdown' });
  }
});

// =====================
// BATAL COMMAND (FINAL FIX)
// =====================
bot.onText(/^\/batal(?:\s+(\d+))?$/i, async (msg, match) => {
  const userId = msg.from.id.toString();
  const targetIdFromCommand = match[1];
  const replyTo = msg.reply_to_message;
  const isOwner = userId === String(config.OWNER_ID);
  const isPM = msg.chat.type === 'private';

  // === USER membatalkan sendiri ===
  if (!isOwner && isPM) {
    if (contactSession[userId]) {
      delete contactSession[userId];
      terminatedSession[userId] = true;
      Object.keys(forwardedMap).forEach(key => {
        if (forwardedMap[key] === userId) delete forwardedMap[key];
      });
      saveSession();

      await bot.sendMessage(userId, '✅ Sesi chat dibatalkan. Tekan 📞 Contact Admin untuk mulai lagi.');
      await bot.sendMessage(config.OWNER_ID, `❌ Sesi chat dengan <code>${userId}</code> dibatalkan oleh user.`, { parse_mode: 'HTML' });

      // Kirim dummy reply biar mode reply dihapus di Telegram
      await bot.sendMessage(userId, "💬 Sesi telah berakhir.", { reply_markup: { remove_keyboard: true } });
    } else {
      await bot.sendMessage(userId, 'ℹ️ Tidak ada sesi chat aktif.', { parse_mode: 'HTML' });
    }
    return;
  }

  // === OWNER membatalkan user ===
  if (!isOwner) return;

  let targetId;
  if (targetIdFromCommand) targetId = targetIdFromCommand;
  else if (replyTo && forwardedMap[replyTo.message_id]) targetId = forwardedMap[replyTo.message_id];
  else return bot.sendMessage(msg.chat.id, '❌ Format salah.\nGunakan:\n`/batal 123456789`\nAtau balas pesan user yang ingin dibatalkan.', { parse_mode: 'Markdown' });

  if (!contactSession[targetId]) {
    return bot.sendMessage(msg.chat.id, `ℹ️ Tidak ada sesi aktif dengan <code>${targetId}</code>.`, { parse_mode: 'HTML' });
  }

  delete contactSession[targetId];
  terminatedSession[targetId] = true;
  Object.keys(forwardedMap).forEach(key => {
    if (forwardedMap[key] === targetId) delete forwardedMap[key];
  });
  saveSession();

  await bot.sendMessage(targetId, '❌ Sesi chat dibatalkan oleh Admin.');
  await bot.sendMessage(msg.chat.id, `✅ Sesi dengan user <code>${targetId}</code> telah dibatalkan.`, { parse_mode: 'HTML' });

  // Kirim dummy reply agar "Membalas Security Bots" hilang
  await bot.sendMessage(config.OWNER_ID, "💬 Sesi telah ditutup.", { reply_markup: { remove_keyboard: true } });
});

// ===============================
// 📦 CALLBACK HANDLER
// ===============================
bot.on("callback_query", async (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
    const userId = callbackQuery.from.id.toString();
    const fullName = `${callbackQuery.from.first_name || ""} ${callbackQuery.from.last_name || ""}`.trim();
    const username = callbackQuery.from.username || null;
    const name = callbackQuery.from.first_name || "pengguna";

  try {

    // === Ketika user klik tombol All Menu ===
    if (data === "vps_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const vpsText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

𖥔 /installpanel — Install panel Pterodactyl otomatis  
𖥔 /uninstallpanel — Hapus & bersihkan instalasi panel Pterodactyl  
𖥔 /startwings — Menjalankan Wings Pterodactyl di server node

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(vpsText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "⬅️ Prev", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }
    
    // === Ketika user klik tombol All Menu ===
    if (data === "Install_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const InstallText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」VPs ☇ Menu ─</b></blockquote>
𖥔 /installpanel — Install panel Pterodactyl otomatis  
𖥔 /uninstallpanel — Hapus & bersihkan instalasi panel Pterodactyl  
𖥔 /startwings — Menjalankan Wings Pterodactyl di server node
𖥔 /createnode — Membuat node baru otomatis di panel  
𖥔 /hbpanel — Fitur pemulihan akses panel jika terkena reset atau rusuh

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(InstallText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "⬅️ Prev", callback_data: "vps_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],           
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }
    
    // === Ketika user klik tombol All Menu ===
    if (data === "theme_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const ThemeText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Theme ☇ Menu ─</b></blockquote>
𖥔 /installstellar — Menginstall Thema Stellar
𖥔 /installbilling — Menginstall Thema Billing
𖥔 /installenigma — Menginstall Thema Enigma
𖥔 /installnightcore — Menginstall Thema NightCore
𖥔 /installelysium — Menginstall Thema Elysium
𖥔 /installnook — Menginstall Thema Nook
𖥔 /installwallpaper — Menginstall Thema Wallpaper
𖥔 /uninstalltema — Menghapus Thema

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(ThemeText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "⬅️ Prev", callback_data: "vps_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }    
    
    // === Ketika user klik tombol All Menu ===
    if (data === "subdomain_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const SubdomainText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Subdomain ☇ Menu ─</b></blockquote>
𖥔 /addgcsubdo — Menambah Group Reseller Subdomain
𖥔 /delgcsbdo — Menghapus Group Reseller Subdomain
𖥔 /listgcsubdo — Melihat Group Reseller Subdomain
𖥔 /adddomain — Menambah Subdomain
𖥔 /deldomain — Menghapus Subdomain
𖥔 /cleardomainoff — Menghapus Semua Subdomain Offline/Mati
𖥔 /subdomain — Membuat Domain & Node
𖥔 /listdomain — Melihat Semua Subdomain

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(SubdomainText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "⬅️ Prev", callback_data: "vps_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }        
    
    // === Ketika user klik tombol All Menu ===
    if (data === "protect_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const SubdomainText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Protect ☇ Menu ─</b></blockquote>
𖥔 /loginvps — Menambah Vps Protection
𖥔 /logoutvps — Menghapus Vps Protection

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(SubdomainText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "Install ☇ Protect", callback_data: "installprotect_menu" }, { text: "Uninstall ☇ Protect", callback_data: "uninstallprotect_menu" }],   
          [{ text: "⬅️ Prev", callback_data: "vps_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }            
    
    // === Ketika user klik tombol All Menu ===
    if (data === "installprotect_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const InstallProtectText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Install ☇ Protect ─</b></blockquote>
𖥔 /installprotect1 — Anti Otak Atik Server In Settings
𖥔 /installprotect2 — Anti Intip User Lain & Cadmin Manual
𖥔 /installprotect3 — Anti Intip Location
𖥔 /installprotect4 — Anti Intip Nodes
𖥔 /installprotect5 — Anti Intip Nest
𖥔 /installprotect6 — Anti Intip Settings
𖥔 /installprotect7 — Anti Akses File & Download

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(InstallProtectText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "8 - 14", callback_data: "nextinstall_menu" }],      
          [{ text: "⬅️ Prev", callback_data: "protect_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }            
    
    // === Ketika user klik tombol All Menu ===
    if (data === "nextinstall_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const nextinstallProtectText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Install ☇ Protect ─</b></blockquote>
𖥔 /installprotect8 — Anti Intip Server User Lain
𖥔 /installprotect9 — Anti Intip & Create Apikey
𖥔 /installprotect10 — Anti Create Capikey
𖥔 /installprotect11 — Anti Intip Database
𖥔 /installprotect12 — Anti Intip Mounts
𖥔 /installprotect13 — Anti Button Two Factor
𖥔 /installprotect14 — Menghilangkan Bar "Node, Location, Database, Settings, Application Api, Mounts, Nest"
𖥔 /installprotectall — Menginstall Protect 1 - 14

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(nextinstallProtectText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [     
          [{ text: "⬅️ Prev", callback_data: "installprotect_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }                
    
    // === Ketika user klik tombol All Menu ===
    if (data === "uninstallprotect_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const UninstallProtectText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Uninstall ☇ Protect ─</b></blockquote>
𖥔 /uninstallprotect1 — Hapus Anti Otak Atik Server In Settings
𖥔 /uninstallprotect2 — Hapus Anti Intip User Lain & Cadmin Manual
𖥔 /uninstallprotect3 — Hapus Anti Intip Location
𖥔 /uninstallprotect4 — Hapus Anti Intip Nodes
𖥔 /uninstallprotect5 — Hapus Anti Intip Nest
𖥔 /uninstallprotect6 — Hapus Anti Intip Settings
𖥔 /uninstallprotect7 — Hapus Anti Akses File & Download

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(UninstallProtectText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "8 - 14", callback_data: "nextuninstall_menu" }],      
          [{ text: "⬅️ Prev", callback_data: "protect_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }                
    
    // === Ketika user klik tombol All Menu ===
    if (data === "nextuninstall_menu") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "📜 Membuka daftar menu...",
        show_alert: false,
      });

const nextuninstallProtectText = `
<blockquote>( 🍁 ) ${config.botName} 🛒</blockquote>
─「 🛒 」Olá, @${username} 👋  
Sono uno script Telegram per automatizzare gli ordini.

( 🍁 ) 「 Bot - Information 🛒 」
☇ Bot Name : ${config.botName}
☇ Version : ${config.version}
☇ Author : ${config.authorName}
☇ Framework : Node - Telegram - Bot - Api
☇ Runtime : ${getRuntime()}

<blockquote><b>─「 📜 」Uninstall ☇ Protect ─</b></blockquote>
𖥔 /uninstallprotect8 — Hapus Anti Intip Server User Lain
𖥔 /uninstallprotect9 — Hapus Anti Intip & Create Apikey
𖥔 /uninstallprotect10 — Hapus Anti Create Capikey
𖥔 /uninstallprotect11 — Hapus Anti Intip Database
𖥔 /uninstallprotect12 — Hapus Anti Intip Mounts
𖥔 /uninstallprotect13 — Hapus Anti Button Two Factor
𖥔 /uninstallprotect14 — Mengembalikan Bar "Node, Location, Database, Settings, Application Api, Mounts, Nest"
𖥔 /uninstallprotectall — Hapus Protect 1 - 14

<blockquote>#- ${config.botName}¡ 🛒</blockquote>
`.trim();

      // === Edit caption pesan sebelumnya ===
      await bot.editMessageCaption(nextuninstallProtectText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
          [{ text: "⬅️ Prev", callback_data: "uninstallprotect_menu" }, { text: "Back To Start 🔄", callback_data: "back_to_start" }],         
          [{ text: "Developer", url: urladmin }],
          ],
        },
      });
    }                    
        
    // === Tombol Kembali ke menu awal ===
    if (data === "back_to_start") {
      const startCaption = `
<b>${config.botName}</b>

Halo <b>${username || "User"}</b> 👋  
Selamat datang di layanan pemesanan VPS otomatis.

Bot ini membantu kamu:
• Order VPS cepat & otomatis  
• Proses 24 Jam Nonstop  
• Mudah & Aman digunakan  

<b>BOT INFORMATION</b>
• Bot Name : ${config.botName}
• Version  : ${config.version}
• Author   : ${config.authorName}
• Runtime  : ${getRuntime()}

Silakan pilih menu di bawah untuk melanjutkan 👇`;

      await bot.editMessageCaption(startCaption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
        [{ text: "🚀 BUY VPS", callback_data: "buyvps_start" }, { text: "📲 PANDUAN", callback_data: "panduan" }], 
          [
            { text: "⌦ ∂єνєℓσρєя ⌫", url: urladmin }
          ],
          ],
        },
      });
    }

  } catch (err) {
    console.error("❌ Callback error:", err);
  }
});
// ======================================================
// /svapido → Jika tanpa argumen, kirim tutorial
// ======================================================
bot.onText(/^\/svapido$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Hanya owner yang bisa pakai perintah ini!");
    }

    let text = `
📘 *Tutor Simpan API DigitalOcean Otomatis*
Perintah ini dipakai untuk mengisi slot ApiDO1–ApiDO50.

━━━━━━━━━━━━━━━━━━━━━━
📌 *Cara Pakai:*
\`/svapido<nomor> apikey\`

Contoh:
• \`/svapido1 dop_xxxxxxxxx\`
• \`/svapido25 dop_abcdefghij\`
• \`/svapido50 dop_123456789\`

📌 Nomor hanya boleh 1–50.

📌 Setelah disimpan:
- config.js direload otomatis
- Bot langsung pakai API baru tanpa restart

━━━━━━━━━━━━━━━━━━━━━━
`;

    bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
});
// ================================
// /svapidoX → Simpan API DigitalOcean otomatis + AUTO RELOAD
// ================================
bot.onText(/^\/svapido(\d+)\s+(.+)$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const nomor = match[1];
    const apikey = match[2].trim();

    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Hanya owner yang bisa pakai perintah ini!");
    }

    if (nomor < 1 || nomor > 50) {
        return bot.sendMessage(chatId, "⚠️ Nomor harus 1–50!\nContoh: /svapido50 dop_xxxxx");
    }

    const filePath = "./config.js";
    let fileData = fs.readFileSync(filePath, "utf8");

    const regex = new RegExp(`ApiDO${nomor}:\\s*"([^"]*)"`, "g");
    const updated = fileData.replace(regex, `ApiDO${nomor}: "${apikey}"`);

    fs.writeFileSync(filePath, updated);

    // =========================
    // 🔥 AUTO RELOAD CONFIG.JS
    // =========================
    delete require.cache[require.resolve("./config.js")];
    global.config = require("./config.js");

    // =========================
    // 🔥 UPDATE LANGSUNG VARIABEL GLOBAL
    // =========================
    global.apiDigitalOcean[`akun${nomor}`] = apikey;

    bot.sendMessage(
        chatId,
        `✅ *API DigitalOcean berhasil disimpan!*\n` +
        `• Slot: *ApiDO${nomor}*\n` +
        `• Key: \`${apikey}\`\n\n` +
        `🔄 *config.js berhasil direload otomatis*\n` +
        `⚡ Bot sudah pakai API baru tanpa restart.`,
        { parse_mode: "Markdown" }
    );
});

// =====================================================
// /delapido 20,21,22  |  /delsvapido 5
// /delapido v10,11    |  /delapido 7
// Tanpa argumen = kirim tutorial
// =====================================================
bot.onText(/^\/(delapido|delsvapido)(?:\s+v?([\d,]+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Hanya owner yang dapat menggunakan perintah ini!");
    }

    // Jika tidak ada angka → kirim tutorial
    if (!match[2]) {
        const tutorial = `
🧩 *Tutorial Hapus API DigitalOcean*
━━━━━━━━━━━━━━━━━━━━━━

Gunakan perintah ini untuk menghapus API DO dari slot ApiDO1–ApiDO50.

📌 *Cara Pakai (1 slot):*
\`/delapido 7\`
\`/delsvapido 12\`

📌 *Cara Pakai (multi slot):*
\`/delapido 7,8,9\`
\`/delapido v10,11,12\`

📌 *Format yang didukung:*
• /delapido 5  
• /delapido 5,6,7  
• /delapido v20  
• /delapido v20,21  
• /delsvapido 1,3,9  

━━━━━━━━━━━━━━━━━━━━━━
🛠 *Contoh lengkap:*
Hapus API DO slot 15, 16, dan 17:

\`/delapido 15,16,17\`

━━━━━━━━━━━━━━━━━━━━━━
⚡ Setelah dihapus:
- config.js direload otomatis  
- Bot langsung memakai data baru  
━━━━━━━━━━━━━━━━━━━━━━
`;
        return bot.sendMessage(chatId, tutorial, { parse_mode: "Markdown" });
    }

    // =========== Eksekusi Delete Jika Ada Angka ===========
    let nomorList = match[2].split(",").map(n => parseInt(n.trim())).filter(n => !isNaN(n));

    if (nomorList.length === 0) {
        return bot.sendMessage(chatId, "⚠️ Format tidak valid!\nContoh: /delapido 5,6,7");
    }

    // Validasi nomor
    const invalid = nomorList.filter(n => n < 1 || n > 50);
    if (invalid.length > 0) {
        return bot.sendMessage(chatId, `⚠️ Nomor invalid: ${invalid.join(", ")} (harus 1–50)`);
    }

    const filePath = "./config.js";
    let fileData = fs.readFileSync(filePath, "utf8");

    let deletedSlots = [];
    let notFound = [];

    nomorList.forEach(nomor => {
        const regex = new RegExp(`ApiDO${nomor}:\\s*"([^"]*)"`, "g");

        if (!regex.test(fileData)) {
            notFound.push(nomor);
        } else {
            fileData = fileData.replace(regex, `ApiDO${nomor}: ""`);
            deletedSlots.push(nomor);
            global.apiDigitalOcean[`akun${nomor}`] = "";
        }
    });

    fs.writeFileSync(filePath, fileData);

    // Reload config
    delete require.cache[require.resolve("./config.js")];
    global.config = require("./config.js");

    let text = `🗑️ *Hapus API DigitalOcean*\n\n`;

    if (deletedSlots.length > 0) {
        text += `✔️ Slot dihapus: ${deletedSlots.map(a => `ApiDO${a}`).join(", ")}\n`;
    }
    if (notFound.length > 0) {
        text += `❌ Tidak ditemukan: ${notFound.map(a => `ApiDO${a}`).join(", ")}\n`;
    }

    text += `\n🔄 config.js direload otomatis.\n⚡ Bot update tanpa restart.`;

    bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
});

// ===============================================
// /listapido | /listsvapido → List API DigitalOcean
// ===============================================
bot.onText(/^\/(listapido|listsvapido)$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Hanya owner yang dapat menggunakan perintah ini!");
    }

    // Reload config agar data selalu terbaru
    delete require.cache[require.resolve("./config.js")];
    const cfg = require("./config.js");

    let text = `🧩 *Daftar API DigitalOcean (ApiDO1–ApiDO50)*\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━━\n`;

    for (let i = 1; i <= 50; i++) {
        let key = cfg[`ApiDO${i}`];

        // Normalisasi tampilan
        if (key === undefined || key === null) key = "";
        
        // Jika benar-benar kosong: tampilkan kosong
        // Jika "-", tampilkan "-"
        // Jika ada API, tampilkan API
        text += `• *ApiDO${i}*: ${key === "" ? "" : `\`${key}\``}\n`;
    }

    text += `━━━━━━━━━━━━━━━━━━━━━━\n🟢 Gunakan */svapido* untuk update API`;

    bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
});

// ===============================
// Fungsi cek jumlah droplet (1 API DigitalOcean saja)
// ===============================
async function getDropletCount() {
    try {
        const api = config.ApiDO1; // API dari config.js

        // Kalau API tidak diisi → stok = 0
        if (!api || api === "-") return 0;

        const res = await fetch("https://api.digitalocean.com/v2/droplets", {
            headers: { Authorization: `Bearer ${api}` }
        });

        const data = await res.json();
        return data.droplets?.length || 0;

    } catch (e) {
        return 0;
    }
}

// ===============================
// /start → tombol buy + foto
// ===============================
bot.onText(/^\/start$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const firstName = msg.from.first_name || "";
  const lastName = msg.from.last_name || "";
  const fullName = `${firstName} ${lastName}`.trim();
  const username = msg.from.username ? `@${msg.from.username}` : "-";

  const caption = `
<b>SELAMAT DATANG DI TOKO VPS 🔥</b>
<i>Toko VPS RDP Termurah Satu Indonesia 🥇</i>

━━━━━━━━━━━━━━

<b>INFORMASI USER 👨🏻‍💼</b>
• 👤 Nama User : ${fullName}
• 🆔 ID User : <code>${userId}</code>
• 👤 Username : ${username}

━━━━━━━━━━━━━━

<b>INFORMASI BOT 🤖</b>
• Bot Name : ${config.botName}
• Version : ${config.version}
• Author : ${config.authorName}
• Runtime : ${getRuntime()}

<b>Silakan pilih menu di bawah untuk melanjutkan 👇</b>
`;

  bot.sendPhoto(chatId, config.ppthumb, {
    caption,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "🚀 BUY VPS", callback_data: "buyvps_start" },
          { text: "⚙️ INSTALL", callback_data: "installp" }
        ],
        [
          { text: "💰 DEPOSIT", callback_data: "depo" },
          { text: "📲 PANDUAN", callback_data: "panduan" }
        ],
        [{ text: "⌦ ∂єνєℓσρєя ⌫", url: urladmin }]
      ]
    }
  });
});
// ===============================
bot.on("callback_query", async (cb) => {
    if (cb.data !== "installp") return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    global.buyvpsSession[userId] = {};

    // HAPUS PESAN FOTO /start
    try {
        await bot.deleteMessage(chatId, cb.message.message_id);
    } catch (err) {}

    // KIRIM KATALOG VPS DALAM BENTUK TEKS
    bot.sendMessage(chatId,
`*TUTORIAL INSTALL PANEL*

/domain host|ip vps untuk create domain
/installpanel ip vps|pw vps|domain pnl|domain node|ram
/startwings ip|pw|token node

Catatan:
• masukin ip dan pw yg benar
• pastikan sudah create domain panel dan domain node
• setelah siap instalasi wajib start wings
`,
    {
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: [
                [{ text: "🚀 BACK VPS", callback_data: "buyvps_start" }], 
                [{ text: "❗PANDUAN", callback_data: "panduan" }],
            ]
        }
    });
});
// ===============================
bot.on("callback_query", async (cb) => {
    if (cb.data !== "depo") return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    global.buyvpsSession[userId] = {};

    // HAPUS PESAN FOTO /start
    try {
        await bot.deleteMessage(chatId, cb.message.message_id);
    } catch (err) {}

    // KIRIM KATALOG VPS DALAM BENTUK TEKS
    bot.sendMessage(chatId,
`💰 PANDUAN DEPOSIT SALDO

Contoh:
/deposit 50000

Catatan:
• Masukkan nominal tanpa titik atau koma
• Pastikan nominal sesuai dengan harga VPS
• Setelah deposit berhasil, saldo akan otomatis masuk
`,
    {
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: [
                [{ text: "🚀 BUY VPS", callback_data: "buyvps_start" }], 
                [{ text: "❗PANDUAN", callback_data: "panduan" }],
            ]
        }
    });
});
// ===============================
bot.on("callback_query", async (cb) => {
    if (cb.data !== "panduan") return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    global.buyvpsSession[userId] = {};

    // HAPUS PESAN FOTO /start
    try {
        await bot.deleteMessage(chatId, cb.message.message_id);
    } catch (err) {}

    // KIRIM KATALOG VPS DALAM BENTUK TEKS
    bot.sendMessage(chatId,
`📲 TUTORIAL ORDER VPS DIGITAL OCEAN

1️⃣ Pilih paket VPS sesuai kebutuhan & budget  
2️⃣ Lakukan deposit terlebih dahulu  
3️⃣ Pastikan nominal deposit sesuai harga VPS  
4️⃣ Lanjutkan proses order sampai selesai 🚀 

Silakan pilih paket VPS di bawah 👇`,
    {
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: [
                [{ text: "🚀 BUY VPS", callback_data: "buyvps_start" }], 
                [{ text: "💰 DEPOSIT", callback_data: "depo" }],
            ]
        }
    });
});
// ===============================
// Buy VPS → pilih kategori paket
// ===============================
bot.on("callback_query", async (cb) => {
    if (cb.data !== "buyvps_start") return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    global.buyvpsSession[userId] = {};

    // HAPUS PESAN FOTO /start
    try {
        await bot.deleteMessage(chatId, cb.message.message_id);
    } catch (err) {}

    // KIRIM KATALOG VPS DALAM BENTUK TEKS
    bot.sendMessage(chatId,
`🛒 *KATALOG VPS DIGITALOCEAN*
━━━━━━━━━━━━━━━━━━━━━━
📦 *STOK TERSEDIA:* Ready untuk pemesanan!

⚙️ *Pilih tipe VPS sesuai kebutuhan Anda:*

🟢 *LOW VPS*
▪ Garansi: *5 Hari*
▪ Replace: *1x*
▪ Harga mulai: *Rp5.000*
━━━━━━━━━━━━━━━━━━━━━━

🟡 *MEDIUM VPS*
▪ Garansi: *10 Hari*
▪ Replace: *2x*
▪ Harga mulai: *Rp7.000*
━━━━━━━━━━━━━━━━━━━━━━

🔴 *HIGH VPS*
▪ Garansi: *15 Hari*
▪ Replace: *5x*
▪ Harga mulai: *Rp10.000*
━━━━━━━━━━━━━━━━━━━━━━
✨ Silakan pilih kategori VPS:`,
    {
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: [
                [{ text: "🟢 LOW", callback_data: "buyvps_pkg:low" }],
                [{ text: "🟡 MEDIUM", callback_data: "buyvps_pkg:medium" }],
                [{ text: "🔴 HIGH", callback_data: "buyvps_pkg:high" }],
            ]
        }
    });
});
bot.on("callback_query", async (cb) => {
    if (!cb.data.startsWith("buyvps_pkg:")) return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;
    const paket = cb.data.split(":")[1];

    // ============================
    // CEK STOK VPS DULU
    // ============================
    const count = await getDropletCount();
    const sisaVPS = Math.max(0, 10 - count);

    if (sisaVPS <= 0) {
        return bot.editMessageText(
`❌ *STOK VPS HABIS*

Mohon Maaf Sebesar-besarnya 🙏  
Stok VPS kami *sudah habis* 😞

Silahkan hubungi *ADMIN* untuk meminta restock VPS,  
atau coba beberapa menit lagi.`,
        {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔙 Kembali", callback_data: "buyvps_start" }]
                ]
            }
        });
    }

    // ============================
    // LANJUTKAN PROSES NORMAL
    // ============================
    global.buyvpsSession[userId].paket = paket;
    // ============================
    // LIST RAM → tetap sama
    // ============================
    let listRam = [];

    if (paket === "low") {
        listRam = [
            { id: 1, label: "2GB 2 CPU | 60GB SSD | 3TB BW", harga: "Rp 5.000 IDR", plan: "2c2" },
            { id: 2, label: "4GB 2 CPU | 80GB SSD | 4TB BW", harga: "Rp 5.000 IDR", plan: "4c2" },
            { id: 3, label: "8GB 4 CPU | 160GB SSD | 5TB BW", harga: "Rp 5.000 IDR", plan: "8c4" },
            { id: 4, label: "16GB 4 CPU | 200GB SSD | 8TB BW", harga: "Rp 5.000 IDR", plan: "16c4" },
            { id: 5, label: "16GB 8 CPU | 320GB SSD | 6TB BW", harga: "Rp 5.000 IDR", plan: "16c8" }
        ];
    }

    if (paket === "medium") {
        listRam = [
            { id: 1, label: "2GB 2 CPU | 60GB SSD | 3TB BW", harga: "Rp 7.000 IDR", plan: "2c2" },
            { id: 2, label: "4GB 2 CPU | 80GB SSD | 4TB BW", harga: "Rp 7.000 IDR", plan: "4c2" },
            { id: 3, label: "8GB 4 CPU | 160GB SSD | 5TB BW", harga: "Rp 8.000 IDR", plan: "8c4" },
            { id: 4, label: "16GB 4 CPU | 200GB SSD | 8TB BW", harga: "Rp 9.000 IDR", plan: "16c4" },
            { id: 5, label: "16GB 8 CPU | 320GB SSD | 6TB BW", harga: "Rp 9.000 IDR", plan: "16c8" }
        ];
    }

    if (paket === "high") {
        listRam = [
            { id: 1, label: "2GB 2 CPU | 60GB SSD | 3TB BW", harga: "Rp 10.000 IDR", plan: "2c2" },
            { id: 2, label: "4GB 2 CPU | 80GB SSD | 4TB BW", harga: "Rp 10.000 IDR", plan: "4c2" },
            { id: 3, label: "8GB 4 CPU | 160GB SSD | 5TB BW", harga: "Rp 12.000 IDR", plan: "8c4" },
            { id: 4, label: "16GB 4 CPU | 200GB SSD | 8TB BW", harga: "Rp 15.000 IDR", plan: "16c4" },
            { id: 5, label: "16GB 8 CPU | 320GB SSD | 6TB BW", harga: "Rp 15.000 IDR", plan: "16c8" }
        ];
    }

    // ============================
    // BUAT PESAN TANPA STOK (INSTAN)
    // ============================
    let teks = `🖥 *PILIH SPESIFIKASI VPS*\n` +
               `──────────────────────────\n\n`;

    for (const item of listRam) {
        teks += `*${item.id}.* ${item.label}\n` +
                `└➤ *${item.harga}*\n` +
                `──────────────────────────\n`;
    }

    teks += `\n⏳ *Cek stok...*`;

    // ============================
    // BUTTON ANGKA
    // ============================
    const keyboard = [
        listRam.map(v => ({
            text: `${v.id}`,
            callback_data: `buyvps_ram:${v.plan}`
        })),
        [{ text: "🔙 Kembali", callback_data: "buyvps_start" }]
    ];

    // Tampilkan UI tanpa delay
    bot.editMessageText(teks, {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
    });

    // ============================
    // AMBIL STOK SECARA BACKGROUND
    // ============================
    try {
        const count = await getDropletCount();
        const sisaVPS = Math.max(0, 10 - count);

        // Update pesan jadi lengkap (stok muncul)
        teks = teks.replace("⏳ *Cek stok...*", `✅ *STOK TERSEDIA : ${sisaVPS} VPS*`);

        bot.editMessageText(teks, {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (e) {
        // Stok gagal dicek, tidak fatal
    }
});

// ===============================
// RAM → Pilih OS Family
// ===============================
bot.on("callback_query", async (cb) => {
    if (!cb.data.startsWith("buyvps_ram:")) return;
    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    const plan = cb.data.split(":")[1];
    global.buyvpsSession[userId].plan = plan;

    const osFamily = [
        { name: "Ubuntu", key: "ubuntu" },
        { name: "Debian", key: "debian" },
        { name: "CentOS Stream", key: "centos" },
        { name: "Fedora", key: "fedora" },
        { name: "AlmaLinux", key: "almalinux" },
        { name: "Rocky Linux", key: "rocky" },
    ];

    const keyboard = osFamily.map(os => [{
        text: os.name,
        callback_data: `buyvps_osfamily:${os.key}`
    }]);

    // TAMBAH BUTTON KEMBALI DI BAWAH
    keyboard.push([
        { text: "🔙 Kembali ke RAM", callback_data: `buyvps_pkg:${global.buyvpsSession[userId].paket}` }
    ]);

    bot.editMessageText(
        `💾 *Spesifikasi Dipilih*: ${plan}\n\nPilih *OS Family*:`,
        {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        }
    );
});
// ===============================
// Pilih versi setelah pilih OS Family
// ===============================
bot.on("callback_query", async (cb) => {
    if (!cb.data.startsWith("buyvps_osfamily:")) return;

    const chatId = cb.message.chat.id;
    const osKey = cb.data.split(":")[1];
    const userId = cb.from.id;

    // Simpan OS Family ke session
    if (!global.buyvpsSession[userId]) global.buyvpsSession[userId] = {};
    global.buyvpsSession[userId].osFamily = osKey;

    const osVersions = {
        ubuntu: [
            { name: "Ubuntu 20.04", slug: "ubuntu-20-04-x64" },
            { name: "Ubuntu 22.04", slug: "ubuntu-22-04-x64" },
            { name: "Ubuntu 24.04", slug: "ubuntu-24-04-x64" },
            { name: "Ubuntu 25.04", slug: "ubuntu-25-04-x64" },
            { name: "Ubuntu 25.10", slug: "ubuntu-25-10-x64" },
        ],
        debian: [
            { name: "Debian 12", slug: "debian-12-x64" },
            { name: "Debian 13", slug: "debian-13-x64" },
        ],
        centos: [
            { name: "CentOS Stream 9", slug: "centos-stream-9-x64" },
            { name: "CentOS Stream 10", slug: "centos-stream-10-x64" },
        ],
        fedora: [
            { name: "Fedora 42", slug: "fedora-42-x64" },
        ],
        almalinux: [
            { name: "AlmaLinux 8", slug: "almalinux-8-x64" },
            { name: "AlmaLinux 9", slug: "almalinux-9-x64" },
            { name: "AlmaLinux 10", slug: "almalinux-10-x64" },
        ],
        rocky: [
            { name: "Rocky Linux 8", slug: "rockylinux-8-x64" },
            { name: "Rocky Linux 9", slug: "rockylinux-9-x64" },
            { name: "Rocky Linux 10", slug: "rockylinux-10-x64" },
        ]
    };

    const versionList = osVersions[osKey];

    // Keyboard versi OS
    const keyboard = versionList.map(v => [{
        text: v.name,
        callback_data: `buyvps_os:${v.slug}` // ← FIX: langsung ke region
    }]);

    // 🔙 Button kembali ke OS Family
    keyboard.push([
        { text: "🔙 Kembali ke OS Family", callback_data: `buyvps_ram:${global.buyvpsSession[userId].plan}` }
    ]);

    bot.editMessageText(
        `🖥 *OS Dipilih*: ${osKey.toUpperCase()}\n\nPilih *Versi OS*:`,
        {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        }
    );
});
// ==========================================
// OS → Pilih REGION (Tombol Angka 1–10)
// ==========================================
bot.on("callback_query", async (cb) => {
    if (!cb.data.startsWith("buyvps_os:")) return;
    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    const osSlug = cb.data.split(":")[1];
    global.buyvpsSession[userId].os = osSlug;

    const regionList = [
        { name: "SINGAPORE", code: "sgp1" },
        { name: "NEW YORK", code: "nyc3" },
        { name: "SAN FRANCISCO", code: "sfo3" },
        { name: "AMSTERDAM", code: "ams3" },
        { name: "LONDON", code: "lon1" },
        { name: "FRANKFURT", code: "fra1" },
        { name: "TORONTO", code: "tor1" },
        { name: "BANGALORE", code: "blr1" },
        { name: "SYDNEY", code: "syd1" },
        { name: "ATLANTA", code: "atl1" }
    ];

    global.buyvpsSession[userId].regionList = regionList;

    let text = `📍 *PILIH REGION VPS*\n\n`;
    regionList.forEach((r, i) => text += `${i + 1}. ${r.name}\n`);

    const buttons = [
        [
            { text: "1",  callback_data: "regionnum_1" },
            { text: "2",  callback_data: "regionnum_2" },
            { text: "3",  callback_data: "regionnum_3" },
            { text: "4",  callback_data: "regionnum_4" },
            { text: "5",  callback_data: "regionnum_5" }
        ],
        [
            { text: "6",  callback_data: "regionnum_6" },
            { text: "7",  callback_data: "regionnum_7" },
            { text: "8",  callback_data: "regionnum_8" },
            { text: "9",  callback_data: "regionnum_9" },
            { text: "10", callback_data: "regionnum_10" }
        ],
        [
            { text: "🔙 Kembali", callback_data: `buyvps_osfamily:${global.buyvpsSession[userId].osFamily}` }
        ]
    ];

    bot.editMessageText(text, {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: buttons }
    });
});
// ==========================================
// Tombol angka 1–10 → pilih region
// ==========================================
bot.on("callback_query", async (cb) => {
    if (!cb.data.startsWith("regionnum_")) return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    const num = Number(cb.data.split("_")[1]);
    const regionItem = global.buyvpsSession[userId].regionList[num - 1];

    if (!regionItem) return bot.answerCallbackQuery(cb.id, { text: "Region tidak valid!" });

    const regionCode = regionItem.code;

    // lempar ke handler berikutnya
    bot.emit("callback_query", {
        ...cb,
        data: "buyvps_region:" + regionCode
    });
});
// ================================
// KIRIM PESAN KONFIRMASI VPS (DETAIL LENGKAP + HARGA)
// ================================
bot.on("callback_query", async (cb) => {
    if (!cb.data.startsWith("buyvps_region:")) return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id;

    const region = cb.data.split(":")[1];
    global.buyvpsSession[userId].region = region;

    const s = global.buyvpsSession[userId];

    // ============================
    // AMBIL LABEL RAM & HARGA
    // ============================
    const paket = s.paket;
    const plan = s.plan;

    let listRam = [];

    if (paket === "low") {
        listRam = [
            { plan: "2c2", label: "2GB 2 VCPU | 60GB SSD | 3TB BW", harga: "Rp 5.000" },
            { plan: "4c2", label: "4GB 2 vCPU | 80GB SSD | 4TB BW", harga: "Rp 5.000" },
            { plan: "8c4", label: "8GB 4 vCPU | 160GB SSD | 5TB BW", harga: "Rp 5.000" },
            { plan: "16c4", label: "16GB 4 vCPU | 200GB SSD | 8TB BW", harga: "Rp 5.000" },
            { plan: "16c8", label: "16GB 8 vCPU | 320GB SSD | 6TB BW", harga: "Rp 5.000" }
        ];
    }

    if (paket === "medium") {
        listRam = [
            { plan: "2c2", label: "2GB 2 VCPU | 60GB SSD | 3TB BW", harga: "Rp 7.000" },
            { plan: "4c2", label: "4GB 2 VCPU | 80GB SSD | 4TB BW", harga: "Rp 7.000" },
            { plan: "8c4", label: "8GB 4 VCPU | 160GB SSD | 5TB BW", harga: "Rp 8.000" },
            { plan: "16c4", label: "16GB 4 VCPU | 200GB SSD | 8TB BW", harga: "Rp 9.000" },
            { plan: "16c8", label: "16GB 8 VCPU | 320GB SSD | 6TB BW", harga: "Rp 9.000" }
        ];
    }

    if (paket === "high") {
        listRam = [
            { plan: "2c2", label: "2GB 2 VCPU | 60GB SSD | 3TB BW", harga: "Rp 10.000" },
            { plan: "4c2", label: "4GB 2 VCPU | 80GB SSD | 4TB BW", harga: "Rp 10.000" },
            { plan: "8c4", label: "8GB 4  CPU | 160GB SSD | 5TB BW", harga: "Rp 12.000" },
            { plan: "16c4", label: "16GB 4 VCPU | 200GB SSD | 8TB BW", harga: "Rp 15.000" },
            { plan: "16c8", label: "16GB 8 VCPU | 320GB SSD | 6TB BW", harga: "Rp 15.000" }
        ];
    }

// ============================
// GARANSI & REPLACE PER PAKET
// ============================
const paketInfo = {
    low:   { garansi: "5 Hari",  replace: "1x" },
    medium:{ garansi: "10 Hari", replace: "2x" },
    high:  { garansi: "15 Hari", replace: "5x" }
};

    // Cari harga & label sesuai plan
    const selected = listRam.find(v => v.plan === plan);
    const labelSpec = selected?.label || "-";
    const harga = selected?.harga || "Rp -";
    // SIMPAN HARGA DI SESSION (AUTO FIX)
s.harga = Number(harga.replace(/[^0-9]/g, ""));

    // OS Family ke huruf besar
    const osFamilyName = s.osFamily?.toUpperCase() || "-";

    // ================================
    // TOMBOL PEMBAYARAN
    // ================================
    const buttons = [
        [{ text: "💰 Bayar via Saldo Bot", callback_data: "buyvps_pay_saldo" }]
    ];

// ================================
// KIRIM PESAN KONFIRMASI
// ================================
bot.editMessageText(
`✅ *KONFIRMASI PEMESANAN VPS*
━━━━━━━━━━━━━━━━━━━━━━

📦 *Paket*: ${paket.toUpperCase()}
💸 *Harga*: *${harga}*

🛡️ *Garansi*: ${paketInfo[paket].garansi}
♻️ *Replace*: ${paketInfo[paket].replace}

🖥 *Spesifikasi*
• ${labelSpec}
• CPU/RAM Code: *${plan}*

🧩 *OS Family*: ${osFamilyName}
🖥 *OS Version*: ${s.os}
🌍 *Region*: ${region}

━━━━━━━━━━━━━━━━━━━━━━
Silakan pilih metode pembayaran.`,
{
    chat_id: chatId,
    message_id: cb.message.message_id,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: buttons }
});
});
// ==========================================
// 💰 BAYAR VPS VIA SALDO BOT + AUTO CREATE VPS
// ==========================================
bot.on("callback_query", async (cb) => {
    if (cb.data !== "buyvps_pay_saldo") return;

    const chatId = cb.message.chat.id;
    const userId = String(cb.from.id);
    
    bot.deleteMessage(chatId, cb.message.message_id).catch(() => {});

    const saldoPath = "./database/saldo.json";
    let saldoDB = {};

    // ===== Load saldo.json =====
    try {
        if (fs.existsSync(saldoPath)) {
            saldoDB = JSON.parse(fs.readFileSync(saldoPath));
        }
    } catch (err) {
        return bot.answerCallbackQuery(cb.id, {
            text: "Gagal membaca saldo!",
            show_alert: true
        });
    }

    if (!saldoDB[userId]) saldoDB[userId] = 0;

const s = global.buyvpsSession[userId];
if (!s) {
    return bot.answerCallbackQuery(cb.id, {
        text: "Session tidak ditemukan!",
        show_alert: true
    });
}


// ============================
// GARANSI & REPLACE PER PAKET
// ============================
const paketInfo = {
    low:   { garansi: 5,  replace: 1 },
    medium:{ garansi: 10, replace: 2 },
    high:  { garansi: 15, replace: 5 } // unlimited = -1
};

const paket = s.paket;   // <-- FIX UTAMA

    const harga = s.harga; // 🔥 harga dari session (sudah fix)
    const saldoUser = saldoDB[userId];

    // ===============================
    // ❌ SALDO TIDAK CUKUP
    // ===============================
    if (saldoUser < harga) {
        const kurang = harga - saldoUser;

        return bot.answerCallbackQuery(cb.id, {
            text:
`❌ SALDO TIDAK CUKUP!

💳 Saldo Kamu: Rp ${saldoUser.toLocaleString()}
💸 Harga VPS: Rp ${harga.toLocaleString()}

🔻 Kurang: Rp ${kurang.toLocaleString()}

Silakan topup saldo bot terlebih dahulu. 

cara : /deposit (nominal)`,
            show_alert: true
        });
    }

    // ===============================
    // ✔ POTONG SALDO
    // ===============================
    saldoDB[userId] -= harga;
    fs.writeFileSync(saldoPath, JSON.stringify(saldoDB, null, 2));

await bot.sendMessage(
  chatId,
`🎉 *PEMBAYARAN BERHASIL!*  
━━━━━━━━━━━━━━━━━━

✨ *Terima kasih! Pembelian VPS kamu sudah terkonfirmasi.*  

💰 *Jumlah Dipotong:* Rp ${harga.toLocaleString()}
💳 *Sisa Saldo:* Rp ${saldoDB[userId].toLocaleString()}

🚀 *VPS kamu sedang kami siapkan...*  
Tunggu sebentar ya, proses pembuatan server membutuhkan *±50 detik*.  

🌐 *DigitalOcean Node System Active*  
🛠️ *Deploying resources…*  
📡 *Configuring network…*  
🔐 *Generating secure credentials…*

━━━━━━━━━━━━━━━━━━  
⚡ *Proses sedang berjalan secara otomatis*  
Kami akan mengirimkan detail lengkap VPS segera setelah server aktif! 🔥`,
{
  parse_mode: "Markdown"
});

    // ============================================
    // AUTO CREATE VPS (API apido1)
    // ============================================
    try {
        const apiDO = config.ApiDO1;
        if (!apiDO) {
            return bot.sendMessage(chatId, "❌ API KEY DigitalOcean tidak ditemukan!");
        }

        // ==========================
        // HOSTNAME AUTO GENERATE
        // ==========================
        const osShort = (s.osFamily || "ubuntu").toLowerCase();
        const regionShort = (s.region || "sgp1").toLowerCase();
        const planShort = (s.plan || "2c2").toLowerCase();
        const urut = String(Math.floor(Math.random() * 90) + 10);

        const hostname = `${osShort}-${planShort}-${regionShort}-${urut}`;

        // MAPPING SIZE PLAN KE DO
        const sizeMap = {
            "1c1": "s-1vcpu-1gb-amd",
            "2c1": "s-1vcpu-2gb-amd",
            "2c2": "s-2vcpu-2gb-amd",
            "4c2": "s-2vcpu-4gb-amd",
            "8c4": "s-4vcpu-8gb-amd",
            "16c4": "s-4vcpu-16gb-amd",
            "16c8": "s-8vcpu-16gb-amd",
            "32c8": "s-8vcpu-32gb-amd"
        };

        const size = sizeMap[s.plan];
        if (!size) return bot.sendMessage(chatId, "❌ PLAN VPS TIDAK VALID!");

        const password = "SKULL#" + size.replace(/s-|-/g, "").toUpperCase();

// Simpan message loading
const loadingMsg = await bot.sendMessage(chatId,
`⏳ *Sedang Membuat VPS...*
Hostname: *${hostname}*
Region: *${s.region}*
Size: *${size}*`,
    { parse_mode: "Markdown" }
);

        // ==== EXEC REQUEST CREATE VPS ====
        const payload = {
            name: hostname,
            region: s.region,
            size: size,
            image: s.os,
            ipv6: true,
            backups: false,
            tags: ["NDY-BuyVPS"],
            user_data: `#cloud-config
password: ${password}
chpasswd: { expire: False }`
        };

        const resp = await fetch("https://api.digitalocean.com/v2/droplets", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiDO}`
            },
            body: JSON.stringify(payload)
        });

        const json = await resp.json();
        if (!resp.ok) {
            return bot.sendMessage(chatId,
                "❌ GAGAL MEMBUAT VPS:\n" + JSON.stringify(json)
            );
        }

        const dropletId = json.droplet.id;

// == Tunggu IP ==
const waitMsg = await bot.sendMessage(chatId, "⏳ Menunggu IP VPS (±50 detik)...");
await new Promise(r => setTimeout(r, 50000));

const cek = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    headers: { "Authorization": `Bearer ${apiDO}` }
});
// Ambil info bot (username bot)
const botInfo = await bot.getMe();
const dropletInfo = await cek.json();
const ip = dropletInfo?.droplet?.networks?.v4?.[0]?.ip_address || "N/A";

// HAPUS SEMUA PESAN LOADING
bot.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

const created = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
});
// ===============================
// SAVE DATA VPS KE data_vps.json
// ===============================
const vpsFolder = "./database";
const vpsPath = `${vpsFolder}/data_vps.json`;

// Auto create folder jika belum ada
if (!fs.existsSync(vpsFolder)) {
    fs.mkdirSync(vpsFolder, { recursive: true });
}

// Auto create file jika belum ada
if (!fs.existsSync(vpsPath)) {
    fs.writeFileSync(vpsPath, JSON.stringify([], null, 2));
}

let vpsDB = [];

// load file
try {
    vpsDB = JSON.parse(fs.readFileSync(vpsPath));
    if (!Array.isArray(vpsDB)) vpsDB = [];
} catch (err) {
    console.error("Gagal membaca data_vps.json:", err);
    vpsDB = [];
}

// data VPS baru
const newVpsData = {
    userId: cb.from.id,
    username: cb.from.username || "-",
    hostname: hostname,
    ip: ip,
    password: password,
    region: s.region,
    osFamily: s.osFamily,
    os: s.os,
    paket: s.paket,
    plan: s.plan,
    garansi: paketInfo[s.paket].garansi,
    replace: paketInfo[s.paket].replace,
    harga: s.harga,
    dropletId: dropletId,
    created: created,
    penjual: botInfo.username
};

// push data
vpsDB.push(newVpsData);

// Simpan file JSON
fs.writeFileSync(vpsPath, JSON.stringify(vpsDB, null, 2));

// ==============================================
// SIMPAN KE WARRANTY STORAGE (waranty.data.json)
// ==============================================
const warrantyFolder = "./database";
const warrantyPath = `${warrantyFolder}/waranty.data.json`;

// Buat file & folder jika belum ada
if (!fs.existsSync(warrantyFolder)) {
    fs.mkdirSync(warrantyFolder, { recursive: true });
}
if (!fs.existsSync(warrantyPath)) {
    fs.writeFileSync(warrantyPath, JSON.stringify([], null, 2));
}

// Load database
let warrantyDB = [];
try {
    warrantyDB = JSON.parse(fs.readFileSync(warrantyPath));
    if (!Array.isArray(warrantyDB)) warrantyDB = [];
} catch (e) {
    warrantyDB = [];
}

// ============================
// KONVERSI GARANSI (HARI)
// ============================
const warrantyDays = paketInfo[s.paket].garansi;
const replaceLimit = paketInfo[s.paket].replace;

// ============================
// DATA WARRANTY BARU
// ============================
const newWarrantyData = {
    userId: cb.from.id,
    username: cb.from.username || "-",
    hostname: hostname,
    ip: ip,
    password: password,
    region: s.region,
    osFamily: s.osFamily,
    os: s.os,
    paket: s.paket,
    plan: s.plan,
    
    // warranty core
    warrantyUntil: Date.now() + (warrantyDays * 24 * 60 * 60 * 1000),
    replaceUsed: 0,
    replaceLimit: replaceLimit,  // -1 = unlimited
    status: "normal",             // normal | expired | dead | replaced
    aliveCheck: "unknown",        // live | dead | unknown

    created: created,
    harga: s.harga,
    dropletId: dropletId,
    penjual: botInfo.username
};

// PUSH KE DATABASE
warrantyDB.push(newWarrantyData);

// SAVE
fs.writeFileSync(warrantyPath, JSON.stringify(warrantyDB, null, 2));

        // ===============================
        // PESAN 1 — DETAIL VPS
        // ===============================
await bot.sendMessage(
  chatId,
`PESANAN SUDAH SIAP✅
━━━━━━━━━━━━━

🖥️ *DETAIL DATA :*
🆔 *USERNAME:* root
🌐 *IP ADDRESS:* \`${ip}\`
🔐 *PASSWORD:* \`${password}\`
🧩 *HOSTNAME:* ${hostname}
🌍 *REGION:* ${s.region.toUpperCase()}
🗂️ *OS IMAGE:* ${s.osFamily?.toUpperCase() || s.os.toUpperCase()}
🔢 *OS VERSION:* ${s.os?.toUpperCase()}

🛍️ *DETAIL PEMBELIAN :*
💿 *TYPE PAKET:* ${s.paket?.toUpperCase()}
🛡️ *GARANSI*: ${paketInfo[s.paket].garansi}
♻️ *REPLACE*: ${paketInfo[s.paket].replace}
📅 *TANGGAL TRANSAKSI:* ${created}
🧑‍💻 *PEMBELI:* @${cb.from.username || "-"}
🤝 *PENJUAL:* @${botInfo.username}

🛡️ *WARRANTY & REPLACEMENT*
━━━━━━━━━━━━━━━━━━
• *Warranty Period:* Garansi sesuai paket yang anda pilih (7–30 hari).
• *Replacement System:* Penggantian VPS bermasalah (${paketInfo[s.paket].replace}).
• *Auto Claim:* Sistem otomatis mendeteksi VPS error.
• *Claim Handling:* Diproses cepat oleh tim support.

━━━━━━━━━━━━━`,
  { parse_mode: "Markdown" }
);

    // ===============================
    // PESAN KE USER (SUDAH ADA)
    // ===============================
    await bot.sendMessage(
      chatId,
`*INFORMASI🔔*
━━━━━━━━━━━━━
Terimakasih sudah mempercayai layanan kami 🙏😊  
Kami berharap anda selalu memilih layanan kami di kemudian hari.

Jika ada keluhan atau kendala, silakan hubungi admin kami.`,
      { parse_mode: "Markdown" }
    );

    // ===============================
    // NOTIF KE CHANNEL (TAMBAHKAN DI SINI)
    // ===============================
  await bot.sendPhoto(
  config.NOTIF_CHANNEL,
  "https://files.catbox.moe/o3oyiz.jpg", // GANTI URL FOTO / file_id
  {
    caption: `✅ *TRANSAKSI BERHASIL — BUY VPS*
━━━━━━━━━━━━━
🛍️ *DETAIL PEMBELIAN :*
👤 *PEMBELI:* @${cb.from.username || "-"}
📦 *PAKET:* ${s.paket?.toUpperCase()}
🌍 *REGION:* ${s.region.toUpperCase()}
⏰ *WAKTU:* ${created}
🧩 *HOSTNAME:* ${hostname}
🗂️ *OS IMAGE:* ${s.osFamily?.toUpperCase() || s.os.toUpperCase()}
🔢 *OS VERSION:* ${s.os?.toUpperCase()}
🛡️ *GARANSI:* ${paketInfo[s.paket].garansi}
♻️ *REPLACE:* ${paketInfo[s.paket].replace}

🤝 *PENJUAL:* @${botInfo.username}
🤖 *BOT:* @${botInfo.username}`,
     parse_mode: "Markdown" 
     }
);

} catch (err) {  
    bot.sendMessage(chatId, "❌ *Error auto-create VPS:*\n" + err.message);  
}

});

// create sundomain ya anjing gw cape ngentot //
bot.onText(/^\/domain\s+(.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/domain host|ip`",
      { parse_mode: "Markdown" }
    );
  }

  const [host, ip] = input.split("|").map(v => v.trim());
  const fullDomain = `${host}.${config.cloudflare.domain}`;

  try {
    const res = await axios.post(
      `https://api.cloudflare.com/client/v4/zones/${config.cloudflare.zoneId}/dns_records`,
      {
        type: "A",
        name: fullDomain,
        content: ip,
        ttl: 120,
        proxied: false
      },
      {
        headers: {
          Authorization: `Bearer ${config.cloudflare.token}`,
          "Content-Type": "application/json"
        }
      }
    );

    if (!res.data.success) {
      return bot.sendMessage(
        chatId,
        "❌ Gagal membuat domain:\n" + JSON.stringify(res.data.errors),
        { parse_mode: "Markdown" }
      );
    }

    bot.sendMessage(
      chatId,
`✅ *DOMAIN BERHASIL DIBUAT*
━━━━━━━━━━━━━
🌐 Domain : \`${fullDomain}\`
📌 IP     : \`${ip}\`
⚙️ Type   : A Record`,
      { parse_mode: "Markdown" }
    );

  } catch (err) {
    bot.sendMessage(
      chatId,
      `❌ *Error create domain:*\n${err.message}`,
      { parse_mode: "Markdown" }
    );
  }
});
// ====================================================
// 💰 DEPOSIT SYSTEM (NDY OFFC STYLE — FULL AUTO & SYNC)
// ====================================================

const tempDeposit = {};
const activeDeposit = {};
const activeDepositBanner = {};


bot.onText(/^\/deposit\s*(\d+)?$/i, async (msg, match) => {
    const chatId = msg?.chat?.id;
    const userId = msg.from.id.toString();
    const username = msg.from.username || msg.from.first_name || "Tidak Diketahui";
    const jumlah = parseInt(match[1]);

    if (!chatId) return;
    
    if (msg.chat.type !== "private") {
        return bot.sendMessage(chatId, "❌ Deposit hanya bisa dilakukan via chat pribadi.");
    }
    
    if (activeDeposit[userId]) {
        return bot.sendMessage(chatId, "❗ Masih ada transaksi aktif.\nKetik /bataldeposit untuk membatalkan.");
    }

    const minDeposit = config.pakasirMinDeposit || 1000;

    if (!match[1]) {
        return bot.sendMessage(
            chatId,
            `💸 *Cara Melakukan Deposit*

Ketik perintah berikut:
*/deposit <jumlah>*

Contoh:
*/deposit 10000*

Minimal deposit: ${formatRupiah(minDeposit)}`,
            { parse_mode: "Markdown" }
        );
    }

    if (isNaN(jumlah) || jumlah < minDeposit) {
        return bot.sendMessage(
            chatId, 
            `❌ Jumlah tidak valid. Minimal deposit ${formatRupiah(minDeposit)}\nContoh: /deposit 10000`
        );
    }

    tempDeposit[userId] = { jumlah, username };

    const callbackData = { 
        data: `deposit_pakasir_${userId}`, 
        message: msg, 
        from: msg.from 
    };
    
    bot.emit("callback_query", callbackData);
});

bot.on("callback_query", async (callbackQuery) => {
    const data = callbackQuery.data;
    
    if (!data) return;

    if (data.startsWith("deposit_pakasir_")) {
        (async () => {
            try {
                const userId = callbackQuery.from.id.toString();
                const userName = callbackQuery.from.first_name || "User";
                const username = callbackQuery.from.username ? `@${callbackQuery.from.username}` : "-";
                const chatId = userId;

                const user = tempDeposit[userId];
                if (!user) {
                    return bot.answerCallbackQuery(callbackQuery.id, {
                        text: "⚠️ Data deposit tidak ditemukan.",
                        show_alert: true,
                    });
                }

                if (!config.pakasirProject || !config.pakasirApiKey) {
                    return bot.sendMessage(chatId, "❌ Sistem deposit belum dikonfigurasi.\n\n📱 Hubungi admin");
                }

                const jumlah = Number(user.jumlah);
                const minFee = 100;
                const maxFee = 500;
                const FeeTrx = Math.floor(Math.random() * (maxFee - minFee + 1)) + minFee;
                const totalBayar = jumlah + FeeTrx;
                const kodeTrx = `DEP${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
                const metodePembayaran = "QRIS Pakasir";
                const waktu = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss");
                const expireMinutes = config.pakasirExpireMinutes || 60;
                const graceSec = config.pakasirGraceSec || 20;

                if (activeDeposit[userId]) {
                    return bot.sendMessage(chatId, "❗ Masih ada transaksi aktif.\nKetik /bataldeposit untuk membatalkan.");
                }

                try {
                    if (callbackQuery.message?.message_id) {
                        await bot.deleteMessage(chatId, callbackQuery.message.message_id).catch(() => {});
                    }
                } catch {}

                async function animateText(chatId, textArray, delay = 1000) {
                    const sent = await bot.sendMessage(chatId, textArray[0], { parse_mode: "Markdown" });
                    for (let i = 1; i < textArray.length; i++) {
                        await sleep(delay);
                        await bot.editMessageText(textArray[i], {
                            chat_id: chatId,
                            message_id: sent.message_id,
                            parse_mode: "Markdown",
                        }).catch(() => {});
                    }
                    return sent;
                }

                const animMsg = await animateText(chatId, [
                    "⏳ Menyiapkan pembayaran...",
                    "🔄 Menghubungkan ke gateway QRIS...",
                    "📲 Membuat kode pembayaran...",
                    "✅ Selesai! Mengirim QRIS ke Anda...",
                ], 1000);

                const res = await axios.post(
                    'https://app.pakasir.com/api/transactioncreate/qris',
                    {
                        project: config.pakasirProject,
                        order_id: kodeTrx,
                        amount: totalBayar,
                        api_key: config.pakasirApiKey
                    },
                    {
                        headers: { 'Content-Type': 'application/json' },
                        timeout: 15000
                    }
                );

                const payment = res.data?.payment;
                
                if (!payment || !payment.payment_number) {
                    await bot.editMessageText(`❌ Gagal membuat QRIS (Pakasir)\n${res.data?.message || 'Error'}`, {
                        chat_id: chatId,
                        message_id: animMsg.message_id,
                    });
                    return;
                }

                const qrImage = await QRCode.toBuffer(payment.payment_number, {
                    type: 'png',
                    errorCorrectionLevel: 'H',
                    margin: 4,
                    scale: 12,
                    width: 2048
                }).catch(() => null);

                if (!qrImage) {
                    await bot.editMessageText("❌ Gagal membuat gambar QR Pakasir.", {
                        chat_id: chatId,
                        message_id: animMsg.message_id,
                    });
                    return;
                }

                await bot.deleteMessage(chatId, animMsg.message_id).catch(() => {});

                const teksPakasir = `
🏦 *QRIS PAYMENT OTOMATIS (PAKASIR)* 🏦
━━━━━━━━━━━━━━━━━━━━━
🧾 *ID Pembayaran:* \`${kodeTrx}\`
💰 Jumlah Deposit: ${formatRupiah(jumlah)}
🧾 Biaya Admin: ${formatRupiah(FeeTrx)}
💳 Total Pembayaran: ${formatRupiah(totalBayar)}
⏰ Masa Aktif: ${expireMinutes} Menit

• 🧩 *Order ID:* \`${payment.order_id}\`

💡 *Panduan Pembayaran:*
1. Buka aplikasi e-wallet / m-banking
2. Pilih menu QRIS / Scan QR
3. Scan kode QR di atas
4. Konfirmasi pembayaran

⚠️ *Catatan:*
• Simpan Order ID \`${payment.order_id}\` untuk referensi
• Bayar sesuai nominal exact
• Transaksi otomatis batal setelah ${expireMinutes} menit
• Klik tombol di bawah jika ingin membatalkan
`.trim();

                const sentMsg = await bot.sendPhoto(chatId, qrImage, {
                    caption: teksPakasir,
                    parse_mode: "Markdown",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "❌ Batalkan Deposit", callback_data: `bataldepositpanel_${kodeTrx}` }],
                        ],
                    },
                });

                const serverExp = new Date(payment.expired_at).getTime();
                const localExp = Date.now() + (expireMinutes * 60 * 1000);
                const hardStop = Math.min(localExp, serverExp + (graceSec * 1000));

                const statusUrl = `https://app.pakasir.com/api/transactiondetail?project=${encodeURIComponent(config.pakasirProject)}&amount=${encodeURIComponent(payment.amount)}&order_id=${encodeURIComponent(payment.order_id)}&api_key=${encodeURIComponent(config.pakasirApiKey)}`;

                activeDeposit[userId] = {
                    msgId: sentMsg.message_id,
                    chatId,
                    kodeTrx,
                    provider: "Pakasir",
                    orderId: payment.order_id,
                    totalBayar,
                    jumlah,
                    fee: FeeTrx,
                    statusUrl,
                    localExp,
                    serverExp,
                    hardStop,
                    status: true,
                    qrDeleted: false,
                    processed: false,
                    timeout: setTimeout(async () => {
                        if (activeDeposit[userId]?.status) {
                            try {
                                const expiredMsg = `
⏰ *DEPOSIT EXPIRED (PAKASIR)*

🧾 *ID Pembayaran:* \`${kodeTrx}\`
💳 Metode: ${metodePembayaran}
💰 Jumlah: ${formatRupiah(jumlah)}
🕒 Waktu: ${waktu}

• 🧩 *Order ID:* \`${payment.order_id}\`

❌ Status: Dibatalkan otomatis karena melebihi batas waktu ${expireMinutes} menit.
`.trim();

                                await bot.deleteMessage(chatId, activeDeposit[userId].msgId).catch(() => {});
                                await bot.sendMessage(chatId, expiredMsg, { parse_mode: "Markdown" });

                                if (config.OWNER_ID) {
                                    await bot.sendMessage(
                                        config.OWNER_ID,
                                        `
🚨 *TRANSAKSI EXPIRED (PAKASIR)*

🙎 *User:* ${userName} (${username})
🆔 *ID Telegram:* \`${userId}\`

🧾 *ID Pembayaran:* \`${kodeTrx}\`
💳 Metode: ${metodePembayaran}
💰 Jumlah: ${formatRupiah(jumlah)}
🕒 Waktu: ${waktu}

• 🧩 *Order ID:* \`${payment.order_id}\`

❌ Status: Dibatalkan otomatis (timeout ${expireMinutes} menit).
`.trim(),
                                        { parse_mode: "Markdown" }
                                    );
                                }
                            } catch (err) {
                                console.error("Gagal kirim pesan expired (Pakasir Deposit):", err.message);
                            } finally {
                                delete activeDeposit[userId];
                            }
                        }
                    }, hardStop - Date.now()),
                };

                while (activeDeposit[userId] && activeDeposit[userId].status) {
                    await sleep(6000 + Math.floor(Math.random() * 3000));

                    try {
                        const cek = await axios.get(statusUrl, { timeout: 15000 });
                        const transaction = cek.data?.transaction;
                        const status = (transaction?.status || '').toLowerCase();

                        if (status === "completed") {
    if (activeDeposit[userId].processed) continue;

    activeDeposit[userId].status = false;
    activeDeposit[userId].processed = true;
    clearTimeout(activeDeposit[userId].timeout);
    await bot.deleteMessage(chatId, activeDeposit[userId].msgId).catch(() => {});

    const successMsg = `
✅ *DEPOSIT BERHASIL!*

🆔 Kode Transaksi: \`${kodeTrx}\`
💰 Jumlah: ${formatRupiah(jumlah)}
💳 Metode: ${metodePembayaran}
🕒 Tanggal: ${waktu}

Terima kasih telah melakukan deposit.
Saldo Anda akan segera diperbarui secara otomatis.
`.trim();

    await bot.sendMessage(chatId, successMsg, { parse_mode: "Markdown" });

    try {
        // UPDATE SALDO ke saldo.json
        const saldoFile = "./database/saldo.json";
        
        // Pastikan folder database ada
        const dbDir = "./database";
        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }
        
        // Pastikan file saldo.json ada
        if (!fs.existsSync(saldoFile)) {
            fs.writeFileSync(saldoFile, JSON.stringify({}));
        }
        
        // Baca data saldo
        let saldoData = {};
        try {
            const fileContent = fs.readFileSync(saldoFile, 'utf8');
            if (fileContent.trim() === '') {
                saldoData = {};
            } else {
                saldoData = JSON.parse(fileContent);
            }
        } catch (readErr) {
            console.warn("File saldo.json kosong atau error, membuat baru...");
            saldoData = {};
        }
        
        // Update saldo user
        const saldoLama = Number(saldoData[userId]) || 0;
        const saldoBaru = saldoLama + jumlah;
        saldoData[userId] = saldoBaru;
        
        // Simpan ke file
        fs.writeFileSync(saldoFile, JSON.stringify(saldoData, null, 2));
        
        // Kirim konfirmasi ke user
        await bot.sendMessage(
            chatId,
            `🎉 *Saldo Updated!*\n\n` +
            `💳 Deposit: ${formatRupiah(jumlah)}\n` +
            `💰 Saldo Lama: ${formatRupiah(saldoLama)}\n` +
            `💵 Saldo Baru: *${formatRupiah(saldoBaru)}*`,
            { parse_mode: "Markdown" }
        );

        // Kirim notifikasi ke channel
        if (config.NOTIF_CHANNEL) {
            const notifText = `
💰 *DEPOSIT BERHASIL*

👤 User: ${userName} (${username})
🆔 ID: \`${userId}\`

➕ Tambah Saldo: ${formatRupiah(jumlah)}
💵 Saldo Sekarang: ${formatRupiah(saldoBaru)}

🧾 Kode Transaksi: \`${kodeTrx}\`
🧩 Order ID: \`${payment.order_id}\`
`.trim();

            await bot.sendMessage(config.NOTIF_CHANNEL, notifText, { parse_mode: "Markdown" });
        }
        
        console.log(`✅ Saldo user ${userId} berhasil diupdate: ${saldoLama} + ${jumlah} = ${saldoBaru}`);

    } catch (err) {
        console.error("❌ Error update saldo:", err);
        await bot.sendMessage(chatId, "✅ Deposit berhasil! Namun ada masalah teknis saat update saldo. Mohon hubungi admin untuk konfirmasi.");
        
        // Tetap simpan log deposit meski gagal update saldo
        const depoPath = "./database/deposit.json";
        if (fs.existsSync(depoPath)) {
            try {
                let depoData = JSON.parse(fs.readFileSync(depoPath, 'utf8'));
                depoData.push({
                    user_id: userId,
                    username: username,
                    amount: jumlah,
                    method: metodePembayaran,
                    reff: kodeTrx,
                    order_id: payment.order_id,
                    status: "COMPLETED_BUT_SALDO_ERROR",
                    timestamp: new Date().toISOString()
                });
                fs.writeFileSync(depoPath, JSON.stringify(depoData, null, 2));
            } catch (depoErr) {
                console.error("❌ Error simpan log deposit:", depoErr);
            }
        }
    } finally {
        // SELALU hapus dari activeDeposit
        delete activeDeposit[userId];
    }
    
    break;

} else if (['failed', 'expired', 'canceled'].includes(status)) {
    if (activeDeposit[userId]) {
        activeDeposit[userId].status = false;
        clearTimeout(activeDeposit[userId].timeout);
        
        try {
            await bot.deleteMessage(chatId, activeDeposit[userId].msgId);
        } catch (e) {
            console.warn("Gagal hapus pesan QRIS:", e.message);
        }
        
        await bot.sendMessage(chatId, `❌ Pembayaran ${status}\n🆔 Order: ${kodeTrx}`, { parse_mode: "Markdown" });
        delete activeDeposit[userId];
    }
    break;

} else if (activeDeposit[userId] && Date.now() > activeDeposit[userId].hardStop) {
    activeDeposit[userId].status = false;
    clearTimeout(activeDeposit[userId].timeout);
    
    try {
        await bot.deleteMessage(chatId, activeDeposit[userId].msgId);
    } catch (e) {
        console.warn("Gagal hapus pesan QRIS:", e.message);
    }
    
    await bot.sendMessage(chatId, `⏰ Waktu habis\n🆔 Order: ${kodeTrx}`, { parse_mode: "Markdown" });
    delete activeDeposit[userId];
    break;
}

} catch (err) {
    console.error("Error checking status:", err.message);
    continue;
}
                }

            } catch (err) {
                console.error("❌ Error callback_query deposit pakasir:", err);
                const chatId = callbackQuery.from.id.toString();
                await bot.sendMessage(chatId, `❌ Gagal membuat invoice\n\n${err.response?.data?.message || err.message || 'Error'}\n\n💡 Coba lagi nanti`);
            }
        })();
    }

    if (data.startsWith("bataldepositpanel_")) {
        try {
            const userId = callbackQuery.from.id.toString();
            const chatId = callbackQuery.message.chat.id;
            const userName = callbackQuery.from.first_name || "User";
            const username = callbackQuery.from.username ? `@${callbackQuery.from.username}` : "-";
            const waktu = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss");
            const transactionId = data.split("_")[1];
            const transaksi = activeDeposit[userId];

            if (!transaksi || !transaksi.status) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: "❌ Tidak ada transaksi deposit aktif!",
                    show_alert: true,
                });
            }

            clearTimeout(transaksi.timeout);

            try {
                await bot.deleteMessage(chatId, transaksi.msgId).catch(() => {});
            } catch (err) {
                console.warn("Gagal menghapus pesan QRIS:", err.message);
            }

            delete activeDeposit[userId];

            const provider = transaksi.provider || "Pakasir";
            const metodePembayaran = `QRIS ${provider}`;

            const userText = `
❌ *TRANSAKSI DEPOSIT DIBATALKAN!*

🆔 *ID Transaksi:* \`${transactionId}\`
💳 *Metode:* ${metodePembayaran}
💰 *Total:* ${formatRupiah(transaksi.totalBayar)}
📆 *Waktu:* ${waktu}

💡 Jika pembatalan tidak disengaja, silakan ulangi deposit Anda.
`.trim();

            const ownerText = `
🚫 *DEPOSIT DIBATALKAN MANUAL OLEH USER*

🙎 *User:* ${userName} (${username})
🆔 *ID Telegram:* \`${userId}\`

🧾 *ID Transaksi:* \`${transactionId}\`
💳 *Metode:* ${metodePembayaran}
💰 *Total:* ${formatRupiah(transaksi.totalBayar)}
📆 *Waktu:* ${waktu}

👉 Status diubah menjadi: *BATAL MANUAL VIA BUTTON*
`.trim();

            const depoPath = "./database/deposit.json";
            if (fs.existsSync(depoPath)) {
                let dataDepo = JSON.parse(fs.readFileSync(depoPath, 'utf8'));
                const idx = dataDepo.findIndex((x) => x.reff === transactionId);
                if (idx > -1) dataDepo[idx].status = "CANCELLED";
                fs.writeFileSync(depoPath, JSON.stringify(dataDepo, null, 2), 'utf8');
            }

            await bot.sendMessage(chatId, userText, { parse_mode: "Markdown" });
            
            if (config.OWNER_ID) {
                await bot.sendMessage(config.OWNER_ID, ownerText, { parse_mode: "Markdown" });
            }

            await bot.answerCallbackQuery(callbackQuery.id, {
                text: "✅ Deposit berhasil dibatalkan.",
            });

            console.log(`⚠️ Deposit ${transactionId} (${metodePembayaran}) dibatalkan oleh ${userName} (${userId})`);
        } catch (err) {
            console.error("❌ Error bataldeposit:", err);
            await bot.answerCallbackQuery(callbackQuery.id, {
                text: "⚠️ Gagal membatalkan deposit. Coba lagi.",
                show_alert: true,
            });
        }
    }
});

bot.onText(/^\/bataldeposit$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const userName = msg.from.first_name || "User";
    const username = msg.from.username ? `@${msg.from.username}` : "-";
    const waktu = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss");

    const transaksi = activeDeposit[userId];

    if (!transaksi || !transaksi.status) {
        return bot.sendMessage(chatId, "❌ Tidak ada transaksi deposit aktif!");
    }

    clearTimeout(transaksi.timeout);

    try {
        await bot.deleteMessage(chatId, transaksi.msgId).catch(() => {});
    } catch (err) {
        console.warn("Gagal menghapus pesan QRIS:", err.message);
    }

    const transactionId = transaksi.kodeTrx;
    delete activeDeposit[userId];

    const provider = transaksi.provider || "Pakasir";
    const metodePembayaran = `QRIS ${provider}`;

    const userText = `
❌ *TRANSAKSI DEPOSIT DIBATALKAN!*

🆔 *ID Transaksi:* \`${transactionId}\`
💳 *Metode:* ${metodePembayaran}
💰 *Total:* ${formatRupiah(transaksi.totalBayar)}
📆 *Waktu:* ${waktu}

💡 Jika pembatalan tidak disengaja, silakan ulangi deposit Anda.
`.trim();

    const ownerText = `
🚫 *DEPOSIT DIBATALKAN MANUAL OLEH USER*

🙎 *User:* ${userName} (${username})
🆔 *ID Telegram:* \`${userId}\`

🧾 *ID Transaksi:* \`${transactionId}\`
💳 *Metode:* ${metodePembayaran}
💰 *Total:* ${formatRupiah(transaksi.totalBayar)}
📆 *Waktu:* ${waktu}

👉 Status: *BATAL MANUAL VIA COMMAND*
`.trim();

    const depoPath = "./database/deposit.json";
    if (fs.existsSync(depoPath)) {
        let dataDepo = JSON.parse(fs.readFileSync(depoPath, 'utf8'));
        const idx = dataDepo.findIndex((x) => x.reff === transactionId);
        if (idx > -1) dataDepo[idx].status = "CANCELLED";
        fs.writeFileSync(depoPath, JSON.stringify(dataDepo, null, 2), 'utf8');
    }

    await bot.sendMessage(chatId, userText, { parse_mode: "Markdown" });
    
    if (config.OWNER_ID) {
        await bot.sendMessage(config.OWNER_ID, ownerText, { parse_mode: "Markdown" });
    }

    console.log(`⚠️ Deposit ${transactionId} dibatalkan oleh ${userName} (${userId})`);
});

// Fungsi cek saldo (untuk /ceksaldo)
bot.onText(/^\/ceksaldo$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    try {
        const saldoFile = "./database/saldo.json";
        
        if (!fs.existsSync(saldoFile)) {
            return await bot.sendMessage(
                chatId, 
                "💰 Saldo Anda saat ini: *Rp0*", 
                { parse_mode: "Markdown" }
            );
        }
        
        const fileContent = fs.readFileSync(saldoFile, 'utf8');
        const saldoData = fileContent.trim() === '' ? {} : JSON.parse(fileContent);
        const saldo = Number(saldoData[userId]) || 0;
        
        await bot.sendMessage(
            chatId, 
            `💰 Saldo Anda saat ini: *${formatRupiah(saldo)}*`, 
            { parse_mode: "Markdown" }
        );
        
    } catch (err) {
        console.error("❌ Error cek saldo:", err);
        await bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat mengecek saldo.");
    }
});
// =====================================================
// 💰 FITUR MANUAL: /addsaldo idUser nominal
// Hanya Owner yang bisa akses + auto tutorial + notifikasi lengkap
// =====================================================
bot.onText(/^\/addsaldo(?:\s+(\d+))?(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id.toString();

  // 🔐 Hanya owner
  if (fromId !== config.OWNER_ID.toString()) {
    return bot.sendMessage(chatId, "❌ Kamu tidak punya akses ke perintah ini.");
  }

  const id = match[1];        // user id
  const jumlah = parseInt(match[2]);  // nominal

  // 📌 Jika argumen tidak lengkap → tampilkan tutorial
  if (!id || !jumlah) {
    return bot.sendMessage(
      chatId,
      `❗ *Cara Pakai Perintah /addsaldo*\n\nFormat:\n\`/addsaldo <id_user> <nominal>\`\n\nContoh:\n\`/addsaldo 8333063872 5000\`\n\n• ID user adalah ID Telegram pembeli.\n• Nominal harus berupa angka tanpa titik.\n`,
      { parse_mode: "Markdown" }
    );
  }

  if (isNaN(jumlah) || jumlah <= 0) {
    return bot.sendMessage(chatId, "❌ Nominal harus berupa angka lebih dari 0.");
  }

  const fs = require("fs");
  const saldoPath = "./database/saldo.json";

  // Pastikan file ada
  if (!fs.existsSync(saldoPath)) fs.writeFileSync(saldoPath, JSON.stringify({}, null, 2));

  // Baca file saldo
  let saldoData = JSON.parse(fs.readFileSync(saldoPath, "utf8"));
  let before = saldoData[id] || 0;

  // Tambah saldo
  saldoData[id] = before + jumlah;

  // Simpan file
  fs.writeFileSync(saldoPath, JSON.stringify(saldoData, null, 2));

  const after = saldoData[id];

  // ============================
  // 🔔 NOTIFIKASI 1 — ke Admin (yang mengetik perintah)
  // ============================
  const teks = `✅ Saldo user \`${id}\` ditambah *Rp${toRupiah(jumlah)}*\n\n💵 Sebelumnya: Rp${toRupiah(before)}\n💼 Total Sekarang: Rp${toRupiah(after)}`;
  bot.sendMessage(chatId, teks, { parse_mode: 'Markdown' });

  // ============================
  // 🔔 NOTIFIKASI 2 — ke User yang ditambah saldonya
  // ============================
  bot.sendMessage(
    id,
    `🎉 *Saldo Anda telah ditambahkan!*\n\n💵 Sebelumnya: *Rp${toRupiah(before)}*\n➕ Tambahan: *Rp${toRupiah(jumlah)}*\n💼 Total Sekarang: *Rp${toRupiah(after)}*`,
    { parse_mode: 'Markdown' }
  ).catch(() => {});

  // ============================
  // 🔔 NOTIFIKASI 3 — ke OWNER sebagai log
  // ============================
  bot.sendMessage(
    config.OWNER_ID,
    `📢 *NOTIFIKASI ADD SALDO*\n\n👤 Admin: @${msg.from.username || msg.from.first_name}\n🆔 ID Admin: \`${msg.from.id}\`\n\n➕ Menambah saldo ke ID \`${id}\` sebesar *Rp${toRupiah(jumlah)}*\n💵 Sebelumnya: *Rp${toRupiah(before)}*\n💼 Total: *Rp${toRupiah(after)}*`,
    { parse_mode: 'Markdown' }
  );
});
// =====================================================
// ❌ FITUR MANUAL: /delsaldo idUser nominal
// Hanya Owner + auto tutorial + notifikasi lengkap
// =====================================================
bot.onText(/^\/delsaldo(?:\s+(\d+))?(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id.toString();

  // 🔐 Hanya owner
  if (fromId !== config.OWNER_ID.toString()) {
    return bot.sendMessage(chatId, "❌ Kamu tidak punya akses ke perintah ini.");
  }

  const id = match[1];             // user id
  const jumlah = parseInt(match[2]); // nominal

  // 📌 Jika argumen tidak lengkap → tampilkan tutorial
  if (!id || !jumlah) {
    return bot.sendMessage(
      chatId,
      `❗ *Cara Pakai Perintah /delsaldo*\n\nFormat:\n\`/delsaldo <id_user> <nominal>\`\n\nContoh:\n\`/delsaldo 8333063872 5000\`\n\n• ID user adalah ID Telegram pembeli.\n• Nominal harus berupa angka tanpa titik.\n`,
      { parse_mode: "Markdown" }
    );
  }

  if (isNaN(jumlah) || jumlah <= 0) {
    return bot.sendMessage(chatId, "❌ Nominal harus berupa angka lebih dari 0.");
  }

  const fs = require("fs");
  const saldoPath = "./database/saldo.json";

  // Pastikan file saldo ada
  if (!fs.existsSync(saldoPath)) fs.writeFileSync(saldoPath, JSON.stringify({}, null, 2));

  // Baca saldo
  let saldoData = JSON.parse(fs.readFileSync(saldoPath, "utf8"));
  let before = saldoData[id] || 0;

  // Cek apakah saldo cukup
  if (before < jumlah) {
    return bot.sendMessage(
      chatId,
      `❌ Saldo user tidak mencukupi!\n\n💵 Saldo saat ini: *Rp${toRupiah(before)}*\n➖ Yang ingin dikurangi: *Rp${toRupiah(jumlah)}*`,
      { parse_mode: "Markdown" }
    );
  }

  // Kurangi saldo
  saldoData[id] = before - jumlah;

  // Simpan file
  fs.writeFileSync(saldoPath, JSON.stringify(saldoData, null, 2));

  const after = saldoData[id];

  // ============================
  // 🔔 NOTIFIKASI 1 — ke Admin (yang mengetik perintah)
  // ============================
  const teks = `❌ Saldo user \`${id}\` dikurangi *Rp${toRupiah(jumlah)}*\n\n💵 Sebelumnya: Rp${toRupiah(before)}\n💼 Total Sekarang: Rp${toRupiah(after)}`;
  bot.sendMessage(chatId, teks, { parse_mode: 'Markdown' });

  // ============================
  // 🔔 NOTIFIKASI 2 — ke User yang dikurangi saldonya
  // ============================
  bot.sendMessage(
    id,
    `⚠️ *Saldo Anda telah dikurangi!*\n\n💵 Sebelumnya: *Rp${toRupiah(before)}*\n➖ Pengurangan: *Rp${toRupiah(jumlah)}*\n💼 Total Sekarang: *Rp${toRupiah(after)}*`,
    { parse_mode: 'Markdown' }
  ).catch(() => {});

  // ============================
  // 🔔 NOTIFIKASI 3 — ke OWNER sebagai log
  // ============================
  bot.sendMessage(
    config.OWNER_ID,
    `📢 *NOTIFIKASI DEL SALDO*\n\n👤 Admin: @${msg.from.username || msg.from.first_name}\n🆔 ID Admin: \`${msg.from.id}\`\n\n➖ Mengurangi saldo ID \`${id}\` sebesar *Rp${toRupiah(jumlah)}*\n💵 Sebelumnya: *Rp${toRupiah(before)}*\n💼 Total: *Rp${toRupiah(after)}*`,
    { parse_mode: 'Markdown' }
  );
});
// =====================================================
// 📋 LIST SEMUA SALDO USER + USERNAME
// =====================================================
bot.onText(/^\/listsaldo$/i, async (msg) => {
  const fs = require("fs");
  const saldoPath = "./database/saldo.json";

  if (!fs.existsSync(saldoPath)) {
    return bot.sendMessage(msg.chat.id, "❌ Data saldo tidak ditemukan.");
  }

  const saldoData = JSON.parse(fs.readFileSync(saldoPath, "utf8"));
  const entries = Object.entries(saldoData);

  if (entries.length === 0) {
    return bot.sendMessage(msg.chat.id, "📭 Belum ada data saldo.");
  }

  let teks = `📋 *DAFTAR SALDO USER*\n\n`;

  // Loop tiap user
  for (const [id, saldo] of entries) {
    let username = "(username tidak ditemukan)";

    try {
      const userInfo = await bot.getChat(id);
      if (userInfo.username) username = `@${userInfo.username}`;
      else if (userInfo.first_name) username = userInfo.first_name;
    } catch (e) {
      // User belum pernah chat bot → username tetap '(username tidak ditemukan)'
    }

    teks += `🆔 \`${id}\`\n👤 ${username}\n💰 Rp${toRupiah(saldo)}\n\n`;
  }

  bot.sendMessage(msg.chat.id, teks, { parse_mode: "Markdown" });
});

// ===================================================
// /cvps → Create VPS DigitalOcean (Telegram Version)
// ===================================================
bot.onText(/^\/cvps(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const hostname = match[1];

    // Hanya owner
    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Hanya owner yang dapat menggunakan perintah ini!");
    }

    // Wajib isi hostname
    if (!hostname) {
        return bot.sendMessage(
            chatId,
            "⚠️ *Masukkan hostname!*\n\nContoh:\n`/cvps ndyzz-vps1`",
            { parse_mode: "Markdown" }
        );
    }

    // Siapkan session
    if (!global.cvpsSession) global.cvpsSession = {};
    global.cvpsSession[userId] = { hostname };

    // Hitung total akun DO (akun1..akun50)
    const totalAkun = Object.keys(global.apiDigitalOcean).length;

    // Buat keyboard akun DO
    let keyboard = [];
    for (let i = 1; i <= 50; i++) {
        let api = global.apiDigitalOcean[`akun${i}`];
        keyboard.push([
            {
                text: api && api.length >= 64 ? `V${i} ✅` : `V${i} ❌`,
                callback_data: `cvps_pick:${i}`
            }
        ]);
    }

    // Kirim FOTO + CAPTION + INLINE KEYBOARD
    bot.sendPhoto(chatId, config.ppdigitalocean, {
        caption:
            `📌 *Pembuatan VPS DigitalOcean*\n\n` +
            `➡️ Hostname: *${hostname}*\n` +
            `➡️ Total Akun Tersedia: *${totalAkun} akun*\n\n` +
            `Silakan pilih akun DigitalOcean yang ingin digunakan ⬇️`,
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
});
// ===============================
// CALLBACK: PILIH AKUN → KE RAM
// ===============================
bot.on("callback_query", async (cb) => {
    const data = cb.data;
    const chatId = cb.message.chat.id;
    const userId = cb.from.id.toString();

    if (!data.startsWith("cvps_pick:")) return;

    const version = data.split(":")[1];
    const hostname = global.cvpsSession?.[userId]?.hostname;

    if (!hostname) {
        return bot.answerCallbackQuery(cb.id, {
            text: "Session expired. Ulangi /cvps hostname.",
            show_alert: true
        });
    }

    const apikeyDO = global.apiDigitalOcean[`akun${version}`];
    if (!apikeyDO || apikeyDO.length < 64) {
        return bot.answerCallbackQuery(cb.id, {
            text: `API Key DigitalOcean V${version} tidak valid!`,
            show_alert: true
        });
    }

    // simpan versi
    global.cvpsSession[userId].version = version;

    bot.answerCallbackQuery(cb.id);

    // ========================
    // LIST RAM
    // ========================
    const ramCPU = [
        ["💻 RAM 1GB | CPU 1 Core", "1c1"],
        ["💻 RAM 2GB | CPU 1 Core", "2c1"],
        ["💻 RAM 2GB | CPU 2 Core", "2c2"],
        ["💻 RAM 4GB | CPU 2 Core", "4c2"],
        ["💻 RAM 8GB | CPU 4 Core", "8c4"],
        ["💻 RAM 16GB | CPU 4 Core", "16c4"],
        ["💻 RAM 16GB | CPU 8 Core", "16c8"],
        ["💻 RAM 32GB | CPU 8 Core", "32c8"]
    ];

    const keyboard = ramCPU.map(v => [{
        text: v[0],
        callback_data: `cvps_ram:${version}:${v[1]}`
    }]);

    bot.editMessageCaption(
        `🌐 *Akun DigitalOcean V${version} Dipilih!*\n\n` +
        `Hostname: *${hostname}*\n\n` +
        `Silakan pilih *RAM & CPU* yang ingin digunakan:`,
        {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        }
    );
});
// ===============================
// CALLBACK: RAM → PILIH OS
// ===============================
bot.on("callback_query", async (cb) => {
    const data = cb.data;
    const chatId = cb.message.chat.id;
    const userId = cb.from.id.toString();

    // pastikan ini callback RAM, bukan yang lain
    if (!data.startsWith("cvps_ram:")) return;

    const [, version, plan] = data.split(":");

    // simpan plan (RAM/CPU) ke session
    if (!global.cvpsSession[userId]) global.cvpsSession[userId] = {};
    global.cvpsSession[userId].plan = plan;

    const hostname = global.cvpsSession[userId]?.hostname;
    if (!hostname) {
        return bot.answerCallbackQuery(cb.id, {
            text: "Session expired! Ulangi /cvps dulu.",
            show_alert: true
        });
    }

    bot.answerCallbackQuery(cb.id);

    // ========================
    // LIST OS
    // ========================
    const osList = [
        { name: "Ubuntu 20.04", slug: "ubuntu-20-04-x64" },
        { name: "Ubuntu 22.04", slug: "ubuntu-22-04-x64" },
        { name: "Ubuntu 24.04", slug: "ubuntu-24-04-x64" },
        { name: "Ubuntu 25.04", slug: "ubuntu-25-04-x64" },
        { name: "Ubuntu 25.10", slug: "ubuntu-25-10-x64" },
        { name: "Fedora 42", slug: "fedora-42-x64" },
        { name: "Debian 12", slug: "debian-12-x64" },
        { name: "Debian 13", slug: "debian-13-x64" },
        { name: "CentOS Stream 9", slug: "centos-stream-9-x64" },
        { name: "CentOS Stream 10", slug: "centos-stream-10-x64" },
        { name: "AlmaLinux 8", slug: "almalinux-8-x64" },
        { name: "AlmaLinux 9", slug: "almalinux-9-x64" },
        { name: "AlmaLinux 10", slug: "almalinux-10-x64" },
        { name: "Rocky Linux 8", slug: "rockylinux-8-x64" },
        { name: "Rocky Linux 9", slug: "rockylinux-9-x64" },
        { name: "Rocky Linux 10", slug: "rockylinux-10-x64" }
    ];

    const keyboard = osList.map(os => [{
        text: `🔵 ${os.name}`,
        callback_data: `cvps_os:${version}:${os.slug}`
    }]);

    // edit caption
    bot.editMessageCaption(
        `💻 *RAM & CPU Dipilih:* ${plan}\n\n` +
        `Hostname: *${hostname}*\n\n` +
        `Silakan pilih *Operating System*:`,
        {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        }
    );
});
// ===============================
// CALLBACK: OS → PILIH REGION
// ===============================
bot.on("callback_query", async (cb) => {
    const data = cb.data;
    if (!data.startsWith("cvps_os:")) return;

    const chatId = cb.message.chat.id;
    const userId = cb.from.id.toString();
    bot.answerCallbackQuery(cb.id);

    // format: cvps_os:version:slugOS
    let [, version, osSlug] = data.split(":");

    // pastikan session ada
    if (!global.cvpsSession[userId])
        global.cvpsSession[userId] = {};

    // simpan OS
    global.cvpsSession[userId].os = osSlug;

    const plan = global.cvpsSession[userId].plan;
    const hostname = global.cvpsSession[userId].hostname;

    if (!plan || !hostname) {
        return bot.answerCallbackQuery(cb.id, {
            text: "Session hilang! Jalankan /cvps lagi.",
            show_alert: true
        });
    }

    // List region
    const regions = [
        ["🇸🇬 Singapore", "sgp1"],
        ["🇺🇸 New York", "nyc3"],
        ["🇺🇸 San Francisco", "sfo3"],
        ["🇳🇱 Amsterdam", "ams3"],
        ["🇬🇧 London", "lon1"],
        ["🇩🇪 Frankfurt", "fra1"],
        ["🇨🇦 Toronto", "tor1"],
        ["🇮🇳 Bangalore", "blr1"],
        ["🇦🇺 Sydney", "syd1"]
    ];

    const keyboard = regions.map(r => [{
        text: r[0],
        callback_data: `cvps_region:${version}:${osSlug}:${plan}:${r[1]}`
    }]);

    // Edit caption
    bot.editMessageCaption(
        `🌍 *Pilih Region VPS*\n\n` +
        `🖥 OS: *${osSlug}*\n` +
        `💾 Plan: *${plan}*\n` +
        `📛 Hostname: *${hostname}*\n\n` +
        `Silakan pilih region:`,
        {
            chat_id: chatId,
            message_id: cb.message.message_id,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        }
    );
});
// ====================================================================
// CALLBACK — Region dipilih → Eksekusi pembuatan VPS (Final Create)
// ====================================================================
bot.on("callback_query", async (cb) => {
    const data = cb.data;
    if (!data.startsWith("cvps_region:")) return;

    bot.answerCallbackQuery(cb.id);

    const chatId = cb.message.chat.id;
    const messageId = cb.message.message_id;
    const userId = cb.from.id.toString();

    let [, version, os, plan, region] = data.split(":");

    const hostname = global.cvpsSession[userId]?.hostname;
    if (!hostname) {
        return bot.sendMessage(chatId, "❌ Session expired. Ulangi /cvps hostname");
    }

    const apiDO = global.apiDigitalOcean[`akun${version}`];
    if (!apiDO || apiDO.length < 64) {
        return bot.sendMessage(chatId, `🚫 API Key Akun DO V${version} tidak valid!`);
    }

    const sizeMap = {
        "1c1": "s-1vcpu-1gb-amd",
        "2c1": "s-1vcpu-2gb-amd",
        "2c2": "s-2vcpu-2gb-amd",
        "4c2": "s-2vcpu-4gb-amd",
        "8c4": "s-4vcpu-8gb-amd",
        "16c4": "s-4vcpu-16gb-amd",
        "16c8": "s-8vcpu-16gb-amd",
        "32c8": "s-8vcpu-32gb-amd"
    };

    const size = sizeMap[plan];
    const password = "NDYOFFC#" + size.replace("s-", "").replace(/-/g, "").toUpperCase();

    // 🔥 EDIT CAPTION — BUKAN TEXT
    await bot.editMessageCaption(
        `⏳ *Sedang membuat VPS...*\n` +
        `Hostname: *${hostname}*\n` +
        `Region: *${region}*\n` +
        `Size: *${size}*`,
        {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown"
        }
    );

    try {
        // Create VPS
        const payload = {
            name: hostname,
            region: region,
            size: size,
            image: os,
            ipv6: true,
            backups: false,
            tags: ["Jangan Lupa Support NDyOffiCial"],
            user_data: `#cloud-config
password: ${password}
chpasswd: { expire: False }`
        };

        const resp = await fetch("https://api.digitalocean.com/v2/droplets", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiDO}`
            },
            body: JSON.stringify(payload)
        });

        const json = await resp.json();

        if (!resp.ok) {
            return bot.sendMessage(chatId, `❌ Gagal Membuat VPS:\n${JSON.stringify(json)}`);
        }

        const dropletId = json.droplet.id;

        // ⏳ Kirim pesan menunggu IP
        const waitingMsg = await bot.sendMessage(chatId, `⏳ Menunggu IP VPS (±50 detik)...`);

        await new Promise(r => setTimeout(r, 50000));

        // Ambil IP
        const cek = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
            headers: { "Authorization": `Bearer ${apiDO}` }
        });

// Ambil IP
const dropletInfo = await cek.json();
const ip = dropletInfo?.droplet?.networks?.v4?.[0]?.ip_address || "N/A";
const createdAt = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
});

// 🔥 Auto delete pesan "Menunggu IP..."
bot.deleteMessage(chatId, waitingMsg.message_id).catch(() => {});

// 🔥 Auto delete pesan FOTO + CAPTION "Sedang membuat VPS..."
bot.deleteMessage(chatId, messageId).catch(() => {});

// Kirim hasil akhir + aturan TOS & GARANSI
bot.sendMessage(
    chatId,
    `✅ *VPS BERHASIL DIBUAT!*\n` +
    `===============================\n` +    
    `🆔 *ID Droplet:* \`${dropletId}\`\n` +
    `👤 *Username:* \`root\`\n` +    
    `🌐 *IP VPS:* \`${ip}\`\n` +    
    `🔐 *Password:* \`${password}\`\n` + 
    `🖥 *Hostname:* ${hostname}\n` +
    `📀 *OS:* ${os}\n` +
    `📍 *Region:* ${region}\n` +
    `💾 *Size:* ${size}\n` +
    `⏰ *Created:* ${createdAt}\n` +
    `===============================\n` +
    `🎉 *GARANSI AKTIF 10 HARI*\n` +
    `*Apabila tidak melanggar T.O.S*\n` +
    `===============================\n\n` +
    `⚠️ *𝗧.𝗢.𝗦 VPS (Terms of Service VPS)*\n` +
    `• Dilarang Hacking\n` +
    `• Dilarang Mining (Crypto/Sejenisnya)\n` +
    `• Dilarang Torrent\n` +
    `• Dilarang Overload CPU (100% terus-menerus)\n` +
    `• Dilarang DDoS\n` +
    `• Dilarang Aktivitas Ilegal dalam bentuk apa pun\n\n` +
    `👉 *Intinya:* Gunakan VPS dengan bijak & sesuai kebutuhan normal.\n\n` +
    `===============================\n\n` +
    `🏪 *𝗧.𝗢.𝗦 TOKO (Ketentuan Garansi Toko)*\n` +
    `• Web toko down karena DDoS, tapi VPS normal → Garansi *AKTIF*\n` +
    `• VPS mati akibat DDoS → Garansi *HANGUS*\n` +
    `• VPS aktif tapi tidak bisa login (CPU 100%) → Garansi *HANGUS*\n` +
    `• Data VPS tanggung jawab pembeli → Hilang = Garansi *HANGUS*\n` +
    `• Mohon gunakan VPS sesuai aturan agar garansi tetap berlaku\n\n` +
    `===============================\n\n` +
    `📛 *𝗞𝗘𝗧𝗘𝗡𝗧𝗨𝗔𝗡 AKUN DO SUSPEND*\n` +
    `Jika akun DigitalOcean terkena suspend:\n` +
    `• Garansi hanya berlaku *2 hari* sejak pembelian\n` +
    `• Hari ke-3 dan seterusnya → Garansi *Tidak Berlaku*\n\n` +
    `===============================\n\n` +
    `📝 *SYARAT CLAIM GARANSI*\n` +
    `1. Sertakan bukti transfer\n` +
    `2. Screenshot chat saat pembelian\n` +
    `3. Cantumkan tanggal pembelian\n` +
    `4. Lampirkan data VPS (IP, Username, Password, dsb.)\n\n` +
    `===============================\n` +
    `© REAL ${config.authorName} — Hosting Since 2024\n\n` +
    `📢 *PERINGATAN:*\n` +
    `Seluruh isi & format teks ini dilindungi hukum.\n` +
    `📌 Dilarang copy-paste tanpa izin.\n` +
    `📌 Pelanggaran akan dikenakan sanksi sesuai UU Hak Cipta No. 28 Tahun 2014.\n` +
    `===============================`,
    { parse_mode: "Markdown" }
);

    } catch (err) {
        bot.sendMessage(chatId, `❌ Error Create VPS:\n${err.message}`);
    }
});
bot.onText(/^\/sisadroplet$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (userId !== config.OWNER_ID.toString())
        return bot.sendMessage(chatId, "🚫 Akses ditolak!");

    const sections = [
        {
            title: "🌐 Pilih Akun DigitalOcean",
            rows: Object.keys(global.apiDigitalOcean).map((key, index) => {
                let apiKey = global.apiDigitalOcean[key];
                return {
                    title: apiKey && apiKey.length >= 64
                        ? `V${index + 1} • READY`
                        : `V${index + 1} • INVALID`,
                    description: "Klik untuk cek sisa droplet",
                    id: `res_sisadroplet${index + 1}`
                };
            })
        }
    ];

    const buttons = [{
        buttonId: "select_do",
        buttonText: { displayText: "🔹 Pilih Akun DigitalOcean 🔹" },
        type: 4,
        nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({ title: "Pilih Akun DO", sections })
        }
    }];

    bot.sendMessage(
        chatId,
        "🌐 *Cek Sisa Droplet DigitalOcean*\nSilakan pilih akun DO.",
        {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [[{ text: "Pilih Akun", callback_data: "show_select" }]]
            }
        }
    );
});
bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;

    if (query.data === "show_select") {
        let buttons = [];

        for (let i = 1; i <= 50; i++) {
            let api = global.apiDigitalOcean[`akun${i}`];
            buttons.push([{
                text: api && api.length >= 64 ? `V${i} ✅` : `V${i} ❌`,
                callback_data: `cv_check:${i}`
            }]);
        }

        return bot.editMessageText(
            "🌐 *Pilih Akun DigitalOcean*",
            {
                chat_id: chatId,
                message_id: query.message.message_id,
                parse_mode: "Markdown",
                reply_markup: { inline_keyboard: buttons }
            }
        );
    }
// ==================================================
// AUTO HANDLER untuk res_sisadroplet1 - 50
// ==================================================
if (query.data.startsWith("cv_check:")) {
    const version = query.data.split(":")[1];
    const apiKey = global.apiDigitalOcean[`akun${version}`];

    if (!apiKey || apiKey.length < 64) {
        return bot.answerCallbackQuery(query.id, { text: "❌ API Key tidak valid!", show_alert: true });
    }

    bot.answerCallbackQuery(query.id);

    try {
        const [acc, drp] = await Promise.all([
            fetch("https://api.digitalocean.com/v2/account", {
                headers: { Authorization: `Bearer ${apiKey}` }
            }),
            fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            })
        ]);

        if (!acc.ok || !drp.ok)
            return bot.editMessageText(
                `❌ *Gagal mengambil data Akun V${version}*`,
                {
                    chat_id: query.message.chat.id,
                    message_id: query.message.message_id,
                    parse_mode: "Markdown"
                }
            );

        const accData = await acc.json();
        const drpData = await drp.json();

        const email = accData.account.email;
        const status = accData.account.status;
        const limit = accData.account.droplet_limit;
        const used = drpData.droplets.length;
        const remain = limit - used;

        // 🔥 EDIT PESAN — TIDAK NUMPUK
        return bot.editMessageText(
            `🌐 *DIGITALOCEAN STATUS*\n\n` +
            `🌟 *Akun DigitalOcean V${version}*\n` +
            `📧 *Email:* ${email}\n` +
            `📊 *Status Akun:* ${status}\n\n` +
            `🔢 *Limit Maksimal Droplet:* ${limit}\n` +
            `💎 *Sisa Droplet Tersedia:* ${remain}\n` +
            `🚀 *Total Droplet Terpakai:* ${used}`,
            {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: "Markdown"
            }
        );

    } catch (err) {
        console.log(err);
        return bot.editMessageText(
            `❌ *Error mengambil data Akun V${version}*`,
            {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                parse_mode: "Markdown"
            }
        );
    }
}
});

bot.onText(/^\/listdroplet$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (userId !== config.OWNER_ID.toString())
        return bot.sendMessage(chatId, "🚫 Akses ditolak!");


    // Tombol awal
    bot.sendMessage(
        chatId,
        "🌐 *List Droplet DigitalOcean*\nSilakan pilih akun DO.",
        {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [[{ text: "Pilih Akun", callback_data: "listdroplet_select" }]]
            }
        }
    );
});
bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const msgId = query.message.message_id;
    const data = query.data;

    // ======== STEP 1: User klik tombol "Pilih Akun" =========
    if (data === "listdroplet_select") {

        let buttons = [];

        for (let i = 1; i <= 50; i++) {
            let api = global.apiDigitalOcean[`akun${i}`];
            buttons.push([
                {
                    text: api && api.length >= 64 ? `V${i} ✅` : `V${i} ❌`,
                    callback_data: `ld_check:${i}`
                }
            ]);
        }

        return bot.editMessageText(
            "🌐 *Pilih Akun DigitalOcean*",
            {
                chat_id: chatId,
                message_id: msgId,
                parse_mode: "Markdown",
                reply_markup: { inline_keyboard: buttons }
            }
        );
    }
    // ======== STEP 2: User pilih akun DigitalOcean =========
    if (data.startsWith("ld_check:")) {
        const version = data.split(":")[1];
        const apiKey = global.apiDigitalOcean[`akun${version}`];

        if (!apiKey || apiKey.length < 64) {
            return bot.answerCallbackQuery(query.id, { 
                text: "❌ API Key tidak valid!", 
                show_alert: true 
            });
        }

        bot.answerCallbackQuery(query.id);

        try {
            const resp = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!resp.ok) {
                return bot.editMessageText(
                    `❌ *Gagal mengambil data droplet Akun V${version}*`,
                    {
                        chat_id: chatId,
                        message_id: msgId,
                        parse_mode: "Markdown"
                    }
                );
            }

            const dataDroplet = await resp.json();
            const droplets = dataDroplet.droplets || [];

            let text = `🌐 *LIST DROPLET DIGITALOCEAN*\n`;
            text += `🌟 *Akun V${version}*\n`;
            text += `📦 Total Droplet: *${droplets.length}*\n\n`;

            if (droplets.length === 0) {
                text += `🚫 Tidak ada droplet ditemukan.`;
            } else {
                droplets.forEach((d, idx) => {
                    const ip = d.networks.v4.find(net => net.type === "public")?.ip_address || "No IP";
                    text += `🔹 *Droplet ${idx + 1}*\n`;
                    text += `ID: ${d.id}\n`;
                    text += `Hostname: ${d.name}\n`;
                    text += `IP: ${ip}\n`;
                    text += `RAM: ${d.memory} MB\n`;
                    text += `CPU: ${d.vcpus} vCPU\n`;
                    text += `Disk: ${d.disk} GB\n`;
                    text += `OS: ${d.image.distribution}\n`;
                    text += `Status: ${d.status}\n\n`;
                });
            }

            return bot.editMessageText(
                text,
                {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "Markdown"
                }
            );

        } catch (e) {
            console.log(e);
            return bot.editMessageText(
                `❌ *Terjadi kesalahan saat mengambil data!*`,
                {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "Markdown"
                }
            );
        }
    }
});

// =====================================================
// 🗑 DELETE VPS (BY DROPLET ID) + KONFIRMASI BUTTON
// =====================================================
bot.onText(/^\/deldroplet(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const dropletId = match[1] ? match[1].trim() : null;
    
    if (userId !== config.OWNER_ID.toString())
        return bot.sendMessage(chatId, "❌ Kamu tidak punya akses!");

    if (!dropletId)
        return bot.sendMessage(chatId, "⚠️ Contoh:\n/deldroplet 123456789");

    let foundDroplet = null;
    let foundAkun = null;

    bot.sendMessage(chatId, "🔍 *Mencari VPS...*", { parse_mode: "Markdown" });

    // 🔎 Cari droplet di semua akun
    for (let i = 1; i <= 50; i++) {
        const apiKey = global.apiDigitalOcean[`akun${i}`];
        if (!apiKey || apiKey.length < 64) continue;

        try {
            const res = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!res.ok) continue;

            const data = await res.json();
            let d = data.droplets.find(x => x.id.toString() === dropletId);

            if (d) {
                foundDroplet = d;
                foundAkun = i;
                break;
            }

        } catch {}
    }

    if (!foundDroplet)
        return bot.sendMessage(chatId, "❌ VPS tidak ditemukan di semua akun.");

    let ip = foundDroplet.networks.v4.find(n => n.type === "public")?.ip_address || "Tidak ada";

    // === Kirim detail & tombol konfirmasi ===
    let text =
        `🗑 *HAPUS VPS?*\n\n` +
        `🆔 *ID:* ${foundDroplet.id}\n` +
        `💽 *Hostname:* ${foundDroplet.name}\n` +
        `🌐 *IP:* ${ip}\n` +
        `🧩 *Spec:* ${foundDroplet.memory}MB | ${foundDroplet.vcpus}vCPU | ${foundDroplet.disk}GB\n` +
        `🌍 *Akun DO:* V${foundAkun}\n\n` +
        `⚠️ *Aksi ini tidak bisa dibatalkan!*`;

    bot.sendMessage(chatId, text, {
        parse_mode: "Markdown",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "✅ Lanjutkan", callback_data: `delvps_yes:${foundAkun}:${foundDroplet.id}` }
                ],
                [
                    { text: "❌ Batalkan", callback_data: `delvps_no` }
                ]
            ]
        }
    });
});
// =====================================================
// 🔘 KONFIRMASI DELETE VPS
// =====================================================
bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;

    // ❌ User membatalkan
    if (query.data === "delvps_no") {
        bot.answerCallbackQuery(query.id, { text: "Dibatalkan.", show_alert: false });
        return bot.editMessageText("❌ *Penghapusan dibatalkan.*", {
            chat_id: chatId,
            message_id: query.message.message_id,
            parse_mode: "Markdown"
        });
    }

    // ✅ User setuju menghapus
    if (query.data.startsWith("delvps_yes:")) {
        let [_, akun, dropletId] = query.data.split(":");
        let apiKey = global.apiDigitalOcean[`akun${akun}`];

        bot.answerCallbackQuery(query.id, { text: "Menghapus VPS...", show_alert: false });

        try {
            const delReq = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${apiKey}`
                }
            });

            if (delReq.ok) {
                return bot.editMessageText(
                    `✅ *Droplet berhasil dihapus!*\n\n🆔 ID: *${dropletId}*\n🌍 Akun: *V${akun}*`,
                    {
                        chat_id: chatId,
                        message_id: query.message.message_id,
                        parse_mode: "Markdown"
                    }
                );
            } else {
                let err = await delReq.json();
                return bot.editMessageText(
                    `❌ Gagal menghapus VPS:\n${err.message || "Unknown error"}`,
                    {
                        chat_id: chatId,
                        message_id: query.message.message_id,
                        parse_mode: "Markdown"
                    }
                );
            }
        } catch (e) {
            return bot.sendMessage(chatId, "❌ Error memproses penghapusan VPS.");
        }
    }
});

// ==========================
// /rebuild DROPLET
// ==========================
bot.onText(/^\/rebuild(?:\s+(\d+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const dropletId = match[1];

    if (String(userId) !== String(config.OWNER_ID))
        return bot.sendMessage(chatId, "🚫 Hanya Owner!");

    if (!dropletId)
        return bot.sendMessage(chatId, "⚠️ Contoh:\n/rebuild 123456789");

    let buttons = [];

    for (let i = 1; i <= 50; i++) {
        const api = global.apiDigitalOcean[`akun${i}`];
        const status = api && api.length >= 64 ? "✅" : "❌";
        buttons.push([{
            text: `${status} Akun DO V${i}`,
            callback_data: `rb_select:${dropletId}:${i}`
        }]);
    }

    return bot.sendMessage(chatId, `🔧 Pilih akun DO untuk Rebuild *${dropletId}*`, {
        reply_markup: { inline_keyboard: buttons },
        parse_mode: "Markdown"
    });
});
// ==================================
// STEP 2 — PILIH OS UNTUK REBUILD
// ==================================
bot.on("callback_query", async (query) => {
    const data = query.data;
    const chatId = query.message.chat.id;
    const msgId = query.message.message_id;

    if (data.startsWith("rb_select")) {
        const [, dropletId, version] = data.split(":");

        const apiKey = global.apiDigitalOcean[`akun${version}`];
        if (!apiKey || apiKey.length < 64)
            return bot.answerCallbackQuery(query.id, { text: "API Key invalid!", show_alert: true });

    const osList = [
        { name: "Ubuntu 20.04", slug: "ubuntu-20-04-x64" },
        { name: "Ubuntu 22.04", slug: "ubuntu-22-04-x64" },
        { name: "Ubuntu 24.04", slug: "ubuntu-24-04-x64" },
        { name: "Ubuntu 25.04", slug: "ubuntu-25-04-x64" },
        { name: "Ubuntu 25.10", slug: "ubuntu-25-10-x64" },
        { name: "Fedora 42", slug: "fedora-42-x64" },
        { name: "Debian 12", slug: "debian-12-x64" },
        { name: "Debian 13", slug: "debian-13-x64" },
        { name: "CentOS Stream 9", slug: "centos-stream-9-x64" },
        { name: "CentOS Stream 10", slug: "centos-stream-10-x64" },
        { name: "AlmaLinux 8", slug: "almalinux-8-x64" },
        { name: "AlmaLinux 9", slug: "almalinux-9-x64" },
        { name: "AlmaLinux 10", slug: "almalinux-10-x64" },
        { name: "Rocky Linux 8", slug: "rockylinux-8-x64" },
        { name: "Rocky Linux 9", slug: "rockylinux-9-x64" },
        { name: "Rocky Linux 10", slug: "rockylinux-10-x64" }
    ];

        const keyboard = osList.map(os => [{
            text: os.name,
            callback_data: `rb_os:${dropletId}:${version}:${os.slug}`
        }]);

        return bot.editMessageReplyMarkup(
            { inline_keyboard: keyboard },
            { chat_id: chatId, message_id: msgId }
        );
    }
async function animateLoading(bot, chatId, textList, delay = 500) {
    let index = 0;
    const sent = await bot.sendMessage(chatId, textList[0], { parse_mode: "Markdown" });

    const interval = setInterval(async () => {
        index = (index + 1) % textList.length;
        try {
            await bot.editMessageText(textList[index], {
                chat_id: chatId,
                message_id: sent.message_id,
                parse_mode: "Markdown"
            });
        } catch (e) {}
    }, delay);

    return { interval, message_id: sent.message_id };
}    
// ==================================
// STEP 3 — EKSEKUSI REBUILD + ANIMASI
// ==================================
if (data.startsWith("rb_os")) {
    const [, dropletId, version, osSlug] = data.split(":");
    const apiKey = global.apiDigitalOcean[`akun${version}`];

    bot.answerCallbackQuery(query.id);

    // Hapus pesan tombol OS
    await bot.deleteMessage(chatId, msgId).catch(() => {});

    // 🔥 ANIMASI LOADING
    const frames = [
        "🔄 *Rebuild sedang diproses...*\n\n⏳ Mohon tunggu...",
        "🔄 *Rebuild sedang diproses...*\n\n⌛ Mohon tunggu...",
        "🔄 *Rebuild sedang diproses...*\n\n🌀 Mohon tunggu...",
        "🔄 *Rebuild sedang diproses...*\n\n💿 Mohon tunggu..."
    ];

    const loading = await animateLoading(bot, chatId, frames, 600);

    // Ambil ID image via slug
    const imgList = await fetch("https://api.digitalocean.com/v2/images?type=distribution", {
        headers: { Authorization: `Bearer ${apiKey}` }
    });

    const img = await imgList.json();
    const target = img.images.find(i => i.slug === osSlug);

    if (!target) {
        clearInterval(loading.interval);
        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
        return bot.sendMessage(chatId, `❌ Image slug *${osSlug}* tidak ditemukan!`, { parse_mode: "Markdown" });
    }

    const imageID = target.id;

    // 🔥 Mulai rebuild
    const rebuild = await fetch(
        `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                type: "rebuild",
                image: imageID
            })
        }
    );

    const res = await rebuild.json();

    // Ganti animasi jadi “Rebuild dimulai!”
    await bot.editMessageText(
        `🔄 *Rebuild dimulai!*\n\n🆔 ID: \`${dropletId}\`\n🌀 API: V${version}\n💿 OS: *${osSlug}*\n⚙️ Status: ${res.action.status}`,
        {
            chat_id: chatId,
            message_id: loading.message_id,
            parse_mode: "Markdown"
        }
    );

    // =======================
    // CEK IP 60 DETIK
    // =======================
    setTimeout(async () => {
        const info = await fetch(
            `https://api.digitalocean.com/v2/droplets/${dropletId}`,
            { headers: { Authorization: `Bearer ${apiKey}` } }
        );

        const vps = await info.json();
        const droplet = vps.droplet;

        const ip =
            droplet.networks.v4.find(n => n.type === "public")?.ip_address ||
            "IP belum muncul";

        // Hapus animasi
        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});

        // Kirim pesan final
        return bot.sendMessage(
            chatId,
            `🎉 *Rebuild Selesai!*\n\n🆔 ID: \`${dropletId}\`\n🌐 IP: \`${ip}\`\n💿 OS: *${droplet.image.distribution} ${droplet.image.name}*`,
            { parse_mode: "Markdown" }
        );
    }, 60000);
}
});

// ====== GANTI PASSWORD VPS ======
bot.onText(/^\/gantipwvps(?:\s+)?(.+)?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();  

    // 👑 Hanya Owner
    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Akses ditolak! Hanya owner yang bisa menggunakan perintah ini.");
    }

  // jika tanpa argumen → tampilkan tutorial
  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
📖 *Tutorial Ganti Password VPS*

Gunakan format berikut:
\`/gantipwvps ipvps|pwvps|pwbaru\`

🔑 *Keterangan:*
- \`ipvps\`   = IP Address VPS
- \`pwvps\`   = Password lama VPS
- \`pwbaru\`  = Password baru VPS yang ingin dibuat

⚡ *Contoh:*
\`/gantipwvps 123.45.67.89|oldpassword|newpassword123\`
      `.trim(),
      { parse_mode: "Markdown" }
    );
  }

  const t = match[1].split("|");
  if (t.length < 3) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\n\nGunakan contoh: `/gantipwvps ipvps|pwvps|pwbaru`",
      { parse_mode: "Markdown" }
    );
  }

  const ipvps = t[0];
  const passwd = t[1];
  const newPass = t[2];

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
  };

  const conn = new Client();

  conn
    .on("ready", () => {
      conn.exec("passwd", (err, stream) => {
        if (err) {
          conn.end();
          return bot.sendMessage(chatId, "❌ Gagal eksekusi perintah di VPS!");
        }

        stream
          .on("close", () => {
            conn.end();
          })
          .on("data", (data) => {
            console.log("STDOUT:", data.toString());
          })
          .stderr.on("data", async (data) => {
            stream.write(`${newPass}\n`);
            stream.write(`${newPass}\n`);

            if (data.toString().includes("password updated successfully")) {
              await bot.sendMessage(
                chatId,
                `
*✅ Password VPS berhasil diubah*

🔐 *Password lama:* ${passwd}
🆕 *Password baru:* ${newPass}
                `.trim(),
                { parse_mode: "Markdown" }
              );
            }
          });
      });
    })
    .on("error", (err) => {
      console.log("Connection Error:", err.message);
      bot.sendMessage(chatId, "❌ IP atau password VPS tidak valid!");
    })
    .connect(connSettings);
});
// ================================
// 🔥 RESTART VPS DIGITALOCEAN (ESTETIC FORMAT)
// ================================
bot.onText(/^\/restartvps(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const text = match[1];

    // 👑 Hanya Owner
    if (String(userId) !== String(config.OWNER_ID)) {
        return bot.sendMessage(chatId, "🚫 Akses ditolak! Hanya owner yang bisa menggunakan perintah ini.");
    }

    if (!text) {
        return bot.sendMessage(chatId, "⚠️ Contoh:\n/restartvps 123456789");
    }

    let dropletId = text.trim();
    let found = false;
    let errors = [];

    // 🔁 Loop semua akun DO 1–50
    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {

        let version = key.replace("akun", "");

        if (!apiKey || apiKey === "-" || apiKey.length < 60) continue;

        try {
            // Ambil semua droplet
            let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!response.ok) {
                errors.push(`❌ DO V${version}: API key tidak valid`);
                continue;
            }

            let data = await response.json();
            let matched = data.droplets.find(d => d.id.toString() === dropletId);

            // VPS ditemukan
            if (matched) {
                found = true;

                // Jalankan restart
                let restartResponse = await fetch(
                    `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Authorization": `Bearer ${apiKey}`
                        },
                        body: JSON.stringify({ type: "reboot" })
                    }
                );

                let restartData = await restartResponse.json();

                if (!restartResponse.ok) {
                    return bot.sendMessage(
                        chatId,
                        `❌ Gagal *restart* VPS:\n🌟 V${version}\n${restartData.message || "Unknown error"}`,
                        { parse_mode: "Markdown" }
                    );
                }

                // =======================
                // 🔥 FORMAT ESTETIK
                // =======================
                let msgSuccess = `
🛠️ *Restart VPS Berhasil Dimulai!*

🧩 *Informasi VPS*
• 🆔 ID: \`${dropletId}\`
• 🌀 API: *DigitalOcean V${version}*
• 📶 Status: *${restartData.action.status}*

⌛ *Estimasi Waktu:*
VPS akan kembali aktif dalam *45–60 detik*.

⚠️ Jika setelah 1 menit belum aktif, coba cek status droplet di panel DO.
                `.trim();

                return bot.sendMessage(chatId, msgSuccess, { parse_mode: "Markdown" });
            }

        } catch (err) {
            console.log(`Error DO V${version}:`, err);
            errors.push(`❌ DO V${version}: Tidak dapat menghubungi API`);
        }
    }

    // ❌ Tidak ditemukan di semua akun
    if (!found) {
        let msgError = `❌ VPS dengan ID *${dropletId}* tidak ditemukan di *50 akun DO*.\n`;
        if (errors.length > 0) msgError += `\n${errors.join("\n")}`;

        return bot.sendMessage(chatId, msgError, { parse_mode: "Markdown" });
    }
});
// ================================
// 💠 START / STOP VPS DIGITALOCEAN
// ================================
bot.onText(/^\/(startvps|stopvps)(?:\s+(.+))?$/i, async (msg, match) => {
    const command = match[1];
    const text = match[2];
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

  // 🛡️ Hanya Owner
  if (String(userId) !== String(config.OWNER_ID)) {
    return bot.sendMessage(
      chatId,
      "🚫 Akses ditolak!\nHanya owner utama yang dapat menggunakan perintah ini.",
      { parse_mode: "Markdown" }
    );
  }

    if (!text) {
        return bot.sendMessage(chatId, `⚠️ Contoh:\n/${command} 123456789`);
    }

    let dropletId = text.trim();
    let found = false;
    let errors = [];

    let actionType = command === "startvps" ? "power_on" : "power_off";
    let actionLabel = command === "startvps" ? "start" : "stop";

    // ===========================
    // 🔁 Loop semua akun DO (1–50)
    // ===========================
    for (const [key, apiKey] of Object.entries(global.apiDigitalOcean)) {

        let version = key.replace("akun", "");

        // API kosong / tanda "-"
        if (!apiKey || apiKey === "-" || apiKey.length < 60) continue;

        try {
            // Ambil semua droplet
            let response = await fetch("https://api.digitalocean.com/v2/droplets", {
                headers: { Authorization: `Bearer ${apiKey}` }
            });

            if (!response.ok) {
                errors.push(`❌ DO V${version}: API key tidak valid`);
                continue;
            }

            let data = await response.json();
            let matched = data.droplets.find(d => d.id.toString() === dropletId);

            if (matched) {
                found = true;

                // Eksekusi start/stop
                let actionResponse = await fetch(
                    `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Authorization": `Bearer ${apiKey}`
                        },
                        body: JSON.stringify({ type: actionType })
                    }
                );

                let actionData = await actionResponse.json();

                if (!actionResponse.ok) {
                    return bot.sendMessage(
                        chatId,
                        `❌ Gagal *${actionLabel}* VPS:\n🌟 V${version}\n${actionData.message || "Unknown error"}`,
                        { parse_mode: "Markdown" }
                    );
                }

                return bot.sendMessage(chatId,
                    `✅ *Aksi ${actionLabel} VPS dimulai!*\n\n` +
                    `📡 *Droplet ID:* ${dropletId}\n` +
                    `🌟 *Akun DO:* V${version}\n` +
                    `🔄 *Status:* ${actionData.action.status}\n\n` +
                    `⏳ Tunggu beberapa saat hingga VPS *${actionLabel === "start" ? "menyala" : "mati"}*.`,
                    { parse_mode: "Markdown" }
                );
            }

        } catch (err) {
            console.log(`Error DO V${version}:`, err);
            errors.push(`❌ DO V${version}: Gagal menghubungi API`);
        }
    }

    // ============================
    // ❌ DROPLET TIDAK DITEMUKAN
    // ============================
    if (!found) {
        let errorMsg = `❌ VPS dengan ID *${dropletId}* tidak ditemukan di akun manapun.\n`;
        if (errors.length > 0) {
            errorMsg += `\n${errors.join("\n")}`;
        }

        return bot.sendMessage(chatId, errorMsg, { parse_mode: "Markdown" });
    }
});
bot.onText(/\/installpanel(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const userId = msg.from.id.toString();  

// asu lu ya //
  if (!text) {
    return bot.sendMessage(chatId, `❗ *FORMAT SALAH*

Gunakan format:
\`/installpanel ipvps|password|domainpnl|domainnode|ramvps\`

📌 Contoh:
\`/installpanel 1.1.1.1|password123|panel.domain.com|node.domain.com|8000\`
➡️ (ramvps 8000 = 8GB)

💡 *INFO VPS YANG DIDUKUNG*
✅ Ubuntu 20.04 LTS
✅ Ubuntu 22.04 LTS
❌ Debian / CentOS tidak disarankan

⏳ Proses instalasi panel & wings memakan waktu 5–10 menit.
`, { parse_mode: "Markdown" });
  }

  const t = text.split('|');
  if (t.length < 5) {
    return bot.sendMessage(chatId, `❗ *FORMAT SALAH*

Gunakan format:
\`/installpanel ipvps,|password|domainpnl|domainnode|ramvps\`

📌 Contoh:
\`/installpanel 1.1.1.1|password123|panel.domain.com|node.domain.com|8000\`
➡️ (ramvps 8000 = 8GB)

💡 *INFO VPS YANG DIDUKUNG*
✅ Ubuntu 20.04 LTS
✅ Ubuntu 22.04 LTS
❌ Debian / CentOS tidak disarankan

⏳ Proses instalasi panel & wings memakan waktu 5–10 menit.
`, { parse_mode: "Markdown" });
  }

  const [ipvps, passwd, subdomain, domainnode, ramvps] = t;
  const connSettings = { host: ipvps, port: 22, username: "root", password: passwd };
  const password = 'admin';
  const command = 'bash <(curl -s https://pterodactyl-installer.se)';
  const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
  const conn = new Client();

  let lastMsgId = null; // simpan ID pesan terakhir

  conn.on('ready', async () => {
    if (lastMsgId) await bot.deleteMessage(chatId, lastMsgId).catch(() => {});
    const msg1 = await bot.sendMessage(chatId, `🚀 PROSES INSTALL PANEL SEDANG BERLANGSUNG, MOHON TUNGGU 5-10 MENIT`);
    lastMsgId = msg1.message_id;

    conn.exec(command, (err, stream) => {
      if (err) throw err;

      stream.on('close', async (code, signal) => {
        console.log(`Panel install stream closed: ${code}, ${signal}`);
        await bot.deleteMessage(chatId, lastMsgId).catch(() => {});
        const msg2 = await bot.sendMessage(chatId, `🛠️ PROSES INSTALL WINGS, MOHON TUNGGU 5 MENIT`);
        lastMsgId = msg2.message_id;

        installWings(conn);
      }).on('data', (data) => {
        handlePanelInstallationInput(data, stream, subdomain, password);
      }).stderr.on('data', (data) => console.log('STDERR:', data.toString()));
    });
  }).connect(connSettings);

  function installWings(conn) {
    conn.exec(commandWings, (err, stream) => {
      if (err) throw err;

      stream.on('close', async (code, signal) => {
        console.log(`Wings install stream closed: ${code}, ${signal}`);
        await bot.deleteMessage(chatId, lastMsgId).catch(() => {});
        const msg3 = await bot.sendMessage(chatId, `📡 MEMULAI CREATE NODE & LOCATION`);
        lastMsgId = msg3.message_id;

        createNode(conn);
      }).on('data', (data) => {
        handleWingsInstallationInput(data, stream, domainnode, subdomain);
      }).stderr.on('data', (data) => console.log('STDERR:', data.toString()));
    });
  }

  function createNode(conn) {
    const command = `${config.bash}`; // pastikan variabel Bash terdefinisi
    conn.exec(command, (err, stream) => {
      if (err) throw err;

      stream.on('close', async (code, signal) => {
        console.log(`Node creation stream closed: ${code}, ${signal}`);
        conn.end();

        await bot.deleteMessage(chatId, lastMsgId).catch(() => {});
        sendPanelData();
      }).on('data', (data) => {
        handleNodeCreationInput(data, stream, domainnode, ramvps);
      }).stderr.on('data', (data) => console.log('STDERR:', data.toString()));
    });
  }

  function sendPanelData() {
    bot.sendMessage(chatId, `
*Install Panel Telah Berhasil ✅*

📦 *Berikut Detail Akun Panel Kamu:*

👤 *Username:* admin  
🔐 *Password:* ${password}  
🌐 *Domain:* ${subdomain}

🧠 Silakan setting *allocation* & ambil *token node* di panel yang sudah dibuat.
━━━━━━━━━━━━━━━━━━━━━━━
⚙️ *WILZZ OFFC - DIGITAL CODE ARMORY*
━━━━━━━━━━━━━━━━━━━━━━━
`, { parse_mode: "Markdown" });
  }

  // ========== HANDLER INTERAKSI SHELL ==========
  function handlePanelInstallationInput(data, stream, subdomain, password) {
    const str = data.toString();
    if (str.includes('Input')) {
      stream.write('0\n\n\n1248\nAsia/Jakarta\nadmin@gmail.com\nadmin@gmail.com\nadmin\nadmin\nadmin\n');
      stream.write(`${password}\n`);
      stream.write(`${subdomain}\n`);
      stream.write('y\ny\ny\ny\ny\n\n1\n');
    }
    if (str.includes('Please read the Terms of Service')) stream.write('Y\n');
    console.log('Panel STDOUT:', str);
  }

  function handleWingsInstallationInput(data, stream, domainnode, subdomain) {
    const str = data.toString();
    if (str.includes('Input')) {
      stream.write('1\ny\ny\ny\n');
      stream.write(`${subdomain}\n`);
      stream.write('y\nuser\n1248\ny\n');
      stream.write(`${domainnode}\n`);
      stream.write('y\nadmin@gmail.com\ny\n');
    }
    console.log('Wings STDOUT:', str);
  }

  function handleNodeCreationInput(data, stream, domainnode, ramvps) {
    stream.write(`${config.tokeninstall}\n4\nSGP\nJangan Lupa Support WILZZ - OFFC🦅🇮🇩\n`);
    stream.write(`${domainnode}\nNODES\n${ramvps}\n${ramvps}\n1\n`);
    console.log('Node STDOUT:', data.toString());
  }
});
bot.onText(/^(\.|\#|\/)startwings(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const text = match[2];
  const reply = msg.reply_to_message;

  // 📖 Kalau tanpa argumen → kasih tutorial
  if (!text) {
    return bot.sendMessage(chatId, `
📖 *TUTORIAL START WINGS* 📖

Gunakan format:
/startwings ipvps|password|token

🔧 Contoh:
/startwings 123.45.67.89,myPassword,token-xyz-123456

➡️ Keterangan:
• ipvps   = IP VPS tujuan
• password = Password root VPS
• token    = Token konfigurasi node dari panel

⚡ Setelah berhasil, node akan otomatis terkoneksi dengan panel.
`, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
  }

  let t = text.split('|');
  if (t.length < 3) {
    return bot.sendMessage(chatId, `❌ *Format salah!*\n\nGunakan format:\n/startwings ipvps,password,token`, { parse_mode: 'Markdown' });
  }

  let ipvps = t[0].trim();
  let passwd = t[1].trim();
  let token = t[2].trim();

  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };

  const conn = new Client();

  conn.on('ready', () => {
    bot.sendMessage(chatId, '⚙️ *PROSES CONFIGURE WINGS...*', { parse_mode: 'Markdown' });

    conn.exec(`${config.bash}`, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, `❌ Terjadi error saat eksekusi command`);
        return conn.end();
      }

      stream.on('close', (code, signal) => {
        console.log('Stream closed with code ' + code + ' and signal ' + signal);
        bot.sendMessage(chatId, '✅ *SUCCESS START WINGS!*\n⚡ Silakan cek node anda 😁', { parse_mode: 'Markdown' });
        conn.end();
      }).on('data', (data) => {
        stream.write(`${config.tokeninstall}\n`);
        stream.write('3\n');
        stream.write(`${token}\n`);
        console.log('STDOUT: ' + data);
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error: ' + err);
    bot.sendMessage(chatId, '❌ Katasandi atau IP tidak valid!');
  }).connect(connSettings);
});
bot.onText(/^\/uninstallpanel(?:\s+(.*))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];

  const fromId = msg.from.id;

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}
    
  if (!text || !text.includes("|")) return bot.sendMessage(chatId, "Contoh penggunaan:\n/uninstallpanel ipvps|pwvps");

  const vpsnya = text.split("|");
  if (vpsnya.length < 2) return bot.sendMessage(chatId, "Contoh penggunaan:\n/uninstallpanel ipvps|pwvps");

  let ipvps = vpsnya[0];
  let passwd = vpsnya[1];

  
  const connSettings = {
    host: ipvps,
    port: '22',
    username: 'root',
    password: passwd
  };

  const boostmysql = `\n`;
  const command = `bash <(curl -s https://pterodactyl-installer.se)`;
  const ress = new Client();

  ress.on('ready', async () => {
    await bot.sendMessage(chatId, "Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selesai", { parse_mode: "Markdown" });

    ress.exec(command, async (err, stream) => {
      if (err) throw err;

      stream.on('close', async () => {
        ress.exec(boostmysql, async (err, stream2) => {
          if (err) throw err;
          stream2.on('close', async () => {
            await bot.sendMessage(chatId, "Berhasil *uninstall* server panel ✅", { parse_mode: "Markdown" });
          }).on('data', async (data) => {
            console.log(data.toString());
            if (data.toString().includes("Remove all MariaDB databases? [yes/no]")) {
              stream2.write("yes\n"); // atau stream2.write("yes\n")
            }
          }).stderr.on('data', (data) => {
            bot.sendMessage(chatId, 'Berhasil Uninstall Server Panel ✅');
          });
        });
      }).on('data', async (data) => {
        console.log(data.toString());
        if (data.toString().includes(`Input 0-6`)) stream.write("6\n");
        if (data.toString().includes(`(y/N)`)) stream.write("y\n");
        if (data.toString().includes(`* Choose the panel user (to skip don't input anything):`)) stream.write("\n");
        if (data.toString().includes(`* Choose the panel database (to skip don't input anything):`)) stream.write("\n");
      }).stderr.on('data', (data) => {
        bot.sendMessage(chatId, 'STDERR: ' + data.toString());
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error:', err);
    bot.sendMessage(chatId, 'Katasandi atau IP tidak valid');
  }).connect(connSettings);
});

bot.onText(/^(\.|\#|\/)createnode(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const text = match[2];
  const reply = msg.reply_to_message;

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  // 📖 Kalau tanpa argumen → kasih tutorial
  if (!text) {
    return bot.sendMessage(chatId, `
📖 *TUTORIAL CREATE NODE* 📖

Gunakan format:
/createnode ipvps|password|domainnode|ramvps

🔧 Contoh:
/createnode 123.45.67.89|myPassword|node.domain.com|8192

➡️ Keterangan:
• ipvps       = IP VPS tujuan
• password    = Password root VPS
• domainnode  = Domain untuk node (misal: node.domain.com)
• ramvps      = RAM node dalam MB (misal: 8192 = 8GB)

⚠️ Allocation & token configure masih harus ditambahkan manual.
`, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
  }

  let t = text.split('|');
  if (t.length < 4) {
    return bot.sendMessage(chatId, `❌ *Format salah!*\n\nGunakan format:\n/createnode ipvps|password|domainnode|ramvps`, { parse_mode: 'Markdown' });
  }

  let ipvps = t[0].trim();
  let passwd = t[1].trim();
  let domainnode = t[2].trim();
  let ramvps = t[3].trim();

  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };

  const command = `${config.bash}`;
  const conn = new Client();

  conn.on('ready', () => {
    bot.sendMessage(chatId, '*🚀 MEMULAI CREATE NODE & LOCATION...*', { parse_mode: 'Markdown' });

    conn.exec(command, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '❌ Terjadi kesalahan saat eksekusi perintah.');
        return conn.end();
      }

      stream.on('close', (code, signal) => {
        console.log('Stream closed with code ' + code + ' and signal ' + signal);
        bot.sendMessage(chatId, '*✅ NODE & LOCATION TELAH DITAMBAHKAN*\n⚡ Silakan tambahkan *allocation* manual & ambil token configure.', { parse_mode: 'Markdown' });
        conn.end();
      }).on('data', (data) => {
        stream.write(`${config.tokeninstall}\n`);
        stream.write('4\n');
        stream.write('SGP\n');
        stream.write('AutoCnode NDy Offc\n');
        stream.write(`${domainnode}\n`);
        stream.write('NODES\n');
        stream.write(`${ramvps}\n`);
        stream.write(`${ramvps}\n`);
        stream.write('1\n');
        console.log('STDOUT:', data.toString());
      }).stderr.on('data', (data) => {
        console.log('STDERR:', data.toString());
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error:', err);
    bot.sendMessage(chatId, '❌ Katasandi atau IP tidak valid!');
  }).connect(connSettings);
});
bot.onText(/^\/(hackbackpanel|hbpanel)(?:\s+(.*))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[2];

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  // Jika tanpa argumen
  if (!text) {
    return bot.sendMessage(
      chatId,
      `📌 *Tutorial Hackback Panel*\n\n` +
      `Gunakan perintah dengan format:\n` +
      `/hackbackpanel username@ipvps|pwvps|newuser|newpw\n\n` +
      `🔹 username@ipvps → login SSH (contoh: root@1.2.3.4)\n` +
      `🔹 pwvps → password VPS\n` +
      `🔹 newuser → username admin panel baru\n` +
      `🔹 newpw → password admin panel baru\n\n` +
      `Contoh:\n` +
      `/hackbackpanel root@123.456.789.10|passwordVPS|adminbaru|pwbaru123`,
      { parse_mode: "Markdown" }
    );
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "❌ Format salah!\nGunakan: /hackbackpanel username@ipvps|pwvps|newuser|newpw");
  }

  let t = text.split("|");
  if (t.length < 4) {
    return bot.sendMessage(chatId, "❌ Argumen kurang!\nGunakan: /hackbackpanel username@ipvps|pwvps|newuser|newpw");
  }

  let [usernameWithIp, passwd, newuser, newpw] = t;
  let [username, ipvps] = usernameWithIp.split("@");

  const connSettings = {
    host: ipvps,
    port: "22",
    username: username,
    password: passwd,
  };

  const command = `${config.bash}`;
  const ress = new Client();

  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) throw err;
      stream
        .on("close", async () => {
          let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`;
          await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
          ress.end();
        })
        .on("data", async (data) => {
          console.log(data.toString());
        })
        .stderr.on("data", (data) => {
          stream.write(`${config.tokeninstall}\n`);
          stream.write("7\n");
          stream.write(`${newuser}\n`);
          stream.write(`${newpw}\n`);
        });
    });
  })
  .on("error", (err) => {
    console.log("Connection Error: " + err);
    bot.sendMessage(chatId, "❌ Kata sandi atau IP tidak valid");
  })
  .connect(connSettings);
});

// ========== ADD GROUP ==========
bot.onText(/^\/addgcsubdo(?:\s+(-?\d+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (String(userId) !== String(config.OWNER_ID)) {
    return bot.sendMessage(chatId, '❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.');
  }

  const groupId = match[1] ? parseInt(match[1]) : (msg.chat.type !== 'private' ? chatId : null);

  if (!groupId) {
    return bot.sendMessage(chatId, '⚠️ Gunakan:\n- `/addgcsubdo -1234567890` di private chat\n- atau langsung kirim `/addgcsubdo` di dalam grup', {
      parse_mode: 'Markdown'
    });
  }

  if (!resellerdomainUsers.includes(groupId)) {
    resellerdomainUsers.push(groupId);
    saveResellerDomain();
    return bot.sendMessage(chatId, `✅ Grup *${groupId}* telah ditambahkan ke daftar yang diizinkan.`, {
      parse_mode: 'Markdown'
    });
  } else {
    return bot.sendMessage(chatId, `ℹ️ Grup *${groupId}* sudah ada di daftar.`, {
      parse_mode: 'Markdown'
    });
  }
});

// ========== DELETE GROUP ==========
bot.onText(/^\/delgcsubdo(?:\s+(-?\d+))?$/, async (msg, match) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (String(userId) !== String(config.OWNER_ID)) {
    return bot.sendMessage(chatId, '❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.');
  }

  const groupId = match[1] ? parseInt(match[1]) : (msg.chat.type !== 'private' ? chatId : null);

  if (!groupId) {
    return bot.sendMessage(chatId, '⚠️ Gunakan:\n- `/delsubgcdo -1234567890` di private chat\n- atau langsung kirim `/delsubgcdo` di dalam grup', {
      parse_mode: 'Markdown'
    });
  }

  const index = resellerdomainUsers.indexOf(groupId);
  if (index !== -1) {
    resellerdomainUsers.splice(index, 1);
    saveResellerDomain();
    return bot.sendMessage(chatId, `✅ Grup *${groupId}* telah dihapus dari daftar yang diizinkan.`, {
      parse_mode: 'Markdown'
    });
  } else {
    return bot.sendMessage(chatId, `ℹ️ Grup *${groupId}* tidak ditemukan di daftar.`, {
      parse_mode: 'Markdown'
    });
  }
});

// ========== LIST GROUP ==========
bot.onText(/^\/listgcsubdo$/, async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (String(userId) !== String(config.OWNER_ID)) {
    return bot.sendMessage(chatId, '❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.');
  }

  if (resellerdomainUsers.length === 0) {
    return bot.sendMessage(chatId, '📋 Daftar grup reseller domain masih kosong.');
  }

  let listText = '📋 *Daftar Grup Reseller Domain:*\n\n';
  resellerdomainUsers.forEach((id, index) => {
    listText += `${index + 1}. \`${id}\`\n`;
  });

  return bot.sendMessage(chatId, listText, { parse_mode: 'Markdown' });
});

// ============================= ⚙️ DOMAIN MANAGEMENT NDY OFFICIAL V4 (FINAL FIX RESPONSIF) ============================= //
const dns = require("dns");

const pathSubdo = "./database/Subdomain.js";

// ============================= 📦 AMBIL DAFTAR DOMAIN ============================= //
function getDomainList() {
  if (!fs.existsSync(pathSubdo)) return [];
  const file = fs.readFileSync(pathSubdo, "utf8");
  const regex = /"([^"]+)":\s*{\s*zone:\s*"([^"]+)",\s*apitoken:\s*"([^"]+)"\s*}/g;
  const domains = [];
  let match;
  while ((match = regex.exec(file)) !== null) {
    domains.push({
      domain: match[1],
      zone: match[2],
      apitoken: match[3]
    });
  }
  return domains;
}

// ========================= 🔍 CEK STATUS DOMAIN (CLOUDFLARE API TEST + CACHE) ========================= //
async function checkDomainStatus(domain, zone, apitoken) {
  const now = Date.now();
  if (domainStatusCache[domain] && now - domainStatusCache[domain].timestamp < cacheTTL) {
    return domainStatusCache[domain].status;
  }

  let statusEmoji = "🔴 Mati";
  const dummy = `check-${Math.random().toString(36).substring(7)}.${domain}`;

  try {
    const res = await axios.post(
      `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
      { type: "A", name: dummy, content: "1.1.1.1", ttl: 120, proxied: false },
      { headers: { Authorization: `Bearer ${apitoken}`, "Content-Type": "application/json" } }
    );

    if (res.data.success) {
      const id = res.data.result.id;
      await axios.delete(`https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${id}`, {
        headers: { Authorization: `Bearer ${apitoken}` }
      });
      statusEmoji = "🟢 Aktif";
    }
  } catch (err) {
    const msg = err.response?.data?.errors?.[0]?.message || "";
    if (msg.includes("already exists") || msg.includes("Invalid name")) {
      statusEmoji = "🟢 Aktif";
    }
  }

  domainStatusCache[domain] = { status: statusEmoji, timestamp: now };
  return statusEmoji;
}

// ========================= 🧩 PAGINATION GENERATOR ========================= //
async function generateDomainPage(page = 1) {
  const domains = getDomainList();
  const perPage = 10;
  const totalPages = Math.ceil(domains.length / perPage);
  page = Math.max(1, Math.min(page, totalPages));

  const start = (page - 1) * perPage;
  const end = start + perPage;
  const pageDomains = domains.slice(start, end);

  // 🚀 Ambil status cepat dari cache dulu, baru update di background
  const cachedStatuses = pageDomains.map(d => domainStatusCache[d.domain]?.status || "⏳ Mengecek...");

  let teks = `🌐 *DAFTAR DOMAIN TERSIMPAN*\n\n`;
  pageDomains.forEach((d, i) => {
    const status = cachedStatuses[i];
    teks += `*${start + i + 1}.* ${status} \`${d.domain}\`\n├ Zone: \`${d.zone}\`\n└ Token: \`${d.apitoken}\`\n\n`;
  });

  teks += `📄 *Halaman:* ${page}/${totalPages}\n📦 *Total Domain:* ${domains.length}\n`;
  teks += `\nGunakan perintah:\n\`/deldomain <nomor>\`\nUntuk menghapus domain tertentu.`;

  const buttons = [];
  if (page > 1) buttons.push({ text: "⬅️ Prev", callback_data: `domainpage_${page - 1}` });
  if (page < totalPages) buttons.push({ text: "Next ➡️", callback_data: `domainpage_${page + 1}` });

  // 🔄 Update status di background tanpa ganggu UI
  (async () => {
    const freshStatuses = await Promise.all(
      pageDomains.map(d => checkDomainStatus(d.domain, d.zone, d.apitoken))
    );
    // Cache otomatis update
  })();

  return { teks, buttons, page, totalPages };
}

// ========================= 🌐 /listdomain — PAGINATION RESPONSIF ========================= //
bot.onText(/^\/listdomain(?: (\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (String(userId) !== String(config.OWNER_ID))
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin menggunakan perintah ini.");

  const { teks, buttons } = await generateDomainPage(match[1] ? parseInt(match[1]) : 1);

  await bot.sendMessage(chatId, teks, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: [buttons] },
  });
});

// ========================= 🔁 CALLBACK PAGINATION (FAST REFRESH) ========================= //
bot.on("callback_query", async (cb) => {
  const data = cb.data;
  const chatId = cb.message.chat.id;
  const msgId = cb.message.message_id;

  if (!data.startsWith("domainpage_")) return;

  const page = parseInt(data.split("_")[1]);
  const { teks, buttons } = await generateDomainPage(page);

  await bot.editMessageText(teks, {
    chat_id: chatId,
    message_id: msgId,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: [buttons] },
  });

  // 🔔 Respons cepat agar tombol terasa langsung
  await bot.answerCallbackQuery(cb.id, { text: `📄 Halaman ${page}`, show_alert: false });
});
// ============================= ⚙️ /adddomain (FINAL FIX) =============================
bot.onText(/^\/adddomain(?:\s+(.*))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const fs = require("fs");

  // ========== JIKA TANPA ARGUMEN → KIRIM TUTORIAL ==========
  const input = match[1]?.trim();
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Menambahkan Domain Baru*\n\nGunakan format berikut:\n\n\`/adddomain domain|zone|apitoken\`\n\n📍 *Contoh:*\n\`/adddomain ndyofficial.my.id|a1b2c3d4e5|AbCdEfGhIjKlMnOpQrStUvWxYz1234567890\`\n\n💡 *Keterangan:*\n• domain → nama domain kamu (tanpa http/https)\n• zone → Zone ID dari Cloudflare\n• apitoken → API Token yang punya akses edit DNS`,
      { parse_mode: "Markdown" }
    );
  }

  // ========== PROCESS INPUT ==========
  const parts = input.split("|");
  if (parts.length < 3) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\n\nGunakan:\n`/adddomain domain|zone|apitoken`",
      { parse_mode: "Markdown" }
    );
  }

  let [domain, zone, apitoken] = parts.map(p => p.trim());

  // bersihkan domain dari http:// atau https://
  domain = domain.replace(/^https?:\/\//i, "").replace(/\/+$/, "");

  if (!fs.existsSync(pathSubdo)) {
    return bot.sendMessage(chatId, "❌ File `./Control/Subdomain.js` tidak ditemukan!");
  }

  try {
    // hapus cache require biar update realtime
    delete require.cache[require.resolve(pathSubdo)];
    const { domains } = require(pathSubdo);

    // cek duplikat domain
    if (domains[domain]) {
      return bot.sendMessage(chatId, `⚠️ Domain \`${domain}\` sudah ada di data!`, { parse_mode: "Markdown" });
    }

    // tambah domain baru
    domains[domain] = { zone, apitoken };

    // ========== FORMAT FILE EXACT SEPERTI ASLINYA ==========
    const formattedDomains = Object.entries(domains)
      .map(([d, v]) =>
        `    "${d}": {\n      zone: "${v.zone}",\n      apitoken: "${v.apitoken}"\n    }`
      )
      .join(",\n");

    const newContent =
`module.exports = {
  domains: {
${formattedDomains}
  }
};
`;
    fs.writeFileSync(pathSubdo, newContent, "utf8");

    // ========== RESPONSE ==========
    bot.sendMessage(
      chatId,
      `✅ *Domain berhasil ditambahkan!*\n\n🌐 Domain: \`${domain}\`\n🧩 Zone: \`${zone}\`\n🔑 Token: \`${apitoken}\``,
      { parse_mode: "Markdown" }
    );

  } catch (err) {
    console.error("❌ Error adddomain:", err);
    bot.sendMessage(chatId, "❌ Gagal menambah domain: " + err.message);
  }
});
const USERS_FILE = "./users.json";
const OWNER_ID = config.OWNER_ID.toString();

// ===============================
// BROADCAST (FORWARD MESSAGE)
// ===============================
bot.onText(/^\/broadcast$/i, async (msg) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id.toString();

  if (fromId !== OWNER_ID) {
    return bot.sendMessage(chatId, "🚫 Perintah ini hanya untuk OWNER!");
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(
      chatId,
      "❗ Gunakan dengan cara reply pesan yang ingin di-broadcast.\n\nContoh:\nReply pesan → /broadcast"
    );
  }

  let users = [];
  try {
    users = JSON.parse(fs.readFileSync(USERS_FILE));
  } catch (e) {
    return bot.sendMessage(chatId, "❌ Gagal membaca users.json");
  }

  let sukses = 0;
  let gagal = 0;

  bot.sendMessage(chatId, `📢 Broadcast dimulai ke ${users.length} user...`);

  for (const userId of users) {
    try {
      await bot.forwardMessage(
        userId,
        chatId,
        msg.reply_to_message.message_id
      );
      sukses++;
    } catch (err) {
      gagal++;
      // skip user error (blokir bot / akun mati)
    }

    // delay kecil biar aman dari FloodWait
    await new Promise(res => setTimeout(res, 50));
  }

  bot.sendMessage(chatId,
`✅ BROADCAST SELESAI

📨 Total User : ${users.length}
✅ Berhasil : ${sukses}
❌ Gagal : ${gagal}`
  );
});
// ============================= ⚙️ /deldomain =============================
bot.onText(/^\/deldomain(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const fs = require("fs");

  // hanya owner
  if (String(userId) !== String(config.OWNER_ID)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  // ambil daftar domain
  const domains = getDomainList();
  if (!domains.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada domain terdaftar.");
  }

  // jika tidak ada argumen, kirim panduan
  if (!match[1]) {
    let teks = `🗑️ *HAPUS DOMAIN*\n\nGunakan format:\n\`/deldomain <nomor>\`\n\nContoh:\n\`/deldomain 2\`\n\n📜 *Daftar Domain:*\n\n`;
    domains.forEach((d, i) => {
      teks += `*${i + 1}.* ${d.domain}\n`;
    });
    return bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
  }

  const index = parseInt(match[1]) - 1;
  if (isNaN(index) || index < 0 || index >= domains.length) {
    return bot.sendMessage(chatId, "⚠️ Nomor domain tidak valid.");
  }

  const deletedDomain = domains[index].domain;

  try {
    // hapus cache require
    delete require.cache[require.resolve(pathSubdo)];
    const { domains: currentDomains } = require(pathSubdo);

    // hapus domain dari objek
    delete currentDomains[deletedDomain];

    // buat ulang file
    const formattedDomains = Object.entries(currentDomains)
      .map(([d, v]) =>
        `    "${d}": {\n      zone: "${v.zone}",\n      apitoken: "${v.apitoken}"\n    }`
      )
      .join(",\n");

    const newContent = `module.exports = {\n  domains: {\n${formattedDomains}\n  }\n};\n`;
    fs.writeFileSync(pathSubdo, newContent, "utf8");

    bot.sendMessage(
      chatId,
      `✅ Domain \`${deletedDomain}\` berhasil dihapus dari daftar.`,
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    console.error("❌ Error deldomain:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus domain: " + err.message);
  }
});
// ========================= 🧹 /cleardomainoff — FINAL FIX FORMAT FILE ========================= //
bot.onText(/^\/cleardomainoff$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (String(userId) !== String(config.OWNER_ID))
        return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const fs = require("fs");

    // Load file
    let data;
    try {
        delete require.cache[require.resolve(pathSubdo)];
        data = require(pathSubdo);
    } catch (e) {
        return bot.sendMessage(chatId, `❌ Gagal membaca Subdomain.js:\n${e.message}`);
    }

    const domainList = Object.entries(data.domains || {}).map(([domain, info]) => ({
        domain,
        zone: info.zone,
        apitoken: info.apitoken
    }));

    if (!domainList.length)
        return bot.sendMessage(chatId, "⚠️ Tidak ada domain yang tersimpan.");

    const loading = await bot.sendMessage(chatId, "⏳ Sedang memeriksa domain...");

    let active = [];
    let dead = [];

    for (const d of domainList) {
        const status = await checkDomainStatus(d.domain, d.zone, d.apitoken);
        if (status.includes("🟢")) active.push(d);
        else dead.push(d);
    }

    try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

    // Hapus domain mati
    for (const d of dead) delete data.domains[d.domain];

    // =========================
    //  🔥 FORMAT FILE PERSIS ORIGINAL
    // =========================
    const renderDomainsFile = (domainsObj) => {
        let out = 'module.exports = {\n  domains: {\n';

        const keys = Object.keys(domainsObj);
        keys.forEach((domain, index) => {
            const info = domainsObj[domain];

            out += `    "${domain}": {\n`;
            out += `      zone: "${info.zone}",\n`;
            out += `      apitoken: "${info.apitoken}"\n`;
            out += `    }`;

            if (index !== keys.length - 1) out += ',\n';
        });

        out += '\n  }\n};';
        return out;
    };

    const finalContent = renderDomainsFile(data.domains);
    fs.writeFileSync(pathSubdo, finalContent, "utf8");

    // ========================= SEND RESULT =========================
    await bot.sendMessage(
        chatId,
        `🧹 *Pembersihan Selesai!*\n\n🟢 Aktif: ${active.length}\n🔴 Dihapus: ${dead.length}\n\n📦 File Subdomain.js berhasil diperbarui.`,
        { parse_mode: "Markdown" }
    );

    if (dead.length) {
        const listDead = dead.map((d, i) => `${i + 1}. ${d.domain}`).join("\n");
        await bot.sendMessage(
            config.OWNER_ID,
            `🧾 *Domain mati yang dihapus:*\n\n${listDead}`,
            { parse_mode: "Markdown" }
        );
    }
});
// 🧠 Memory
let pendingD1 = {};
let msgIdInstruction = {};
const domainStatusCache = {};
const cacheTTL = 10 * 60 * 1000;

// === COMMAND INSTALL STELLAR THEME (ZERO-HIROO VERSION - FINAL FIX + AUTO TUTOR) ===
bot.onText(/^\/(?:installstellar|instaltemastellar)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd;

  // === [1] Jika tidak ada argumen, tampilkan tutor dulu ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Stellar (Zero-Hiroo):\n\`/installstellar ip|password\`\n\n🧩 *Contoh:*\n\`/installstellar 1.2.3.4|root123\`\n\nSetelah itu, kamu cukup jalankan:\n\`/installstellar\`\nuntuk menggunakan VPS terakhir yang sudah disimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Validasi format argumen ===
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\n\nGunakan format:\n`/installstellar ip|password`\n\nContoh:\n`/installstellar 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  // === [3] Parsing IP dan Password ===
  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!\nGunakan format: `/installstellar ip|password`", {
      parse_mode: "Markdown",
    });
  }

  // Simpan data global agar bisa dipakai ulang nanti
  global.installtema = { vps: ipvps, pwvps: passwd };

  // === [4] Cek port jika user menggunakan ip:port ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port: port,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Zero-Hiroo/Autoinstall-/refs/heads/main/bangkai.sh)`;
  const ress = new Client();

  // === [5] Notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Stellar (Zero-Hiroo) Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [6] Eksekusi SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch (e) {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Stellar (Zero-Hiroo) Pterodactyl!*", { parse_mode: "Markdown" });
          ress.end();
        })
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Input otomatis sesuai urutan skrip Zero-Hiroo
            stream.write("1\n");   // Pilih menu utama
            stream.write("1\n");   // Pilih opsi Stellar
            stream.write("yes\n"); // Konfirmasi
            stream.write("x\n");   // Keluar
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [7] Error handling ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch (e) {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [8] Koneksi ke server ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND INSTALL BILLING THEME (ZERO-HIROO VERSION - FINAL FIX + AUTO TUTOR) ===
bot.onText(/^\/(?:installbilling|instaltemabiling)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd;

  // === [1] Jika tidak ada argumen, tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Billing (Zero-Hiroo):\n\`/installbilling ip|password\`\n\n🧩 *Contoh:*\n\`/installbilling 1.2.3.4|root123\`\n\nSetelah itu, kamu cukup jalankan:\n\`/installbilling\`\nuntuk menggunakan VPS terakhir yang sudah disimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Validasi format argumen ===
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\n\nGunakan format:\n`/installbilling ip|password`\n\nContoh:\n`/installbilling 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  // === [3] Parsing IP & Password ===
  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!\nGunakan format: `/installbilling ip|password`", {
      parse_mode: "Markdown",
    });
  }

  // Simpan ke global agar bisa dipakai ulang nanti tanpa argumen
  global.installtema = { vps: ipvps, pwvps: passwd };

  // === [4] Cek jika ada port (contoh: 1.2.3.4:2222) ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port: port,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Zero-Hiroo/Autoinstall-/refs/heads/main/bangkai.sh)`;
  const ress = new Client();

  // === [5] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Billing (Zero-Hiroo) Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [6] Jalankan SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch (e) {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      // Saat SSH kirim output
      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Input otomatis sesuai urutan skrip Zero-Hiroo
            stream.write("1\n");   // Menu utama
            stream.write("2\n");   // Pilih Billing
            stream.write("yes\n"); // Konfirmasi
            stream.write("x\n");   // Keluar
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Billing (Zero-Hiroo) Pterodactyl!*", { parse_mode: "Markdown" });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [7] Error handler ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch (e) {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [8] Koneksi SSH ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND INSTALL ENIGMA THEME PTERODACTYL (FINAL FIX + TUTOR) ===
bot.onText(/^\/(?:installenigma|installtemaenigma|instaltemaenigma)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  // Default / fallback data
  const DEFAULT_PHONE = "6285668739544";
  const DEFAULT_GROUP = "https://chat.whatsapp.com/Dw36iXWxe1Q2QSjZ2PnnlW?mode=wwc";
  const DEFAULT_CHANNEL = "https://whatsapp.com/channel/0029Vb6HVf08PgsPGd7ejr0x";

  let ipvps, passwd, phone, groupLink, channelLink;

  // === [1] Jika tidak ada argumen → tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Enigma:\n\`/installenigma ip|password|nomor|linkGroup|linkChannel\`\n\n🧩 *Contoh:*\n\`/installenigma 1.2.3.4|root123|628123456789|https://chat.whatsapp.com/abc|https://whatsapp.com/channel/xyz\`\n\nSetelah itu, kamu cukup jalankan:\n\`/installenigma\`\nuntuk memakai data VPS terakhir yang sudah disimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Parsing argumen ===
  const parts = input.split("|").map(p => p.trim());
  if (parts.length < 2) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan format: `/installenigma ip|password|nomor|linkGroup|linkChannel`\n\nMinimal: `/installenigma ip|password`",
      { parse_mode: "Markdown" }
    );
  }

  ipvps = parts[0];
  passwd = parts[1];
  phone = parts[2] || DEFAULT_PHONE;
  groupLink = parts[3] || DEFAULT_GROUP;
  channelLink = parts[4] || DEFAULT_CHANNEL;

  // Simpan data ke global
  global.installtema = { vps: ipvps, pwvps: passwd, phone, group: groupLink, channel: channelLink };

  // === [3] Normalisasi nomor agar diawali "62" ===
  try {
    let digits = phone.replace(/\D+/g, "");
    if (digits.startsWith("0")) digits = "62" + digits.slice(1);
    else if (digits.startsWith("+")) digits = digits.replace(/^\+/, "");
    else if (digits.startsWith("8")) digits = "62" + digits;
    else if (!digits.startsWith("62")) digits = "62" + digits;
    phone = digits;
  } catch {
    phone = DEFAULT_PHONE;
  }

  // === [4] Parsing port (jika ada ip:port) ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = { host: ipvps, port, username: "root", password: passwd };
  const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
  const ress = new Client();

  // === [5] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Enigma (Skyzo) Pterodactyl...*\n\n📡 IP: \`${ipvps}:${port}\`\n📱 WA: \`https://wa.me/${phone}\`\n👥 Group: \`${groupLink}\`\n📢 Channel: \`${channelLink}\`\n\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [6] Jalankan koneksi SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Urutan input skrip Enigma Skyzo
            stream.write("skyzodev\n"); // Token key
            stream.write("1\n");        // Pilih menu
            stream.write("3\n");        // Pilih Enigma
            stream.write(`https://wa.me/${phone}\n`);  // Nomor WA
            stream.write(`${groupLink}\n`);            // Link grup
            stream.write(`${channelLink}\n`);          // Link channel
            stream.write("yes\n");      // Konfirmasi
            stream.write("x\n");        // Exit
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Enigma (Skyzo) Pterodactyl!*", { parse_mode: "Markdown" });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [7] Error handler koneksi ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [8] Jalankan koneksi SSH ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND INSTALL NIGHTCORE THEME PTERODACTYL (FINAL FIX + TUTOR) ===
bot.onText(/^\/(?:installnightcore|installtemanightcore|installnighcore)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd;

  // === [1] Jika tidak ada argumen → tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Nightcore:\n\`/installnightcore ip|password\`\n\n🧩 *Contoh:*\n\`/installnightcore 1.2.3.4|root123\`\n\nSetelah itu, kamu cukup jalankan:\n\`/installnightcore\`\nuntuk memakai VPS terakhir yang sudah disimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Parsing argumen ===
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan format: `/installnightcore ip|password`\n\nContoh: `/installnightcore 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!", {
      parse_mode: "Markdown",
    });
  }

  // Simpan ke global agar bisa digunakan ulang
  global.installtema = { vps: ipvps, pwvps: passwd };

  // === [3] Parsing port (jika ada ip:port) ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd,
    readyTimeout: 20000,
  };

  const command = "bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)";
  const ress = new Client();

  // === [4] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Nightcore Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [5] Jalankan SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Urutan input otomatis sesuai script Nightcore
            stream.write("1C\n");
            stream.write("y\n");
            stream.write("yes\n");
            stream.write("y\n");
            stream.write("\n");
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Nightcore Pterodactyl!*", {
            parse_mode: "Markdown",
          });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [6] Jika koneksi SSH gagal ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [7] Jalankan koneksi ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND INSTALL ELYSIUM THEME (NDy Official - FINAL FIX + TUTOR) ===
bot.onText(/^\/(?:installelysium|installtemaelysium)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd;

  // === [1] Jika tanpa argumen → tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Elysium (NDy Official):\n\`/installelysium ip|password\`\n\n🧩 *Contoh:*\n\`/installelysium 1.2.3.4|root123\`\n\nSetelah itu, kamu cukup jalankan:\n\`/installelysium\`\nuntuk menggunakan VPS terakhir yang sudah disimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Parsing argumen ===
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan format: `/installelysium ip|password`\n\nContoh: `/installelysium 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!", { parse_mode: "Markdown" });
  }

  // Simpan agar bisa dipakai ulang tanpa argumen
  global.installtema = { vps: ipvps, pwvps: passwd };

  // === [3] Cek jika user menyertakan port ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Kelaoffc/Ndyoffc/refs/heads/main/installndyoffc.sh)`;
  const ress = new Client();

  // === [4] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Elysium (NDy Official) Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [5] Jalankan koneksi SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Urutan input otomatis sesuai skrip NDy
            stream.write("metrickpack2\n"); // Token key
            stream.write("1\n");             // Pilih menu utama
            stream.write("y\n");             // Konfirmasi
            stream.write("yes\n");           // Persetujuan
            stream.write("23\n");            // Selesai / keluar
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Elysium (NDy Official)!*", {
            parse_mode: "Markdown",
          });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [6] Jika koneksi gagal ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [7] Jalankan koneksi ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND INSTALL NOOK THEME (NDy Official - FINAL FIX + TUTOR) ===
bot.onText(/^\/(?:installnook|installtemanook)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd;

  // === [1] Jika tanpa argumen → tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Nook (NDy Official):\n\`/installnook ip|password\`\n\n🧩 *Contoh:*\n\`/installnook 1.2.3.4|root123\`\n\nSetelah itu, kamu cukup jalankan:\n\`/installnook\`\nuntuk menggunakan VPS terakhir yang sudah disimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Parsing argumen ===
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan format: `/installnook ip|password`\n\nContoh: `/installnook 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!", { parse_mode: "Markdown" });
  }

  // Simpan agar bisa dipakai ulang tanpa argumen
  global.installtema = { vps: ipvps, pwvps: passwd };

  // === [3] Cek jika user menyertakan port ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Kelaoffc/Ndyoffc/refs/heads/main/installndyoffc.sh)`;
  const ress = new Client();

  // === [4] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Nook (NDy Official) Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [5] Jalankan koneksi SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Input otomatis sesuai urutan skrip NDy
            stream.write("metrickpack2\n"); // Token NDy
            stream.write("21\n");            // Pilih kategori Nook
            stream.write("yes\n");           // Konfirmasi
            stream.write("y\n");             // Konfirmasi lagi
            stream.write("yes\n");           // Persetujuan
            stream.write("23\n");            // Keluar
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Nook (NDy Official)!*", {
            parse_mode: "Markdown",
          });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [6] Jika koneksi gagal ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [7] Jalankan koneksi ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND INSTALL WALLPAPER THEME (NDy Official - FINAL FIX + TUTOR) ===
bot.onText(/^\/(?:installwallpaper|installtemawallpaper)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd, linkWallpaper;

  // === [1] Jika tanpa argumen → tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menginstall tema Wallpaper (NDy Official):\n\`/installwallpaper ip|password|linkWallpaper\`\n\n🧩 *Contoh:*\n\`/installwallpaper 1.2.3.4|root123|https://files.catbox.moe/7rprsx.jpg\`\n\n💡 Jika link wallpaper dikosongkan, akan menggunakan default wallpaper NDy.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Parsing argumen ===
  const parts = input.split("|").map(p => p.trim());
  if (parts.length < 2) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan format: `/installwallpaper ip|password|linkWallpaper`\n\nContoh:\n`/installwallpaper 1.2.3.4|root123|https://files.catbox.moe/7rprsx.jpg`",
      { parse_mode: "Markdown" }
    );
  }

  ipvps = parts[0];
  passwd = parts[1];
  linkWallpaper = parts[2] || "https://files.catbox.moe/7rprsx.jpg";

  if (!ipvps || !passwd)
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!", { parse_mode: "Markdown" });

  // Simpan global agar bisa dipakai ulang tanpa argumen
  global.installtema = { vps: ipvps, pwvps: passwd, wallpaper: linkWallpaper };

  // === [3] Cek jika ada port (contoh: 1.2.3.4:2222) ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Kelaoffc/Ndyoffc/refs/heads/main/installndyoffc.sh)`;
  const ress = new Client();

  // === [4] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses install tema Wallpaper (NDy Official) Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n🖼️ Wallpaper: ${linkWallpaper}\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [5] Jalankan koneksi SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Input otomatis ke skrip NDy
            stream.write("metrickpack2\n");   // Token key NDy
            stream.write("4\n");               // Pilih menu Wallpaper
            stream.write(`${linkWallpaper}\n`); // Link wallpaper
            stream.write("23\n");              // Keluar setelah selesai
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil install tema Wallpaper (NDy Official)!*", {
            parse_mode: "Markdown",
          });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [6] Handle koneksi gagal ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "❌ Koneksi SSH gagal — periksa IP, port, atau password!");
  });

  // === [7] Jalankan koneksi ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// === COMMAND UNINSTALL THEME PTERODACTYL (FINAL FIX + TUTOR) ===
bot.onText(/^\/(?:uninstalltema|uninstaltema|uninstalltemaptero)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = (match[1] || "").trim();

// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  let ipvps, passwd;

  // === [1] Jika tanpa argumen → tampilkan tutor ===
  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Penggunaan:*\n\nGunakan format berikut untuk menghapus tema Pterodactyl:\n\`/uninstalltema ip|password\`\n\n🧩 *Contoh:*\n\`/uninstalltema 1.2.3.4|root123\`\n\n💡 Setelah dijalankan sekali, kamu bisa cukup ketik:\n\`/uninstalltema\`\nuntuk menggunakan data VPS terakhir yang tersimpan.`,
      { parse_mode: "Markdown" }
    );
  }

  // === [2] Parsing argumen ===
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan format: `/uninstalltema ip|password`\n\nContoh:\n`/uninstalltema 1.2.3.4|root123`",
      { parse_mode: "Markdown" }
    );
  }

  const [ip, pw] = input.split("|");
  ipvps = ip.trim();
  passwd = pw.trim();

  if (!ipvps || !passwd)
    return bot.sendMessage(chatId, "⚠️ IP atau Password tidak boleh kosong!", { parse_mode: "Markdown" });

  // Simpan ke global agar bisa dipakai lagi
  global.uninstaller = { vps: ipvps, pwvps: passwd };

  // === [3] Cek jika ada port (contoh: 1.2.3.4:2222) ===
  let port = 22;
  if (ipvps.includes(":")) {
    const [host, portNum] = ipvps.split(":");
    ipvps = host;
    port = parseInt(portNum, 10) || 22;
  }

  const connSettings = {
    host: ipvps,
    port,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Zero-Hiroo/Autoinstall-/refs/heads/main/bangkai.sh)`;
  const ress = new Client();

  // === [4] Kirim notifikasi awal ===
  await bot.sendMessage(
    chatId,
    `🌀 *Memproses uninstall tema Pterodactyl...*\n📡 IP: \`${ipvps}:${port}\`\n⏳ Tunggu 1–10 menit hingga proses selesai...`,
    { parse_mode: "Markdown" }
  );

  // === [5] Jalankan koneksi SSH ===
  ress.on("ready", () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        console.error("SSH exec error:", err);
        try { ress.end(); } catch {}
        return bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di server.");
      }

      stream
        .on("data", (data) => {
          console.log(`[${ipvps}] ${data.toString()}`);
          try {
            // Input otomatis ke skrip uninstall
            stream.write("2\n"); // Pilih menu uninstall
            stream.write("y\n"); // Konfirmasi
            stream.write("x\n"); // Keluar
          } catch (e) {
            console.log("Write error:", e);
          }
        })
        .on("close", async () => {
          await bot.sendMessage(chatId, "✅ *Berhasil uninstall tema Pterodactyl!*", {
            parse_mode: "Markdown",
          });
          ress.end();
        })
        .stderr.on("data", (data) => console.log(`[STDERR ${ipvps}] ${data.toString()}`));
    });
  });

  // === [6] Handle koneksi gagal ===
  ress.on("error", (err) => {
    console.error("Connection Error:", err);
    try { ress.end(); } catch {}
    bot.sendMessage(chatId, "❌ Gagal terhubung ke VPS.\nPeriksa IP, port, atau password!");
  });

  // === [7] Jalankan koneksi ===
  try {
    ress.connect(connSettings);
  } catch (e) {
    console.error("SSH connect error:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba koneksi ke VPS!");
  }
});

// ========================= 🔐 LOGIN & LOGOUT VPS (HANYA 1 VPS PER USER) =========================
const { NodeSSH } = require("node-ssh");
const ssh = new NodeSSH();

const sessionFile = path.join(__dirname, "vpsSessions.json.enc");
const ENCRYPT_KEY = "ndyzz-protect-key"; // Ganti dengan key unik kamu (min 16 karakter)
let sessions = {};

// ========================= 🔒 ENKRIPSI / DEKRIPSI =========================
function encrypt(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(
    "aes-256-cbc",
    Buffer.from(ENCRYPT_KEY.padEnd(32)),
    iv
  );
  let encrypted = cipher.update(text, "utf8", "hex");
  encrypted += cipher.final("hex");
  return iv.toString("hex") + ":" + encrypted;
}

function decrypt(text) {
  const [ivHex, encrypted] = text.split(":");
  const iv = Buffer.from(ivHex, "hex");
  const decipher = crypto.createDecipheriv(
    "aes-256-cbc",
    Buffer.from(ENCRYPT_KEY.padEnd(32)),
    iv
  );
  let decrypted = decipher.update(encrypted, "hex", "utf8");
  decrypted += decipher.final("utf8");
  return decrypted;
}

// ========================= 📂 MUAT SESI DARI FILE =========================
if (fs.existsSync(sessionFile)) {
  try {
    const data = fs.readFileSync(sessionFile, "utf8");
    sessions = JSON.parse(decrypt(data));
    console.log("🟢 VPS session loaded:", Object.keys(sessions).length, "user(s)");
  } catch (e) {
    console.error("⚠️ Gagal memuat sesi terenkripsi:", e.message);
  }
}

// ========================= 💾 SIMPAN SESI =========================
function saveSessions() {
  try {
    const encrypted = encrypt(JSON.stringify(sessions));
    fs.writeFileSync(sessionFile, encrypted, "utf8");
  } catch (e) {
    console.error("❌ Gagal menyimpan sesi VPS:", e.message);
  }
}

// ========================= 🔐 COMMAND LOGIN VPS (HANYA 1 VPS SAJA PER USER) =========================
bot.onText(/^\/(loginvps|sftp)(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const input = match[2]?.trim();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!input) {
    return bot.sendMessage(
      chatId,
      `📘 *Cara Login VPS / SFTP*\n\nGunakan format:\n\`/loginvps ip|password|port(optional)\`\n\n🧩 *Contoh:*\n\`/loginvps 123.45.67.89|mypassword|22\`\n\nSetelah login, kamu bisa pakai:\n\`/protect1\` untuk proteksi panel.`,
      { parse_mode: "Markdown" }
    );
  }

  // Cek apakah user sudah login ke VPS lain
  if (sessions[userId]) {
    const { host } = sessions[userId];
    return bot.sendMessage(
      chatId,
      `⚠️ Kamu sudah login ke VPS:\n\n🌐 \`${host}\`\n\nKetik /logoutvps dulu sebelum login ke VPS lain.`,
      { parse_mode: "Markdown" }
    );
  }

  const [ip, password, portRaw] = input.split("|").map((v) => v.trim());
  const port = portRaw ? parseInt(portRaw) : 22;

  if (!ip || !password) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/loginvps ip|password|port(optional)`\n\nContoh:\n`/loginvps 123.45.67.89|mypassword|22`",
      { parse_mode: "Markdown" }
    );
  }

  bot.sendMessage(chatId, "🔌 Menghubungkan ke VPS, tunggu sebentar...");

  try {
    await ssh.connect({ host: ip, username: "root", password, port });
    ssh.dispose();

    // Simpan 1 sesi saja per user
    sessions[userId] = { host: ip, username: "root", password, port };
    saveSessions();

    await bot.sendMessage(
      chatId,
      `✅ *Login Berhasil!*\n\n🌐 IP: \`${ip}\`\n👤 User: root\n🔑 Password: \`${password}\`\n📦 Port: ${port}\n\nSekarang kamu bisa gunakan perintah:\n\`/protect1\` untuk aktifkan proteksi panel.`,
      { parse_mode: "Markdown" }
    );

    console.log(`🟢 ${userId} berhasil login ke VPS ${ip}`);
  } catch (err) {
    console.error("❌ LOGIN VPS ERROR:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal login ke VPS.\nPeriksa IP dan password kamu.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});

// ========================= 🚪 COMMAND LOGOUT VPS =========================
bot.onText(/^\/(logoutvps|logoutsftp)$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!sessions[userId]) {
    return bot.sendMessage(chatId, "⚠️ Kamu belum login ke VPS mana pun.", {
      parse_mode: "Markdown",
    });
  }

  const target = sessions[userId];
  delete sessions[userId];
  saveSessions();

  await bot.sendMessage(
    chatId,
    `✅ *Logout Berhasil!*\n\n🌐 IP: \`${target.host}\`\n🔑 Password: \`${target.password}\`\n\nKamu bisa login lagi dengan perintah:\n\`/loginvps ip|password\``,
    { parse_mode: "Markdown" }
  );

  console.log(`🔴 ${userId} logout dari VPS ${target.host}`);
});
// ========================= ⚙️ INSTALL PROTECT ALL (PROTECT1–15 SEKALIGUS) =========================
bot.onText(/^\/installprotect1$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  await bot.sendMessage(chatId, "🧩 *Memulai instalasi semua proteksi 1...*\nHarap tunggu beberapa saat ⏳", {
    parse_mode: "Markdown",
  });

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    // ========================= PATHS =========================
    const protectFiles = [
      {
        name: "PROTECT1 (Anti Intip Server In Settings)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Nest;
use Pterodactyl\\Models\\Location;
use Spatie\\QueryBuilder\\QueryBuilder;
use Spatie\\QueryBuilder\\AllowedFilter;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Models\\Filters\\AdminServerFilter;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;

class ServerController extends Controller
{
    /**
     * Konstruktor
     */
    public function __construct(private ViewFactory $view)
    {
    }

/**
 * 📋 Daftar server — hanya tampilkan milik sendiri kecuali admin ID 1
 */
public function index(Request $request): View
{
    $user = Auth::user();

    // Ambil query dasar
$query = Server::query()
    ->with(['node', 'user', 'allocation'])
    ->orderBy('id', 'asc'); // server baru di bawah

    // NDyProtect v1.5 — Batasi query utama
    if ($user->id !== 1) {
        $query->where('owner_id', $user->id);
    }

    // Gunakan QueryBuilder tapi tetap batasi hasil user
    $servers = QueryBuilder::for($query)
        ->allowedFilters([
            AllowedFilter::exact('owner_id'),
            AllowedFilter::custom('*', new AdminServerFilter()),
        ])
        ->when($request->has('filter') && isset($request->filter['search']), function ($q) use ($request) {
            $search = $request->filter['search'];
            $q->where(function ($sub) use ($search) {
                $sub->where('name', 'like', "%{$search}%")
                    ->orWhere('uuidShort', 'like', "%{$search}%")
                    ->orWhere('uuid', 'like', "%{$search}%");
            });
        })
        ->paginate(config('pterodactyl.paginate.admin.servers'))
        ->appends($request->query());

    return $this->view->make('admin.servers.index', ['servers' => $servers]);
}

    /**
     * 🧱 Form buat server baru
     */
    public function create(): View
    {
        $user = Auth::user();

        if ($user->id === 1) {
            // Admin ID 1 bisa pilih owner siapa pun
            $users = User::all();
            $lock_owner = false;
            $auto_owner = null;
        } else {
            // User biasa hanya bisa membuat server untuk dirinya sendiri
            $users = collect([$user]);
            $lock_owner = true;
            $auto_owner = $user;
        }

        return $this->view->make('admin.servers.new', [
            'users' => $users,
            'lock_owner' => $lock_owner,
            'auto_owner' => $auto_owner,
            'locations' => Location::with('nodes')->get(),
            'nests' => Nest::with('eggs')->get(),
        ]);
    }

    /**
     * 🔍 Detail/Edit Server — hanya pemilik server atau admin ID 1
     */
    public function view(Server $server): View
    {
        $user = Auth::user();

        if ($user->id !== 1 && $server->owner_id !== $user->id) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat melihat atau mengedit server ini! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.servers.view', ['server' => $server]);
    }

    /**
     * 🛠 Update Server — hanya pemilik server atau admin ID 1
     */
    public function update(Request $request, Server $server)
    {
        $user = Auth::user();

        if ($user->id !== 1 && $server->owner_id !== $user->id) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat mengubah server ini! ©Protect By @wilzzofficial.');
        }

        // Lindungi agar user biasa tidak bisa ubah owner_id
        $data = $request->except(['owner_id']);

        $server->update($data);

        return redirect()->route('admin.servers.view', $server->id)
            ->with('success', '✅ Server berhasil diperbarui.');
    }

    /**
     * ❌ Hapus Server — hanya Admin ID 1
     */
    public function destroy(Server $server)
    {
        $user = Auth::user();

        if ($user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat menghapus server ini! ©Protect By @wilzzofficial.');
        }

        $server->delete();

        return redirect()->route('admin.servers')
            ->with('success', '🗑️ Server berhasil dihapus.');
    }
}`
      },
      {
        name: "PROTECT1 (Otomatis Isi Server Owner)",
        path: "/var/www/pterodactyl/resources/views/admin/servers/new.blade.php",
        file: "new.blade.php",
        code: `@extends('layouts.admin')

@section('title')
    New Server
@endsection

@section('content-header')
    <h1>Create Server<small>Add a new server to the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.servers') }}">Servers</a></li>
        <li class="active">Create Server</li>
    </ol>
@endsection

@section('content')
<form action="{{ route('admin.servers.new') }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Core Details</h3>
                </div>

                <div class="box-body row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pName">Server Name</label>
                            <input type="text" class="form-control" id="pName" name="name" value="{{ old('name') }}" placeholder="Server Name">
                            <p class="small text-muted no-margin">Character limits: <code>a-z A-Z 0-9 _ - .</code> and <code>[Space]</code>.</p>
                        </div>

<div class="form-group">
    <label for="pUserId">Server Owner</label>

    @if(Auth::user()->id == 1)
        {{-- Admin ID 1: bisa isi manual --}}
        <select id="pUserId" name="owner_id" class="form-control">
            <option value="">Select a User</option>
            @foreach(\\Pterodactyl\\Models\\User::all() as $user)
                <option value="{{ $user->id }}" @selected(old('owner_id') == $user->id)>
                    {{ $user->username }} ({{ $user->email }})
                </option>
            @endforeach
        </select>
        <p class="small text-muted no-margin">As admin, you can manually choose the server owner.</p>
    @else
        {{-- Selain admin ID 1: otomatis --}}
        <input type="hidden" id="pUserId" name="owner_id" value="{{ Auth::user()->id }}">
        <input type="text" class="form-control" value="{{ Auth::user()->email }}" disabled>
        <p class="small text-muted no-margin">This server will be owned by your account automatically.</p>
    @endif
</div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pDescription" class="control-label">Server Description</label>
                            <textarea id="pDescription" name="description" rows="3" class="form-control">{{ old('description') }}</textarea>
                            <p class="text-muted small">A brief description of this server.</p>
                        </div>

                        <div class="form-group">
                            <div class="checkbox checkbox-primary no-margin-bottom">
                                <input id="pStartOnCreation" name="start_on_completion" type="checkbox" {{ \\Pterodactyl\\Helpers\\Utilities::checked('start_on_completion', 1) }} />
                                <label for="pStartOnCreation" class="strong">Start Server when Installed</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Allocation Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-sm-4">
                        <label for="pNodeId">Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->long }} ({{ $location->short }})">
                                @foreach($location->nodes as $node)

                                <option value="{{ $node->id }}"
                                    @if($location->id === old('location_id')) selected @endif
                                >{{ $node->name }}</option>

                                @endforeach
                                </optgroup>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">The node which this server will be deployed to.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocation">Default Allocation</label>
                        <select id="pAllocation" name="allocation_id" class="form-control"></select>
                        <p class="small text-muted no-margin">The main allocation that will be assigned to this server.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocationAdditional">Additional Allocation(s)</label>
                        <select id="pAllocationAdditional" name="allocation_additional[]" class="form-control" multiple></select>
                        <p class="small text-muted no-margin">Additional allocations to assign to this server on creation.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Application Feature Limits</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDatabaseLimit" class="control-label">Database Limit</label>
                        <div>
                            <input type="text" id="pDatabaseLimit" name="database_limit" class="form-control" value="{{ old('database_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of databases a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pAllocationLimit" class="control-label">Allocation Limit</label>
                        <div>
                            <input type="text" id="pAllocationLimit" name="allocation_limit" class="form-control" value="{{ old('allocation_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of allocations a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pBackupLimit" class="control-label">Backup Limit</label>
                        <div>
                            <input type="text" id="pBackupLimit" name="backup_limit" class="form-control" value="{{ old('backup_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of backups that can be created for this server.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Resource Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pCPU">CPU Limit</label>

                        <div class="input-group">
                            <input type="text" id="pCPU" name="cpu" class="form-control" value="{{ old('cpu', 0) }}" />
                            <span class="input-group-addon">%</span>
                        </div>

                        <p class="text-muted small">If you do not want to limit CPU usage, set the value to <code>0</code>. To determine a value, take the number of threads and multiply it by 100. For example, on a quad core system without hyperthreading <code>(4 * 100 = 400)</code> there is <code>400%</code> available. To limit a server to using half of a single thread, you would set the value to <code>50</code>. To allow a server to use up to two threads, set the value to <code>200</code>.<p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pThreads">CPU Pinning</label>

                        <div>
                            <input type="text" id="pThreads" name="threads" class="form-control" value="{{ old('threads') }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced:</strong> Enter the specific CPU threads that this process can run on, or leave blank to allow all threads. This can be a single number, or a comma separated list. Example: <code>0</code>, <code>0-1,3</code>, or <code>0,1,3,4</code>.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pMemory">Memory</label>

                        <div class="input-group">
                            <input type="text" id="pMemory" name="memory" class="form-control" value="{{ old('memory') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">The maximum amount of memory allowed for this container. Setting this to <code>0</code> will allow unlimited memory in a container.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pSwap">Swap</label>

                        <div class="input-group">
                            <input type="text" id="pSwap" name="swap" class="form-control" value="{{ old('swap', 0) }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">Setting this to <code>0</code> will disable swap space on this server. Setting to <code>-1</code> will allow unlimited swap.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDisk">Disk Space</label>

                        <div class="input-group">
                            <input type="text" id="pDisk" name="disk" class="form-control" value="{{ old('disk') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">This server will not be allowed to boot if it is using more than this amount of space. If a server goes over this limit while running it will be safely stopped and locked until enough space is available. Set to <code>0</code> to allow unlimited disk usage.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pIO">Block IO Weight</label>

                        <div>
                            <input type="text" id="pIO" name="io" class="form-control" value="{{ old('io', 500) }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced</strong>: The IO performance of this server relative to other <em>running</em> containers on the system. Value should be between <code>10</code> and <code>1000</code>. Please see <a href="https://docs.docker.com/engine/reference/run/#block-io-bandwidth-blkio-constraint" target="_blank">this documentation</a> for more information about it.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pOomDisabled" name="oom_disabled" value="0" {{ \\Pterodactyl\\Helpers\\Utilities::checked('oom_disabled', 0) }} />
                            <label for="pOomDisabled" class="strong">Enable OOM Killer</label>
                        </div>

                        <p class="small text-muted no-margin">Terminates the server if it breaches the memory limits. Enabling OOM killer may cause server processes to exit unexpectedly.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nest Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pNestId">Nest</label>

                        <select id="pNestId" name="nest_id" class="form-control">
                            @foreach($nests as $nest)
                                <option value="{{ $nest->id }}"
                                    @if($nest->id === old('nest_id'))
                                        selected="selected"
                                    @endif
                                >{{ $nest->name }}</option>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">Select the Nest that this server will be grouped under.</p>
                    </div>

                    <div class="form-group col-xs-12">
                        <label for="pEggId">Egg</label>
                        <select id="pEggId" name="egg_id" class="form-control"></select>
                        <p class="small text-muted no-margin">Select the Egg that will define how this server should operate.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pSkipScripting" name="skip_scripts" value="1" {{ \\Pterodactyl\\Helpers\\Utilities::checked('skip_scripts', 0) }} />
                            <label for="pSkipScripting" class="strong">Skip Egg Install Script</label>
                        </div>

                        <p class="small text-muted no-margin">If the selected Egg has an install script attached to it, the script will run during the install. If you would like to skip this step, check this box.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Docker Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pDefaultContainer">Docker Image</label>
                        <select id="pDefaultContainer" name="image" class="form-control"></select>
                        <input id="pDefaultContainerCustom" name="custom_image" value="{{ old('custom_image') }}" class="form-control" placeholder="Or enter a custom image..." style="margin-top:1rem"/>
                        <p class="small text-muted no-margin">This is the default Docker image that will be used to run this server. Select an image from the dropdown above, or enter a custom image in the text field above.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Startup Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pStartup">Startup Command</label>
                        <input type="text" id="pStartup" name="startup" value="{{ old('startup') }}" class="form-control" />
                        <p class="small text-muted no-margin">The following data substitutes are available for the startup command: <code>@{{SERVER_MEMORY}}</code>, <code>@{{SERVER_IP}}</code>, and <code>@{{SERVER_PORT}}</code>. They will be replaced with the allocated memory, server IP, and server port respectively.</p>
                    </div>
                </div>

                <div class="box-header with-border" style="margin-top:-10px;">
                    <h3 class="box-title">Service Variables</h3>
                </div>

                <div class="box-body row" id="appendVariablesTo"></div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    <input type="submit" class="btn btn-success pull-right" value="Create Server" />
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('vendor/lodash/lodash.js') !!}

    <script type="application/javascript">
        // Persist 'Service Variables'
        function serviceVariablesUpdated(eggId, ids) {
            @if (old('egg_id'))
                // Check if the egg id matches.
                if (eggId != '{{ old('egg_id') }}') {
                    return;
                }

                @if (old('environment'))
                    @foreach (old('environment') as $key => $value)
                        $('#' + ids['{{ $key }}']).val('{{ $value }}');
                    @endforeach
                @endif
            @endif
            @if(old('image'))
                $('#pDefaultContainer').val('{{ old('image') }}');
            @endif
        }
        // END Persist 'Service Variables'
    </script>

    {!! Theme::js('js/admin/new-server.js?v=20220530') !!}

    <script type="application/javascript">
        $(document).ready(function() {
// Persist 'Server Owner' select2
// (Removed because Server Owner now auto-fills based on logged-in user)
// END Persist 'Server Owner' select2

            // Persist 'Node' select2
            @if (old('node_id'))
                $('#pNodeId').val('{{ old('node_id') }}').change();

                // Persist 'Default Allocation' select2
                @if (old('allocation_id'))
                    $('#pAllocation').val('{{ old('allocation_id') }}').change();
                @endif
                // END Persist 'Default Allocation' select2

                // Persist 'Additional Allocations' select2
                @if (old('allocation_additional'))
                    const additional_allocations = [];

                    @for ($i = 0; $i < count(old('allocation_additional')); $i++)
                        additional_allocations.push('{{ old('allocation_additional.'.$i)}}');
                    @endfor

                    $('#pAllocationAdditional').val(additional_allocations).change();
                @endif
                // END Persist 'Additional Allocations' select2
            @endif
            // END Persist 'Node' select2

            // Persist 'Nest' select2
            @if (old('nest_id'))
                $('#pNestId').val('{{ old('nest_id') }}').change();

                // Persist 'Egg' select2
                @if (old('egg_id'))
                    $('#pEggId').val('{{ old('egg_id') }}').change();
                @endif
                // END Persist 'Egg' select2
            @endif
            // END Persist 'Nest' select2
        });
    </script>
@endsection
`
      },
      {
        name: "PROTECT1 (Anti Update Detail Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/DetailsModificationService.php",
        file: "DetailsModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\ReturnsUpdatedModels;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class DetailsModificationService
{
    use ReturnsUpdatedModels;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $serverRepository
    ) {
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Edit Server
     * Mencegah user non-admin mengubah detail server milik orang lain.
     */
    public function handle(Server $server, array $data): Server
    {
        $user = Auth::user();

        // Proteksi: hanya Admin ID 1 boleh ubah detail server orang lain
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah detail server milik orang lain! ©Protect By @wilzzofficial'
                );
            }
        }

        // Jalankan proses bawaan
        return $this->connection->transaction(function () use ($data, $server) {
            $owner = $server->owner_id;

            $server->forceFill([
                'external_id' => Arr::get($data, 'external_id'),
                'owner_id' => Arr::get($data, 'owner_id'),
                'name' => Arr::get($data, 'name'),
                'description' => Arr::get($data, 'description') ?? '',
            ])->saveOrFail();

            // Jika owner diganti, cabut akses owner lama di Wings
            if ($server->owner_id !== $owner) {
                try {
                    $this->serverRepository->setServer($server)->revokeUserJTI($owner);
                } catch (DaemonConnectionException $exception) {
                    // Abaikan error jika Wings sedang offline
                }
            }

            return $server;
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Build Configuration Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/BuildModificationService.php",
        file: "BuildModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Allocation;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Support\\Facades\\Auth;
use Illuminate\\Database\\Eloquent\\ModelNotFoundException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class BuildModificationService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private ServerConfigurationStructureService $structureService
    ) {
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Build Abuse
     * Mencegah user non-admin mengubah konfigurasi Build server milik orang lain.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server, array $data): Server
    {
        $user = Auth::user();

        // NDyProtect — Cegah user biasa ubah konfigurasi server yang bukan miliknya
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah Build Configuration server orang lain! ©Protect By @wilzzofficial'
                );
            }
        }

        // Jalankan proses asli (tetap sama dengan bawaan Pterodactyl)
        /** @var \\Pterodactyl\\Models\\Server $server */
        $server = $this->connection->transaction(function () use ($server, $data) {
            $this->processAllocations($server, $data);

            if (isset($data['allocation_id']) && $data['allocation_id'] != $server->allocation_id) {
                try {
                    Allocation::query()
                        ->where('id', $data['allocation_id'])
                        ->where('server_id', $server->id)
                        ->firstOrFail();
                } catch (ModelNotFoundException) {
                    throw new DisplayException('The requested default allocation is not currently assigned to this server.');
                }
            }

            $merge = Arr::only($data, [
                'oom_disabled',
                'memory',
                'swap',
                'io',
                'cpu',
                'threads',
                'disk',
                'allocation_id',
            ]);

            $server->forceFill(array_merge($merge, [
                'database_limit' => Arr::get($data, 'database_limit', 0) ?? null,
                'allocation_limit' => Arr::get($data, 'allocation_limit', 0) ?? null,
                'backup_limit' => Arr::get($data, 'backup_limit', 0) ?? 0,
            ]))->saveOrFail();

            return $server->refresh();
        });

        $updateData = $this->structureService->handle($server);

        if (!empty($updateData['build'])) {
            try {
                $this->daemonServerRepository->setServer($server)->sync();
            } catch (DaemonConnectionException $exception) {
                Log::warning($exception, ['server_id' => $server->id]);
            }
        }

        return $server;
    }

    /**
     * Proses alokasi (port) untuk server.
     */
    private function processAllocations(Server $server, array &$data): void
    {
        if (empty($data['add_allocations']) && empty($data['remove_allocations'])) {
            return;
        }

        if (!empty($data['add_allocations'])) {
            $query = Allocation::query()
                ->where('node_id', $server->node_id)
                ->whereIn('id', $data['add_allocations'])
                ->whereNull('server_id');

            $freshlyAllocated = $query->pluck('id')->first();

            $query->update(['server_id' => $server->id, 'notes' => null]);
        }

        if (!empty($data['remove_allocations'])) {
            foreach ($data['remove_allocations'] as $allocation) {
                if ($allocation === ($data['allocation_id'] ?? $server->allocation_id)) {
                    if (empty($freshlyAllocated)) {
                        throw new DisplayException(
                            'You are attempting to delete the default allocation for this server but there is no fallback allocation to use.'
                        );
                    }
                    $data['allocation_id'] = $freshlyAllocated;
                }
            }

            Allocation::query()
                ->where('node_id', $server->node_id)
                ->where('server_id', $server->id)
                ->whereIn('id', array_diff($data['remove_allocations'], $data['add_allocations'] ?? []))
                ->update([
                    'notes' => null,
                    'server_id' => null,
                ]);
        }
    }
}`
      },
      {
        name: "PROTECT1 (Anti Setup Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/StartupModificationService.php",
        file: "StartupModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Egg;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\ServerVariable;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\HasUserLevels;
use Pterodactyl\\Exceptions\\DisplayException;

class StartupModificationService
{
    use HasUserLevels;

    /**
     * StartupModificationService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private VariableValidatorService $validatorService
    ) {
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Startup Abuse
     * Mencegah user non-admin mengubah startup command server milik orang lain.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        // NDyProtect — Cegah user biasa ubah startup server bukan miliknya
        $user = auth()->user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah startup command server orang lain! ©Protect By @wilzzofficial'
                );
            }
        }

        // Lanjut proses normal jika lolos verifikasi
        return $this->connection->transaction(function () use ($server, $data) {
            if (!empty($data['environment'])) {
                $egg = $this->isUserLevel(User::USER_LEVEL_ADMIN)
                    ? ($data['egg_id'] ?? $server->egg_id)
                    : $server->egg_id;

                $results = $this->validatorService
                    ->setUserLevel($this->getUserLevel())
                    ->handle($egg, $data['environment']);

                foreach ($results as $result) {
                    ServerVariable::query()->updateOrCreate(
                        [
                            'server_id' => $server->id,
                            'variable_id' => $result->id,
                        ],
                        ['variable_value' => $result->value ?? '']
                    );
                }
            }

            if ($this->isUserLevel(User::USER_LEVEL_ADMIN)) {
                $this->updateAdministrativeSettings($data, $server);
            }

            return $server->fresh();
        });
    }

    /**
     * Update certain administrative settings for a server in the DB.
     */
    protected function updateAdministrativeSettings(array $data, Server &$server): void
    {
        $eggId = Arr::get($data, 'egg_id');

        if (is_digit($eggId) && $server->egg_id !== (int) $eggId) {
            /** @var \\Pterodactyl\\Models\\Egg $egg */
            $egg = Egg::query()->findOrFail($data['egg_id']);

            $server = $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ]);
        }

        $server->fill([
            'startup' => $data['startup'] ?? $server->startup,
            'skip_scripts' => $data['skip_scripts'] ?? isset($data['skip_scripts']),
            'image' => $data['docker_image'] ?? $server->image,
        ])->save();
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Database)",
        path: "/var/www/pterodactyl/app/Services/Databases/DatabaseManagementService.php",
        file: "DatabaseManagementService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Databases;

use Exception;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Helpers\\Utilities;
use Illuminate\\Database\\ConnectionInterface;
use Illuminate\\Contracts\\Encryption\\Encrypter;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Extensions\\DynamicDatabaseConnection;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseRepository;
use Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException;
use Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException;
use Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Support\\Facades\\Log;

class DatabaseManagementService
{
    private const MATCH_NAME_REGEX = '/^(s[\\d]+_)(.*)$/';

    protected bool $validateDatabaseLimit = true;

    public function __construct(
        protected ConnectionInterface $connection,
        protected DynamicDatabaseConnection $dynamic,
        protected Encrypter $encrypter,
        protected DatabaseRepository $repository
    ) {
    }

    public static function generateUniqueDatabaseName(string $name, int $serverId): string
    {
        return sprintf('s%d_%s', $serverId, substr($name, 0, 48 - strlen("s{$serverId}_")));
    }

    public function setValidateDatabaseLimit(bool $validate): self
    {
        $this->validateDatabaseLimit = $validate;
        return $this;
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Database Abuse
     * Melindungi agar user biasa tidak bisa membuat/menghapus database server milik orang lain.
     */
    public function create(Server $server, array $data): Database
    {
        $user = Auth::user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat membuat database untuk server orang lain! ©Protect By @wilzzofficial');
            }
        }

        if (!config('pterodactyl.client_features.databases.enabled')) {
            throw new DatabaseClientFeatureNotEnabledException();
        }

        if ($this->validateDatabaseLimit) {
            if (!is_null($server->database_limit) && $server->databases()->count() >= $server->database_limit) {
                throw new TooManyDatabasesException();
            }
        }

        if (empty($data['database']) || !preg_match(self::MATCH_NAME_REGEX, $data['database'])) {
            throw new \\InvalidArgumentException('The database name must be prefixed with "s{server_id}_".');
        }

        $data = array_merge($data, [
            'server_id' => $server->id,
            'username' => sprintf('u%d_%s', $server->id, str_random(10)),
            'password' => $this->encrypter->encrypt(
                Utilities::randomStringWithSpecialCharacters(24)
            ),
        ]);

        $database = null;

        try {
            return $this->connection->transaction(function () use ($data, &$database) {
                $database = $this->createModel($data);

                $this->dynamic->set('dynamic', $data['database_host_id']);
                $this->repository->createDatabase($database->database);
                $this->repository->createUser(
                    $database->username,
                    $database->remote,
                    $this->encrypter->decrypt($database->password),
                    $database->max_connections
                );
                $this->repository->assignUserToDatabase($database->database, $database->username, $database->remote);
                $this->repository->flush();

                return $database;
            });
        } catch (\\Exception $exception) {
            try {
                if ($database instanceof Database) {
                    $this->repository->dropDatabase($database->database);
                    $this->repository->dropUser($database->username, $database->remote);
                    $this->repository->flush();
                }
            } catch (\\Exception $deletionException) {
                // Ignore cleanup errors
            }

            throw $exception;
        }
    }

    public function delete(Database $database): ?bool
    {
        $user = Auth::user();

        if ($user && $user->id !== 1) {
            $server = Server::find($database->server_id);
            if ($server && $server->owner_id !== $user->id) {
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat menghapus database server orang lain! ©Protect By @wilzzofficial');
            }
        }

        $this->dynamic->set('dynamic', $database->database_host_id);

        $this->repository->dropDatabase($database->database);
        $this->repository->dropUser($database->username, $database->remote);
        $this->repository->flush();

        return $database->delete();
    }

    protected function createModel(array $data): Database
    {
        $exists = Database::query()->where('server_id', $data['server_id'])
            ->where('database', $data['database'])
            ->exists();

        if ($exists) {
            throw new DuplicateDatabaseNameException('A database with that name already exists for this server.');
        }

        $database = (new Database())->forceFill($data);
        $database->saveOrFail();

        return $database;
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Transfer This Server)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerTransferController.php",
        file: "ServerTransferController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Models\\ServerTransfer;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Eloquent\\NodeRepository;
use Pterodactyl\\Repositories\\Wings\\DaemonTransferRepository;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Exceptions\\DisplayException;

class ServerTransferController extends Controller
{
    /**
     * ServerTransferController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private AllocationRepositoryInterface $allocationRepository,
        private ConnectionInterface $connection,
        private DaemonTransferRepository $daemonTransferRepository,
        private NodeJWTService $nodeJWTService,
        private NodeRepository $nodeRepository
    ) {
    }

    /**
     * Starts a transfer of a server to a new node.
     *
     * @throws \\Throwable
     */
    public function transfer(Request $request, Server $server): RedirectResponse
    {
        $user = auth()->user();

        // 🧱 NDyProtect v1.2 — Anti Unauthorized Server Transfer
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id
                ?? $server->user_id
                ?? ($server->owner?->id ?? null)
                ?? ($server->user?->id ?? null);

            if ($ownerId === null) {
                throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');
            }

            if ($ownerId !== $user->id) {
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mentransfer server orang lain! ©Protect By @wilzzofficial');
            }
        }

        $validatedData = $request->validate([
            'node_id' => 'required|exists:nodes,id',
            'allocation_id' => 'required|bail|unique:servers|exists:allocations,id',
            'allocation_additional' => 'nullable',
        ]);

        $node_id = $validatedData['node_id'];
        $allocation_id = intval($validatedData['allocation_id']);
        $additional_allocations = array_map('intval', $validatedData['allocation_additional'] ?? []);

        // Check if the node is viable for the transfer.
        $node = $this->nodeRepository->getNodeWithResourceUsage($node_id);
        if (!$node->isViable($server->memory, $server->disk)) {
            $this->alert->danger(trans('admin/server.alerts.transfer_not_viable'))->flash();

            return redirect()->route('admin.servers.view.manage', $server->id);
        }

        $server->validateTransferState();

        $this->connection->transaction(function () use ($server, $node_id, $allocation_id, $additional_allocations) {
            // Create a new ServerTransfer entry.
            $transfer = new ServerTransfer();

            $transfer->server_id = $server->id;
            $transfer->old_node = $server->node_id;
            $transfer->new_node = $node_id;
            $transfer->old_allocation = $server->allocation_id;
            $transfer->new_allocation = $allocation_id;
            $transfer->old_additional_allocations = $server->allocations->where('id', '!=', $server->allocation_id)->pluck('id');
            $transfer->new_additional_allocations = $additional_allocations;

            $transfer->save();

            // Add the allocations to the server, so they cannot be automatically assigned while the transfer is in progress.
            $this->assignAllocationsToServer($server, $node_id, $allocation_id, $additional_allocations);

            // Generate a token for the destination node that the source node can use to authenticate with.
            $token = $this->nodeJWTService
                ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
                ->setSubject($server->uuid)
                ->handle($transfer->newNode, $server->uuid, 'sha256');

            // Notify the source node of the pending outgoing transfer.
            $this->daemonTransferRepository->setServer($server)->notify($transfer->newNode, $token);

            return $transfer;
        });

        $this->alert->success(trans('admin/server.alerts.transfer_started'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Assigns the specified allocations to the specified server.
     */
    private function assignAllocationsToServer(Server $server, int $node_id, int $allocation_id, array $additional_allocations)
    {
        $allocations = $additional_allocations;
        $allocations[] = $allocation_id;

        $unassigned = $this->allocationRepository->getUnassignedAllocationIds($node_id);

        $updateIds = [];
        foreach ($allocations as $allocation) {
            if (!in_array($allocation, $unassigned)) {
                continue;
            }

            $updateIds[] = $allocation;
        }

        if (!empty($updateIds)) {
            $this->allocationRepository->updateWhereIn('id', $updateIds, ['server_id' => $server->id]);
        }
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Suspend Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

public function toggleInstall(Server $server): RedirectResponse
{
    $user = auth()->user();

    // 🧱 NDyProtect v1.2 — Anti Unauthorized Toggle Install
    if ($user && $user->id !== 1) {
        $ownerId = $server->owner_id
            ?? $server->user_id
            ?? ($server->owner?->id ?? null)
            ?? ($server->user?->id ?? null);

        if ($ownerId === null) {
            throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');
        }

        if ($ownerId !== $user->id) {
            throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah status instalasi server orang lain! ©Protect By @wilzzofficial');
        }
    }

    if ($server->status === Server::STATUS_INSTALL_FAILED) {
        throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
    }

    $this->repository->update($server->id, [
        'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
    ], true, true);

    $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

    return redirect()->route('admin.servers.view.manage', $server->id);
}

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
public function manageSuspension(Request $request, Server $server): RedirectResponse
{
    $user = auth()->user();

    // 🧱 NDyProtect v1.2 — Anti Suspend Server Tanpa Izin
    if ($user && $user->id !== 1) {
        $ownerId = $server->owner_id
            ?? $server->user_id
            ?? ($server->owner?->id ?? null)
            ?? ($server->user?->id ?? null);

        if ($ownerId === null) {
            throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');
        }

        if ($ownerId !== $user->id) {
            throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mensuspend server orang lain! ©Protect By @wilzzofficial');
        }
    }

    // Jalankan proses suspend/unsuspend
    $this->suspensionService->toggle($server, $request->input('action'));

    $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
        'status' => $request->input('action') . 'ed',
    ]))->flash();

    return redirect()->route('admin.servers.view.manage', $server->id);
}

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Toggle Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php  
  
namespace Pterodactyl\\Http\\Controllers\\Admin;  
  
use Illuminate\\Http\\Request;  
use Pterodactyl\\Models\\User;  
use Illuminate\\Http\\Response;  
use Pterodactyl\\Models\\Mount;  
use Pterodactyl\\Models\\Server;  
use Pterodactyl\\Models\\Database;  
use Pterodactyl\\Models\\MountServer;  
use Illuminate\\Http\\RedirectResponse;  
use Prologue\\Alerts\\AlertsMessageBag;  
use Pterodactyl\\Exceptions\\DisplayException;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Illuminate\\Validation\\ValidationException;  
use Pterodactyl\\Services\\Servers\\SuspensionService;  
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;  
use Pterodactyl\\Services\\Servers\\ServerDeletionService;  
use Pterodactyl\\Services\\Servers\\ReinstallServerService;  
use Pterodactyl\\Exceptions\\Model\\DataValidationException;  
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;  
use Pterodactyl\\Services\\Servers\\BuildModificationService;  
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;  
use Pterodactyl\\Services\\Servers\\DetailsModificationService;  
use Pterodactyl\\Services\\Servers\\StartupModificationService;  
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;  
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;  
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;  
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;  
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;  
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;  
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;  
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;  
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;  
  
class ServersController extends Controller  
{  
    public function __construct(  
        protected AlertsMessageBag $alert,  
        protected AllocationRepositoryInterface $allocationRepository,  
        protected BuildModificationService $buildModificationService,  
        protected ConfigRepository $config,  
        protected DaemonServerRepository $daemonServerRepository,  
        protected DatabaseManagementService $databaseManagementService,  
        protected DatabasePasswordService $databasePasswordService,  
        protected DatabaseRepositoryInterface $databaseRepository,  
        protected DatabaseHostRepository $databaseHostRepository,  
        protected ServerDeletionService $deletionService,  
        protected DetailsModificationService $detailsModificationService,  
        protected ReinstallServerService $reinstallService,  
        protected ServerRepositoryInterface $repository,  
        protected MountRepository $mountRepository,  
        protected NestRepositoryInterface $nestRepository,  
        protected ServerConfigurationStructureService $serverConfigurationStructureService,  
        protected StartupModificationService $startupModificationService,  
        protected SuspensionService $suspensionService  
    ) {  
    }  
  
    public function setDetails(Request $request, Server $server): RedirectResponse  
    {  
        $this->detailsModificationService->handle($server, $request->only([  
            'owner_id', 'external_id', 'name', 'description',  
        ]));  
  
        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();  
  
        return redirect()->route('admin.servers.view.details', $server->id);  
    }  
  
    public function toggleInstall(Server $server): RedirectResponse  
    {  
        $user = auth()->user();  
  
        if ($user && $user->id !== 1) {  
            $ownerId = $server->owner_id  
                ?? $server->user_id  
                ?? ($server->owner?->id ?? null)  
                ?? ($server->user?->id ?? null);  
  
            if ($ownerId === null) {  
                throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');  
            }  
  
            if ($ownerId !== $user->id) {  
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah status instalasi server orang lain! ©Protect By @wilzzofficial');  
            }  
        }  
  
        if ($server->status === Server::STATUS_INSTALL_FAILED) {  
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));  
        }  
  
        $this->repository->update($server->id, [  
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,  
        ], true, true);  
  
        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function reinstallServer(Server $server): RedirectResponse  
    {  
        $this->reinstallService->handle($server);  
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function manageSuspension(Request $request, Server $server): RedirectResponse  
    {  
        $user = auth()->user();  
  
        if ($user && $user->id !== 1) {  
            $ownerId = $server->owner_id  
                ?? $server->user_id  
                ?? ($server->owner?->id ?? null)  
                ?? ($server->user?->id ?? null);  
  
            if ($ownerId === null) {  
                throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');  
            }  
  
            if ($ownerId !== $user->id) {  
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mensuspend server orang lain! ©Protect By @wilzzofficial');  
            }  
        }  
  
        $this->suspensionService->toggle($server, $request->input('action'));  
  
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [  
            'status' => $request->input('action') . 'ed',  
        ]))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function updateBuild(Request $request, Server $server): RedirectResponse  
    {  
        try {  
            $this->buildModificationService->handle($server, $request->only([  
                'allocation_id', 'add_allocations', 'remove_allocations',  
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',  
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',  
            ]));  
        } catch (DataValidationException $exception) {  
            throw new ValidationException($exception->getValidator());  
        }  
  
        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();  
  
        return redirect()->route('admin.servers.view.build', $server->id);  
    }  
  
    public function delete(Request $request, Server $server): RedirectResponse  
    {  
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);  
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();  
  
        return redirect()->route('admin.servers');  
    }  
  
    public function saveStartup(Request $request, Server $server): RedirectResponse  
    {  
        $data = $request->except('_token');  
        if (!empty($data['custom_docker_image'])) {  
            $data['docker_image'] = $data['custom_docker_image'];  
            unset($data['custom_docker_image']);  
        }  
  
        try {  
            $this->startupModificationService  
                ->setUserLevel(User::USER_LEVEL_ADMIN)  
                ->handle($server, $data);  
        } catch (DataValidationException $exception) {  
            throw new ValidationException($exception->getValidator());  
        }  
  
        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();  
  
        return redirect()->route('admin.servers.view.startup', $server->id);  
    }  
  
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse  
    {  
        $this->databaseManagementService->create($server, [  
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),  
            'remote' => $request->input('remote'),  
            'database_host_id' => $request->input('database_host_id'),  
            'max_connections' => $request->input('max_connections'),  
        ]);  
  
        return redirect()->route('admin.servers.view.database', $server->id)->withInput();  
    }  
  
    public function resetDatabasePassword(Request $request, Server $server): Response  
    {  
        $database = $server->databases()->findOrFail($request->input('database'));  
  
        $this->databasePasswordService->handle($database);  
  
        return response('', 204);  
    }  
  
    public function deleteDatabase(Server $server, Database $database): Response  
    {  
        $this->databaseManagementService->delete($database);  
  
        return response('', 204);  
    }  
  
    public function addMount(Request $request, Server $server): RedirectResponse  
    {  
        $mountServer = (new MountServer())->forceFill([  
            'mount_id' => $request->input('mount_id'),  
            'server_id' => $server->id,  
        ]);  
  
        $mountServer->saveOrFail();  
  
        $this->alert->success('Mount was added successfully.')->flash();  
  
        return redirect()->route('admin.servers.view.mounts', $server->id);  
    }  
  
    public function deleteMount(Server $server, Mount $mount): RedirectResponse  
    {  
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();  
  
        $this->alert->success('Mount was removed successfully.')->flash();  
  
        return redirect()->route('admin.servers.view.mounts', $server->id);  
    }  
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Illuminate\\Support\\Facades\\Log;

class ReinstallServerService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {}

    /**
     * 🧱 NDyProtect v1.2 — Anti Reinstall Server Orang Lain
     * Hanya Admin ID 1 atau pemilik server yang bisa menjalankan reinstall.
     */
    public function handle(Server $server): Server
    {
        $user = Auth::user();

        // 🔒 Proteksi akses
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat me-reinstall server orang lain! ©Protect By @wilzzofficial');
                }
            }
        }

        // 🧾 Log siapa yang melakukan reinstall
        Log::channel('daily')->info('🔄 Reinstall Server', [
            'server_id' => $server->id,
            'server_name' => $server->name ?? 'Unknown',
            'reinstalled_by' => $user?->id ?? 'CLI/Unknown',
            'time' => now()->toDateTimeString(),
        ]);

        // ⚙️ Jalankan reinstall
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Delete Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/ServerDeletionService.php",
        file: "ServerDeletionService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService
    ) {}

    /**
     * Aktifkan mode "Force Delete"
     */
    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;
        return $this;
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Delete Server + Force Delete Logger
     * Melindungi agar pengguna biasa tidak dapat menghapus server orang lain.
     * Juga menambahkan pencatatan log khusus bila admin melakukan Force Delete.
     */
    public function handle(Server $server): void
    {
        $user = Auth::user();

        // 🔒 Cegah selain Admin ID 1 menghapus server milik orang lain
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat menghapus server orang lain! ©Protect By @wilzzofficial');
                }
            }
        }

        // 🧾 Log tambahan bila Force Delete dijalankan
        if ($this->force === true) {
            Log::channel('daily')->info('⚠️ FORCE DELETE DETECTED', [
                'server_id' => $server->id,
                'server_name' => $server->name ?? 'Unknown',
                'deleted_by' => $user?->id ?? 'CLI/Unknown',
                'time' => now()->toDateTimeString(),
            ]);

            Log::build([
                'driver' => 'single',
                'path' => storage_path('logs/force_delete.log'),
            ])->info("⚠️ FORCE DELETE SERVER #{$server->id} ({$server->name}) oleh User ID {$user?->id}");
        }

        // 🔧 Hapus data dari Daemon (Wings)
        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw $exception;
            }
            Log::warning($exception);
        }

        // 🧹 Hapus database & record panel
        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\\Exception $exception) {
                    if (!$this->force) throw $exception;
                    $database->delete();
                    Log::warning($exception);
                }
            }

            $server->delete();
        });
    }
}`
      },
    ];

    // ========================= UPLOAD SEMUA PROTEKSI =========================
    let successCount = 0;

    for (const file of protectFiles) {
      try {
        const tempFile = path.join(__dirname, file.file);
        fs.writeFileSync(tempFile, file.code);
        await ssh.putFile(tempFile, file.path);
        fs.unlinkSync(tempFile);
        successCount++;
        await bot.sendMessage(chatId, `✅ *${file.name}* berhasil dipasang!\n📂 \`${file.path}\``, {
          parse_mode: "Markdown",
        });
      } catch (err) {
        await bot.sendMessage(
          chatId,
          `❌ Gagal memasang *${file.name}*\nError: \`${err.message}\``,
          { parse_mode: "Markdown" }
        );
      }
    }

    ssh.dispose();

await bot.sendMessage(
  chatId,
  `🧩 *INSTALASI PROTECT ALL SELESAI!*\n
✅ Berhasil: ${successCount}/${protectFiles.length} file\n
⚙️ Semua fitur keamanan aktif untuk panelmu.\n\n©Protect By @wilzzofficial`,
  { parse_mode: "Markdown" }
);

    console.log(`🟢 InstallProtect1 selesai untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT1:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menjalankan instalasi ProtectAll.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT2 (ANTI INTIP USERS & ANTI CADMIN - FINAL FIX) =========================
bot.onText(/^\/installprotect2$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/UserController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Model;
use Illuminate\\Support\\Collection;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Spatie\\QueryBuilder\\QueryBuilder;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Contracts\\Translation\\Translator;
use Pterodactyl\\Services\\Users\\UserUpdateService;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Users\\UserCreationService;
use Pterodactyl\\Services\\Users\\UserDeletionService;
use Pterodactyl\\Http\\Requests\\Admin\\UserFormRequest;
use Pterodactyl\\Http\\Requests\\Admin\\NewUserFormRequest;
use Pterodactyl\\Contracts\\Repository\\UserRepositoryInterface;

class UserController extends Controller
{
    use AvailableLanguages;

    /**
     * UserController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected UserCreationService $creationService,
        protected UserDeletionService $deletionService,
        protected Translator $translator,
        protected UserUpdateService $updateService,
        protected UserRepositoryInterface $repository,
        protected ViewFactory $view
    ) {
    }

    /**
     * Display user index page.
     */
public function index(Request $request): View
{
    $authUser = $request->user();

    $query = User::query()
        ->select('users.*')
        ->selectRaw('COUNT(DISTINCT(subusers.id)) as subuser_of_count')
        ->selectRaw('COUNT(DISTINCT(servers.id)) as servers_count')
        ->leftJoin('subusers', 'subusers.user_id', '=', 'users.id')
        ->leftJoin('servers', 'servers.owner_id', '=', 'users.id')
        ->groupBy('users.id');

    // Jika bukan admin ID 1, hanya tampilkan dirinya sendiri
    if ($authUser->id !== 1) {
        $query->where('users.id', $authUser->id);
    }

    $users = QueryBuilder::for($query)
        ->allowedFilters(['username', 'email', 'uuid'])
        ->allowedSorts(['id', 'uuid'])
        ->paginate(50);

    return $this->view->make('admin.users.index', ['users' => $users]);
}

    /**
     * Display new user page.
     */
    public function create(): View
    {
        return $this->view->make('admin.users.new', [
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Display user view page.
     */
    public function view(User $user): View
    {
        return $this->view->make('admin.users.view', [
            'user' => $user,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Delete a user from the system.
     *
     * @throws \\Exception
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
public function delete(Request $request, User $user): RedirectResponse
{
    $authUser = $request->user();

    // ❌ Jika bukan admin ID 1 -> larang delete user manapun
    if ($authUser->id !== 1) {
        throw new DisplayException("🚫 Akses ditolak: hanya admin ID 1 yang dapat menghapus user! ©Protect By @wilzzofficial");
    }

    // ❌ Admin ID 1 tidak boleh hapus dirinya sendiri
    if ($authUser->id === $user->id) {
        throw new DisplayException("❌ Tidak bisa menghapus akun Anda sendiri.");
    }

    // Lanjut hapus user
    $this->deletionService->handle($user);

    $this->alert->success("🗑️ User berhasil dihapus.")->flash();
    return redirect()->route('admin.users');
}

    /**
     * Create a user.
     */
    public function store(NewUserFormRequest $request): RedirectResponse
    {
        $authUser = $request->user();
        $data = $request->normalize();

        // Jika user bukan admin ID 1 dan mencoba membuat user admin
        if ($authUser->id !== 1 && isset($data['root_admin']) && $data['root_admin'] == true) {
            throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat membuat user admin! ©Protect By @wilzzofficial.");
        }

        // Semua user selain ID 1 akan selalu membuat user biasa
        if ($authUser->id !== 1) {
            $data['root_admin'] = false;
        }

        // Buat user baru
        $user = $this->creationService->handle($data);

        $this->alert->success("✅ Akun user berhasil dibuat (level: user biasa).")->flash();
        return redirect()->route('admin.users.view', $user->id);
    }


    /**
     * Update a user on the system.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(UserFormRequest $request, User $user): RedirectResponse
    {
        $restrictedFields = ['email', 'first_name', 'last_name', 'password'];

        foreach ($restrictedFields as $field) {
            if ($request->filled($field) && $request->user()->id !== 1) {
                throw new DisplayException("⚠️ Data hanya bisa diubah oleh admin ID 1. ©Protect By @wilzzofficial");
            }
        }

        if ($user->root_admin && $request->user()->id !== 1) {
            throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat menurunkan hak admin user ini! ©Protect By @wilzzofficial.");
        }

        if ($request->user()->id !== 1 && $request->user()->id !== $user->id) {
            throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat mengubah data user lain! ©Protect By @wilzzofficial.");
        }

        // Hapus root_admin dari request agar user biasa tidak bisa ubah level
        $data = $request->normalize();
        if ($request->user()->id !== 1) {
            unset($data['root_admin']);
        }

        $this->updateService
            ->setUserLevel(User::USER_LEVEL_ADMIN)
            ->handle($user, $data);

        $this->alert->success(trans('admin/user.notices.account_updated'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Get a JSON response of users on the system.
     */
    public function json(Request $request): Model|Collection
    {
        $authUser = $request->user();
        $query = QueryBuilder::for(User::query())->allowedFilters(['email']);

        if ($authUser->id !== 1) {
            $query->where('id', $authUser->id);
        }

        $users = $query->paginate(25);

        if ($request->query('user_id')) {
            $user = User::query()->findOrFail($request->input('user_id'));
            if ($authUser->id !== 1 && $authUser->id !== $user->id) {
                throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat melihat data user lain! ©Protect By @wilzzofficial.");
            }
            $user->md5 = md5(strtolower($user->email));
            return $user;
        }

        return $users->map(function ($item) {
            $item->md5 = md5(strtolower($item->email));
            return $item;
        });
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "UserController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `✅ *PROTECT2 (ANTI INTIP USERS & ANTI CADMIN) BERHASIL DIPASANG!*

⚙️ *Fungsi:*
Melindungi menu Users Settings — hanya Admin utama (ID 1) yang bisa mengedit, menghapus, & melihat semua user.

🔐 *Keamanan Tambahan:*
- Pengguna biasa hanya bisa melihat & mengedit akunnya sendiri.
- User non-admin tidak bisa melihat data user lain.
- Mencegah pembuatan admin ilegal & cadmin.
- Tidak bisa delete user lain.
- Anti intip & anti penyalahgunaan data.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect2 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT2:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT2.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT3 (ANTI INTIP LOCATION - FINAL) =========================
bot.onText(/^\/installprotect3$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/LocationController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Location;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\LocationFormRequest;
use Pterodactyl\\Services\\Locations\\LocationUpdateService;
use Pterodactyl\\Services\\Locations\\LocationCreationService;
use Pterodactyl\\Services\\Locations\\LocationDeletionService;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class LocationController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected LocationCreationService $creationService,
        protected LocationDeletionService $deletionService,
        protected LocationRepositoryInterface $repository,
        protected LocationUpdateService $updateService,
        protected ViewFactory $view
    ) {
    }

    public function index(): View
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.locations.index', [
            'locations' => $this->repository->getAllWithDetails(),
        ]);
    }

    public function view(int $id): View
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.locations.view', [
            'location' => $this->repository->getWithNodes($id),
        ]);
    }

    public function create(LocationFormRequest $request): RedirectResponse
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        $location = $this->creationService->handle($request->normalize());
        $this->alert->success('Location was created successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    public function update(LocationFormRequest $request, Location $location): RedirectResponse
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        if ($request->input('action') === 'delete') {
            return $this->delete($location);
        }

        $this->updateService->handle($location->id, $request->normalize());
        $this->alert->success('Location was updated successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    public function delete(Location $location): RedirectResponse
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        try {
            $this->deletionService->handle($location->id);
            return redirect()->route('admin.locations');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }

        return redirect()->route('admin.locations.view', $location->id);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "LocationController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `✅ *PROTECT3 (ANTI INTIP LOCATION) BERHASIL DIPASANG!*

⚙️ *Fungsi:* 
Mengunci akses menu *Location* agar hanya Admin utama (ID 1) yang dapat membuka, mengedit dan menghapus lokasi.

🧠 *Keamanan tambahan:*
- User biasa tidak bisa melihat data location.
- Semua akses selain Admin ID 1 akan *langsung diblokir (403 Forbidden)*.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy SecureShield v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect3 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT3:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT3.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT4 (ANTI INTIP NODES - FINAL FIX) =========================
bot.onText(/^\/installprotect4$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/Nodes/NodeController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nodes;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;
use Pterodactyl\\Models\\Node;
use Spatie\\QueryBuilder\\QueryBuilder;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\NodeFormRequest;
use Pterodactyl\\Services\\Nodes\\NodeUpdateService;
use Pterodactyl\\Services\\Nodes\\NodeCreationService;
use Pterodactyl\\Services\\Nodes\\NodeDeletionService;
use Pterodactyl\\Contracts\\Repository\\NodeRepositoryInterface;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;

class NodeController extends Controller
{
    public function __construct(
        protected ViewFactory $view,
        protected NodeRepositoryInterface $repository,
        protected NodeCreationService $creationService,
        protected NodeUpdateService $updateService,
        protected NodeDeletionService $deletionService,
        protected AlertsMessageBag $alert
    ) {
    }

    private function checkAdminAccess(): void
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak! Hanya Admin utama (ID 1) yang dapat mengakses menu Nodes. 
©Protect By @wilzzofficial');
        }
    }

    public function index(Request $request): View
    {
        $this->checkAdminAccess();

        $nodes = QueryBuilder::for(
            Node::query()->with('location')->withCount('servers')
        )
            ->allowedFilters(['uuid', 'name'])
            ->allowedSorts(['id'])
            ->paginate(25);

        return $this->view->make('admin.nodes.index', ['nodes' => $nodes]);
    }

    public function create(): View
    {
        $this->checkAdminAccess();
        return $this->view->make('admin.nodes.new');
    }

    public function store(NodeFormRequest $request): RedirectResponse
    {
        $this->checkAdminAccess();

        $node = $this->creationService->handle($request->normalize());
        $this->alert->success('✅ Node berhasil dibuat.')->flash();

        return redirect()->route('admin.nodes.view', $node->id);
    }

    public function view(int $id): View
    {
        $this->checkAdminAccess();

        $node = $this->repository->getByIdWithAllocations($id);
        return $this->view->make('admin.nodes.view', ['node' => $node]);
    }

    public function edit(int $id): View
    {
        $this->checkAdminAccess();

        $node = $this->repository->getById($id);
        return $this->view->make('admin.nodes.edit', ['node' => $node]);
    }

    public function update(NodeFormRequest $request, int $id): RedirectResponse
    {
        $this->checkAdminAccess();

        $this->updateService->handle($id, $request->normalize());
        $this->alert->success('✅ Node berhasil diperbarui.')->flash();

        return redirect()->route('admin.nodes.view', $id);
    }

    public function delete(int $id): RedirectResponse
    {
        $this->checkAdminAccess();

        try {
            $this->deletionService->handle($id);
            $this->alert->success('🗑️ Node berhasil dihapus.')->flash();
            return redirect()->route('admin.nodes');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }

        return redirect()->route('admin.nodes.view', $id);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "NodeController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `✅ *PROTECT4 (ANTI INTIP NODES) BERHASIL DIPASANG!*

⚙️ *Fungsi:*
Menutup akses ke *menu Nodes* untuk semua user selain *Admin utama (ID 1)*.

🧠 *Penjelasan:*
- Hanya admin utama yang bisa melihat & mengelola node.
- User lain tidak bisa membuka menu / melihat daftar node aktif.
- Keamanan node terjamin 100% 🔐

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect4 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT4:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT4.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT5 (ANTI INTIP NEST - FINAL FIX) =========================
bot.onText(/^\/installprotect5$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/Nests/NestController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nests;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nests\\NestUpdateService;
use Pterodactyl\\Services\\Nests\\NestCreationService;
use Pterodactyl\\Services\\Nests\\NestDeletionService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Nest\\StoreNestFormRequest;
use Pterodactyl\\Exceptions\\DisplayException;

class NestController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestCreationService $nestCreationService,
        protected NestDeletionService $nestDeletionService,
        protected NestRepositoryInterface $repository,
        protected NestUpdateService $nestUpdateService,
        protected ViewFactory $view
    ) {
    }

    /**
     * 🔒 Cek akses: hanya admin ID 1 yang boleh lanjut.
     */
    private function checkAdminAccess(): void
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak! Hanya Admin utama (ID 1) yang dapat membuka menu Nests. 
©Protect By @wilzzofficial');
        }
    }

    public function index(): View
    {
        $this->checkAdminAccess();

        return $this->view->make('admin.nests.index', [
            'nests' => $this->repository->getWithCounts(),
        ]);
    }

    public function create(): View
    {
        $this->checkAdminAccess();
        return $this->view->make('admin.nests.new');
    }

    public function store(StoreNestFormRequest $request): RedirectResponse
    {
        $this->checkAdminAccess();
        $nest = $this->nestCreationService->handle($request->normalize());
        $this->alert->success('✅ Nest berhasil dibuat.')->flash();
        return redirect()->route('admin.nests.view', $nest->id);
    }

    public function view(int $nest): View
    {
        $this->checkAdminAccess();
        return $this->view->make('admin.nests.view', [
            'nest' => $this->repository->getWithEggServers($nest),
        ]);
    }

    public function update(StoreNestFormRequest $request, int $nest): RedirectResponse
    {
        $this->checkAdminAccess();
        $this->nestUpdateService->handle($nest, $request->normalize());
        $this->alert->success('✅ Nest berhasil diperbarui.')->flash();
        return redirect()->route('admin.nests.view', $nest);
    }

    public function destroy(int $nest): RedirectResponse
    {
        $this->checkAdminAccess();
        try {
            $this->nestDeletionService->handle($nest);
            $this->alert->success('🗑️ Nest berhasil dihapus.')->flash();
            return redirect()->route('admin.nests');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }
        return redirect()->route('admin.nests.view', $nest);
    }
}
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "NestController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT5 (ANTI INTIP NEST) BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Melindungi menu *Nests* agar hanya *Admin utama (ID 1)* yang dapat melihat & mengelolanya.

🧠 *Penjelasan:*  
- Hanya SuperAdmin (ID 1) yang bisa akses Nests.  
- User lain *tidak bisa melihat atau mengedit* Nest.  
- Akses ilegal otomatis *403 Forbidden*.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect5 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT5:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT5.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT6 (ANTI INTIP SETTINGS - FINAL FIX) =========================
bot.onText(/^\/installprotect6$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/Settings/IndexController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Settings;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\Contracts\\Console\\Kernel;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Helpers\\SoftwareVersionService;
use Pterodactyl\\Contracts\\Repository\\SettingsRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Settings\\BaseSettingsFormRequest;

class IndexController extends Controller
{
    use AvailableLanguages;

    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private SoftwareVersionService $versionService,
        private ViewFactory $view
    ) {
    }

    public function index(): View
    {
        // 🔒 Anti akses menu Settings selain user ID 1
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat membuka menu Settings! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.settings.index', [
            'version' => $this->versionService,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    public function update(BaseSettingsFormRequest $request): RedirectResponse
    {
        // 🔒 Anti akses update settings selain user ID 1
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat update menu Settings! ©Protect By @wilzzofficial.');
        }

        foreach ($request->normalize() as $key => $value) {
            $this->settings->set('settings::' . $key, $value);
        }

        $this->kernel->call('queue:restart');
        $this->alert->success(
            'Panel settings have been updated successfully and the queue worker was restarted to apply these changes.'
        )->flash();

        return redirect()->route('admin.settings');
    }
}
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "IndexController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT6 (ANTI INTIP SETTINGS) BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Membatasi akses ke *menu Settings* hanya untuk *Admin utama (ID 1)*.

🧠 *Penjelasan:*  
- Hanya Admin ID 1 yang bisa membuka dan mengubah konfigurasi panel.  
- User lain *tidak bisa membuka halaman Settings*.  
- Akses ilegal akan langsung *403 Forbidden*.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect6 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT6:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT6.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT7 (ANTI AKSES FILE & DOWNLOAD) =========================
bot.onText(/^\/installprotect7$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/FileController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Response;
use Illuminate\\Http\\JsonResponse;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Wings\\DaemonFileRepository;
use Pterodactyl\\Transformers\\Api\\Client\\FileObjectTransformer;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\{
    CopyFileRequest, PullFileRequest, ListFilesRequest, ChmodFilesRequest,
    DeleteFileRequest, RenameFileRequest, CreateFolderRequest,
    CompressFilesRequest, DecompressFilesRequest, GetFileContentsRequest, WriteFileContentRequest
};

class FileController extends ClientApiController
{
    public function __construct(
        private NodeJWTService $jwtService,
        private DaemonFileRepository $fileRepository
    ) {
        parent::__construct();
    }

    /**
     * 🔒 NDy DoubleProtect v3.3 — Cegah akses file server orang.
     */
    private function checkServerAccess($request, Server $server)
    {
        $authUser = Auth::user();

        if (!$authUser) {
            abort(403, '🚫 Tidak dapat memverifikasi pengguna. Silakan login ulang. ©NDyProtect');
        }

        if ($authUser->id === 1) {
            return;
        }

        if ($authUser->id !== $server->owner_id) {
            abort(403, "🚫 Kasihan gabisa yaaa? 😹 Ini bukan servermu! Akses ditolak total. ©Protect By @wilzzofficial");
        }
    }

    public function directory(ListFilesRequest $request, Server $server): array
    {
        $this->checkServerAccess($request, $server);

        $contents = $this->fileRepository
            ->setServer($server)
            ->getDirectory($request->get('directory') ?? '/');

        return $this->fractal->collection($contents)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    public function contents(GetFileContentsRequest $request, Server $server): Response
    {
        $this->checkServerAccess($request, $server);

        $response = $this->fileRepository->setServer($server)->getContent(
            $request->get('file'),
            config('pterodactyl.files.max_edit_size')
        );

        Activity::event('server:file.read')->property('file', $request->get('file'))->log();

        return new Response($response, Response::HTTP_OK, ['Content-Type' => 'text/plain']);
    }

    public function download(GetFileContentsRequest $request, Server $server): array
    {
        $this->checkServerAccess($request, $server);

        $token = $this->jwtService
            ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
            ->setUser($request->user())
            ->setClaims([
                'file_path' => rawurldecode($request->get('file')),
                'server_uuid' => $server->uuid,
            ])
            ->handle($server->node, $request->user()->id . $server->uuid);

        Activity::event('server:file.download')->property('file', $request->get('file'))->log();

        return [
            'object' => 'signed_url',
            'attributes' => [
                'url' => sprintf('%s/download/file?token=%s', $server->node->getConnectionAddress(), $token->toString()),
            ],
        ];
    }

    public function write(WriteFileContentRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->putContent($request->get('file'), $request->getContent());
        Activity::event('server:file.write')->property('file', $request->get('file'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function create(CreateFolderRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->createDirectory($request->input('name'), $request->input('root', '/'));

        Activity::event('server:file.create-directory')
            ->property('name', $request->input('name'))
            ->property('directory', $request->input('root'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function rename(RenameFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->renameFiles($request->input('root'), $request->input('files'));

        Activity::event('server:file.rename')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function copy(CopyFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->copyFile($request->input('location'));
        Activity::event('server:file.copy')->property('file', $request->input('location'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function compress(CompressFilesRequest $request, Server $server): array
    {
        $this->checkServerAccess($request, $server);

        $file = $this->fileRepository->setServer($server)->compressFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.compress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return $this->fractal->item($file)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    public function decompress(DecompressFilesRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        set_time_limit(300);

        $this->fileRepository->setServer($server)->decompressFile(
            $request->input('root'),
            $request->input('file')
        );

        Activity::event('server:file.decompress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('file'))
            ->log();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }

    public function delete(DeleteFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->deleteFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.delete')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function chmod(ChmodFilesRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->chmodFiles(
            $request->input('root'),
            $request->input('files')
        );

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function pull(PullFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->pull(
            $request->input('url'),
            $request->input('directory'),
            $request->safe(['filename', 'use_header', 'foreground'])
        );

        Activity::event('server:file.pull')
            ->property('directory', $request->input('directory'))
            ->property('url', $request->input('url'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "FileController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT7 (ANTI AKSES FILE & DOWNLOAD SERVER) BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Mencegah user membuka, edit, download, rename, copy, dan browse file *server orang lain*.

🔐 Hanya *Admin ID 1 & Owner server* yang bisa akses direktori.
🚫 User lain otomatis *403 Forbidden*.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect7 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT7:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT7.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT8 (ANTI INTIP SERVER) =========================
bot.onText(/^\/installprotect8$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/ServerController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Transformers\\Api\\Client\\ServerTransformer;
use Pterodactyl\\Services\\Servers\\GetUserPermissionsService;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\GetServerRequest;

class ServerController extends ClientApiController
{
    public function __construct(private GetUserPermissionsService $permissionsService)
    {
        parent::__construct();
    }

    /**
     * 🧱 NDy Anti-Intip Server Protect v2.5
     * Hanya Admin utama (ID 1) atau pemilik server yang dapat melihat detail server.
     */
    public function index(GetServerRequest $request, Server $server): array
    {
        $authUser = Auth::user();

        if (!$authUser) {
            abort(403, '🚫 Tidak dapat memverifikasi pengguna. Silakan login ulang.');
        }

        if ($authUser->id !== 1 && (int) $server->owner_id !== (int) $authUser->id) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) atau pemilik server yang dapat melihat server ini! ©Protect By @wilzzofficial');
        }

        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->addMeta([
                'is_server_owner' => $authUser->id === $server->owner_id,
                'user_permissions' => $this->permissionsService->handle($server, $authUser),
            ])
            ->toArray();
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "ServerController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT8 (ANTI INTIP SERVER) BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Mencegah user melihat detail server orang lain (*anti intip*).

🔐 Hanya *Admin ID 1 & Owner server* yang dapat membuka halaman Server.  
🚫 User lain otomatis *403 Forbidden*.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect8 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT8:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT8.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT9 (ANTI INTIP APIKEY) =========================
bot.onText(/^\/installprotect9$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/ApiController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\ApiKey;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Services\\Acl\\Api\\AdminAcl;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Api\\KeyCreationService;
use Pterodactyl\\Contracts\\Repository\\ApiKeyRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Api\\StoreApplicationApiKeyRequest;

class ApiController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private ApiKeyRepositoryInterface $repository,
        private KeyCreationService $keyCreationService,
        private ViewFactory $view,
    ) {}

    /**
     * 🧱 NDy DoubleProtect v2.3 — Anti Intip APIKEY
     * Hanya Admin utama (ID 1) yang dapat mengakses menu APIKEY.
     */
    private function protectAccess()
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat mengakses halaman APIKEY! ©Protect By @wilzzofficial');
        }
    }

    public function index(Request $request): View
    {
        $this->protectAccess();

        return $this->view->make('admin.api.index', [
            'keys' => $this->repository->getApplicationKeys($request->user()),
        ]);
    }

    public function create(): View
    {
        $this->protectAccess();

        $resources = AdminAcl::getResourceList();
        sort($resources);

        return $this->view->make('admin.api.new', [
            'resources' => $resources,
            'permissions' => [
                'r' => AdminAcl::READ,
                'rw' => AdminAcl::READ | AdminAcl::WRITE,
                'n' => AdminAcl::NONE,
            ],
        ]);
    }

    public function store(StoreApplicationApiKeyRequest $request): RedirectResponse
    {
        $this->protectAccess();

        $this->keyCreationService->setKeyType(ApiKey::TYPE_APPLICATION)->handle([
            'memo' => $request->input('memo'),
            'user_id' => $request->user()->id,
        ], $request->getKeyPermissions());

        $this->alert->success('✅ API Key baru berhasil dibuat untuk Admin utama.')->flash();
        return redirect()->route('admin.api.index');
    }

    public function delete(Request $request, string $identifier): Response
    {
        $this->protectAccess();
        $this->repository->deleteApplicationKey($request->user(), $identifier);

        return response('', 204);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "ApiController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT9 (ANTI INTIP APIKEY) BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Membatasi akses Application API *khusus Admin ID 1*.

🔐 Hanya Admin 1 bisa membuka, membuat, dan menghapus APIKEY.
🚫 User lain otomatis *403 Forbidden* bahkan tidak bisa membuka menu tersebut.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect9 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT9:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT9.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT10 (ANTI CREATE CAPIKEY) =========================
bot.onText(/^\/installprotect10$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/ApiKeyController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client;

use Pterodactyl\\Models\\ApiKey;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Requests\\Api\\Client\\ClientApiRequest;
use Pterodactyl\\Transformers\\Api\\Client\\ApiKeyTransformer;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Account\\StoreApiKeyRequest;

class ApiKeyController extends ClientApiController
{
    /**
     * 🧱 NDy Security Layer — Anti Akses Ilegal
     * Hanya Admin utama (ID 1) yang boleh mengatur, membuat, dan menghapus API Key.
     */
    private function protectAccess($user)
    {
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengelola API Key! ©Protect By @wilzzofficial.');
        }
    }

    /**
     * 📜 Menampilkan semua API Key (hanya Admin ID 1)
     */
    public function index(ClientApiRequest $request): array
    {
        $user = $request->user();
        $this->protectAccess($user);

        return $this->fractal->collection($user->apiKeys)
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))
            ->toArray();
    }

    /**
     * 🧩 Membuat API Key baru (hanya Admin ID 1)
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function store(StoreApiKeyRequest $request): array
    {
        $user = $request->user();
        $this->protectAccess($user);

        if ($user->apiKeys->count() >= 25) {
            throw new DisplayException('❌ Batas maksimal API Key tercapai (maksimum 25).');
        }

        $token = $user->createToken(
            $request->input('description'),
            $request->input('allowed_ips')
        );

        Activity::event('user:api-key.create')
            ->subject($token->accessToken)
            ->property('identifier', $token->accessToken->identifier)
            ->log();

        return $this->fractal->item($token->accessToken)
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))
            ->addMeta(['secret_token' => $token->plainTextToken])
            ->toArray();
    }

    /**
     * ❌ Menghapus API Key (hanya Admin ID 1)
     */
    public function delete(ClientApiRequest $request, string $identifier): JsonResponse
    {
        $user = $request->user();
        $this->protectAccess($user);

        /** @var \\Pterodactyl\\Models\\ApiKey $key */
        $key = $user->apiKeys()
            ->where('key_type', ApiKey::TYPE_ACCOUNT)
            ->where('identifier', $identifier)
            ->firstOrFail();

        Activity::event('user:api-key.delete')
            ->property('identifier', $key->identifier)
            ->log();

        $key->delete();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "ApiKeyController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT10 ANTI CREATE CAPIKEY BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Membatasi *pembuatan & pengelolaan Client API Key hanya untuk Admin utama (ID 1)*.

🚫 User lain tidak dapat membuka menu Application API sama sekali.
🔐 Hanya Admin ID 1 yang bisa create, delete, dan melihat API Key.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy Security Layer`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect10 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT10:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT10.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT11 (ANTI INTIP DATABASE) =========================
bot.onText(/^\/installprotect11$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/DatabaseController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Exception;
use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Models\\DatabaseHost;
use Pterodactyl\\Http\\Requests\\Admin\\DatabaseHostFormRequest;
use Pterodactyl\\Services\\Databases\\Hosts\\HostCreationService;
use Pterodactyl\\Services\\Databases\\Hosts\\HostDeletionService;
use Pterodactyl\\Services\\Databases\\Hosts\\HostUpdateService;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseHostRepositoryInterface;

class DatabaseController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private DatabaseHostRepositoryInterface $repository,
        private DatabaseRepositoryInterface $databaseRepository,
        private HostCreationService $creationService,
        private HostDeletionService $deletionService,
        private HostUpdateService $updateService,
        private LocationRepositoryInterface $locationRepository,
        private ViewFactory $view
    ) {}

    /**
     * 🔒 Proteksi: hanya admin ID 1 yang boleh mengakses Database Section
     */
    private function checkAccess()
    {
        $user = auth()->user();

        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: hanya admin ID 1 yang dapat mengelola Database! ©Protect By @wilzzofficial');
        }
    }

    public function index(): View
    {
        $this->checkAccess();

        return $this->view->make('admin.databases.index', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'hosts' => $this->repository->getWithViewDetails(),
        ]);
    }

    public function view(int $host): View
    {
        $this->checkAccess();

        return $this->view->make('admin.databases.view', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'host' => $this->repository->find($host),
            'databases' => $this->databaseRepository->getDatabasesForHost($host),
        ]);
    }

    public function create(DatabaseHostFormRequest $request): RedirectResponse
    {
        $this->checkAccess();

        try {
            $host = $this->creationService->handle($request->normalize());
        } catch (Exception $exception) {
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('❌ Gagal konek ke host DB: %s', $exception->getMessage())
                )->flash();
                return redirect()->route('admin.databases')->withInput($request->validated());
            }

            throw $exception;
        }

        $this->alert->success('✅ Database host berhasil dibuat.')->flash();
        return redirect()->route('admin.databases.view', $host->id);
    }

    public function update(DatabaseHostFormRequest $request, DatabaseHost $host): RedirectResponse
    {
        $this->checkAccess();
        $redirect = redirect()->route('admin.databases.view', $host->id);

        try {
            $this->updateService->handle($host->id, $request->normalize());
            $this->alert->success('✅ Database host berhasil diperbarui.')->flash();
        } catch (Exception $exception) {
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('❌ Error koneksi DB: %s', $exception->getMessage())
                )->flash();
                return $redirect->withInput($request->normalize());
            }

            throw $exception;
        }

        return $redirect;
    }

    public function delete(int $host): RedirectResponse
    {
        $this->checkAccess();

        $this->deletionService->handle($host);
        $this->alert->success('🗑️ Database host berhasil dihapus.')->flash();

        return redirect()->route('admin.databases');
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "DatabaseController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT11 ANTI INTIP DATABASE BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Menutup akses menu Database untuk semua user selain Admin utama (ID 1).

🔐 Admin ID 1 bisa melihat, membuat, edit dan delete DB Host.
🚫 User lain langsung 403 dan tidak dapat melihat node & database.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy Security Layer`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect11 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT11:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal memasang PROTECT11.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT12 (ANTI INTIP MOUNTS) =========================
bot.onText(/^\/installprotect12$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/MountController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Ramsey\\Uuid\\Uuid;
use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Nest;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Location;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\MountFormRequest;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class MountController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestRepositoryInterface $nestRepository,
        protected LocationRepositoryInterface $locationRepository,
        protected MountRepository $repository,
        protected ViewFactory $view
    ) {}

    private function checkAdminAccess()
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: hanya Admin utama (ID 1) yang boleh akses Mount! ©Protect By @wilzzofficial');
        }
    }

    private function globalProtect()
    {
        $this->checkAdminAccess();
    }

    public function index(): View
    {
        $this->globalProtect();
        return $this->view->make('admin.mounts.index', [
            'mounts' => $this->repository->getAllWithDetails(),
        ]);
    }

    public function view(string $id): View
    {
        $this->globalProtect();
        $nests = Nest::query()->with('eggs')->get();
        $locations = Location::query()->with('nodes')->get();

        return $this->view->make('admin.mounts.view', [
            'mount' => $this->repository->getWithRelations($id),
            'nests' => $nests,
            'locations' => $locations,
        ]);
    }

    public function create(MountFormRequest $request): RedirectResponse
    {
        $this->globalProtect();

        $model = (new Mount())->fill($request->validated());
        $model->forceFill(['uuid' => Uuid::uuid4()->toString()]);
        $model->saveOrFail();
        $mount = $model->fresh();

        $this->alert->success('Mount was created successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function update(MountFormRequest $request, Mount $mount): RedirectResponse
    {
        $this->globalProtect();

        if ($request->input('action') === 'delete') {
            return $this->delete($mount);
        }

        $mount->forceFill($request->validated())->save();
        $this->alert->success('Mount was updated successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function delete(Mount $mount): RedirectResponse
    {
        $this->globalProtect();
        $mount->delete();
        return redirect()->route('admin.mounts');
    }

    public function addEggs(Request $request, Mount $mount): RedirectResponse
    {
        $this->globalProtect();
        $data = $request->validate(['eggs' => 'required|exists:eggs,id']);
        if (count($data['eggs']) > 0) $mount->eggs()->attach($data['eggs']);
        $this->alert->success('Mount was updated successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function addNodes(Request $request, Mount $mount): RedirectResponse
    {
        $this->globalProtect();
        $data = $request->validate(['nodes' => 'required|exists:nodes,id']);
        if (count($data['nodes']) > 0) $mount->nodes()->attach($data['nodes']);
        $this->alert->success('Mount was updated successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function deleteEgg(Mount $mount, int $egg_id): Response
    {
        $this->globalProtect();
        $mount->eggs()->detach($egg_id);
        return response('', 204);
    }

    public function deleteNode(Mount $mount, int $node_id): Response
    {
        $this->globalProtect();
        $mount->nodes()->detach($node_id);
        return response('', 204);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "MountController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT12 ANTI INTIP MOUNTS BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Menutup akses menu Mounts untuk semua user selain Admin utama (ID 1).

🔐 Hanya Admin ID 1 bisa melihat, create, edit, atau delete Mount.
🚫 User lain otomatis *403 Access Denied*.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — DoubleProtect v3.5`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect12 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT12:", err);
    bot.sendMessage(chatId, `❌ Gagal memasang PROTECT12.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
  }
});
// ========================= 🛡️ INSTALL PROTECT13 (ANTI BUTTON TWO FACTOR) =========================
bot.onText(/^\/installprotect13$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/TwoFactorController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client;

use Carbon\\Carbon;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Users\\TwoFactorSetupService;
use Pterodactyl\\Services\\Users\\ToggleTwoFactorService;
use Illuminate\\Contracts\\Validation\\Factory as ValidationFactory;
use Symfony\\Component\\HttpKernel\\Exception\\BadRequestHttpException;

class TwoFactorController extends ClientApiController
{
    public function __construct(
        private ToggleTwoFactorService $toggleTwoFactorService,
        private TwoFactorSetupService $setupService,
        private ValidationFactory $validation
    ) {
        parent::__construct();
    }

    public function index(Request $request): JsonResponse
    {
        if ($request->user()->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat mengatur Two-Step Verification. ©Protect By @wilzzofficial');
        }

        if ($request->user()->use_totp) {
            throw new BadRequestHttpException('Two-factor authentication is already enabled on this account.');
        }

        return new JsonResponse([
            'data' => $this->setupService->handle($request->user()),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        if ($request->user()->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat mengaktifkan Two-Step Verification. ©Protect By @wilzzofficial');
        }

        $validator = $this->validation->make($request->all(), [
            'code' => ['required', 'string', 'size:6'],
            'password' => ['required', 'string'],
        ]);

        $data = $validator->validate();
        if (!password_verify($data['password'], $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        $tokens = $this->toggleTwoFactorService->handle($request->user(), $data['code'], true);
        Activity::event('user:two-factor.create')->log();

        return new JsonResponse([
            'object' => 'recovery_tokens',
            'attributes' => ['tokens' => $tokens],
        ]);
    }

    public function delete(Request $request): JsonResponse
    {
        if ($request->user()->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat menonaktifkan Two-Step Verification. ©Protect By @wilzzofficial');
        }

        if (!password_verify($request->input('password') ?? '', $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        $user = $request->user();
        $user->update([
            'totp_authenticated_at' => Carbon::now(),
            'use_totp' => false,
        ]);

        Activity::event('user:two-factor.delete')->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "TwoFactorController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT13 ANTI BUTTON TWO FACTOR BERHASIL DIPASANG!*

⚙️ *Fungsi:*  
Menutup akses Two Step Verification untuk semua user selain Admin utama (ID 1).

🔐 Only Admin ID 1 dapat enable / disable 2FA.
🚫 User lain otomatis *403 Akses Ditolak* dengan pesan lucu.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — TwoFactorGuard v1.0`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect13 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT13:", err);
    bot.sendMessage(chatId, `❌ Gagal memasang PROTECT13.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
  }
});
// ========================= 🛡️ INSTALL PROTECT13 (ANTI BUTTON TWO FACTOR) =========================
bot.onText(/^\/installprotect14$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/resources/views/layouts/admin.blade.php";

  const phpCode = `<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="{{ csrf_token() }}">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#0e4688">

        @include('layouts.scripts')

        @section('scripts')
            {!! Theme::css('vendor/select2/select2.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/admin.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/animate/animate.min.css?t={cache-version}') !!}
            {!! Theme::css('css/pterodactyl.css?t={cache-version}') !!}
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        @show
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="{{ route('index') }}" class="logo">
                    <span>{{ config('app.name', 'Pterodactyl') }}</span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="user-menu">
                                <a href="{{ route('account') }}">
                                    <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs">{{ Auth::user()->name_first }} {{ Auth::user()->name_last }}</span>
                                </a>
                            </li>
                            <li>
                                <li><a href="{{ route('index') }}" data-toggle="tooltip" data-placement="bottom" title="Exit Admin Control"><i class="fa fa-server"></i></a></li>
                            </li>
                            <li>
                                <li><a href="{{ route('auth.logout') }}" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li class="header">BASIC ADMINISTRATION</li>
                        <li class="{{ Route::currentRouteName() !== 'admin.index' ?: 'active' }}">
                            <a href="{{ route('admin.index') }}">
                                <i class="fa fa-home"></i> <span>Overview</span>
                            </a>
                        </li>
{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.settings') ?: 'active' }}">
    <a href="{{ route('admin.settings') }}">
        <i class="fa fa-wrench"></i> <span>Settings</span>
    </a>
</li>
@endif
{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.api') ?: 'active' }}">
    <a href="{{ route('admin.api.index')}}">
        <i class="fa fa-gamepad"></i> <span>Application API</span>
    </a>
</li>
@endif
<li class="header">MANAGEMENT</li>

{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.databases') ?: 'active' }}">
    <a href="{{ route('admin.databases') }}">
        <i class="fa fa-database"></i> <span>Databases</span>
    </a>
</li>
@endif

{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.locations') ?: 'active' }}">
    <a href="{{ route('admin.locations') }}">
        <i class="fa fa-globe"></i> <span>Locations</span>
    </a>
</li>
@endif

{{-- ✅ Hanya tampil untuk user dengan ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nodes') ?: 'active' }}">
    <a href="{{ route('admin.nodes') }}">
        <i class="fa fa-sitemap"></i> <span>Nodes</span>
    </a>
</li>
@endif

                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.servers') ?: 'active' }}">
                            <a href="{{ route('admin.servers') }}">
                                <i class="fa fa-server"></i> <span>Servers</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active' }}">
                            <a href="{{ route('admin.users') }}">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
{{-- ✅ Hanya tampil untuk admin utama --}}
@if(Auth::user()->id == 1)
    <li class="header">SERVICE MANAGEMENT</li>

    <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.mounts') ?: 'active' }}">
        <a href="{{ route('admin.mounts') }}">
            <i class="fa fa-magic"></i> <span>Mounts</span>
        </a>
    </li>

    <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nests') ?: 'active' }}">
        <a href="{{ route('admin.nests') }}">
            <i class="fa fa-th-large"></i> <span>Nests</span>
        </a>
    </li>
@endif
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    @yield('content-header')
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    There was an error validating the data provided.<br><br>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @foreach (Alert::getMessages() as $type => $messages)
                                @foreach ($messages as $message)
                                    <div class="alert alert-{{ $type }} alert-dismissable" role="alert">
                                        {!! $message !!}
                                    </div>
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                    @yield('content')
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw {{ $appIsGit ? 'fa-git-square' : 'fa-code-fork' }}"></i></strong> {{ $appVersion }}<br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> {{ round(microtime(true) - LARAVEL_START, 3) }}s
                </div>
                Copyright &copy; 2015 - {{ date('Y') }} <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
            </footer>
        </div>
        @section('footer-scripts')
            <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
            <script>keyboardeventKeyPolyfill.polyfill();</script>

            {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/adminlte/app.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/select2/select2.full.min.js?t={cache-version}') !!}
            {!! Theme::js('js/admin/functions.js?t={cache-version}') !!}
            <script src="/js/autocomplete.js" type="application/javascript"></script>

            @if(Auth::user()->root_admin)
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        var that = this;
                        swal({
                            title: 'Do you want to log out?',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Log out'
                        }, function () {
                             $.ajax({
                                type: 'POST',
                                url: '{{ route('auth.logout') }}',
                                data: {
                                    _token: '{{ csrf_token() }}'
                                },complete: function () {
                                    window.location.href = '{{route('auth.login')}}';
                                }
                        });
                    });
                });
                </script>
            @endif

            <script>
                $(function () {
                    $('[data-toggle="tooltip"]').tooltip();
                })
            </script>
        @show
    </body>
</html>`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "admin.blade.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT14 𝗠𝗘𝗡𝗚𝗛𝗜𝗟𝗔𝗡𝗚𝗞𝗔𝗡 𝗕𝗔𝗥 𝗠𝗘𝗡𝗨 “𝗡𝗢𝗗𝗘𝗦, 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡𝗦, 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘, 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦, 𝗔𝗣𝗣𝗟𝗜𝗖𝗔𝗧𝗜𝗢𝗡 𝗔𝗣𝗜, 𝗠𝗢𝗨𝗡𝗧𝗦, 𝗡𝗘𝗦𝗧*

⚙️ *Fungsi:*  
User biasa (selain ID 1) tidak akan melihat menu tersebut sama sekali, menjadikan tampilan panel lebih sederhana, bersih, dan aman.

🔐 Only Admin ID 1 dapat enable / disable 2FA.
🚫 User lain otomatis *403 Akses Ditolak* dengan pesan lucu.

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect14 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT14:", err);
    bot.sendMessage(chatId, `❌ Gagal memasang PROTECT14.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
  }
});
// ========================= ⚙️ INSTALL PROTECT ALL (PROTECT1–15 SEKALIGUS) =========================
bot.onText(/^\/installprotectall$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  await bot.sendMessage(chatId, "🧩 *Memulai instalasi semua proteksi...*\nHarap tunggu beberapa saat ⏳", {
    parse_mode: "Markdown",
  });

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    // ========================= PATHS =========================
    const protectFiles = [
      {
        name: "PROTECT1 (Anti Intip Server In Settings)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Nest;
use Pterodactyl\\Models\\Location;
use Spatie\\QueryBuilder\\QueryBuilder;
use Spatie\\QueryBuilder\\AllowedFilter;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Models\\Filters\\AdminServerFilter;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;

class ServerController extends Controller
{
    /**
     * Konstruktor
     */
    public function __construct(private ViewFactory $view)
    {
    }

/**
 * 📋 Daftar server — hanya tampilkan milik sendiri kecuali admin ID 1
 */
public function index(Request $request): View
{
    $user = Auth::user();

    // Ambil query dasar
$query = Server::query()
    ->with(['node', 'user', 'allocation'])
    ->orderBy('id', 'asc'); // server baru di bawah

    // NDyProtect v1.5 — Batasi query utama
    if ($user->id !== 1) {
        $query->where('owner_id', $user->id);
    }

    // Gunakan QueryBuilder tapi tetap batasi hasil user
    $servers = QueryBuilder::for($query)
        ->allowedFilters([
            AllowedFilter::exact('owner_id'),
            AllowedFilter::custom('*', new AdminServerFilter()),
        ])
        ->when($request->has('filter') && isset($request->filter['search']), function ($q) use ($request) {
            $search = $request->filter['search'];
            $q->where(function ($sub) use ($search) {
                $sub->where('name', 'like', "%{$search}%")
                    ->orWhere('uuidShort', 'like', "%{$search}%")
                    ->orWhere('uuid', 'like', "%{$search}%");
            });
        })
        ->paginate(config('pterodactyl.paginate.admin.servers'))
        ->appends($request->query());

    return $this->view->make('admin.servers.index', ['servers' => $servers]);
}

    /**
     * 🧱 Form buat server baru
     */
    public function create(): View
    {
        $user = Auth::user();

        if ($user->id === 1) {
            // Admin ID 1 bisa pilih owner siapa pun
            $users = User::all();
            $lock_owner = false;
            $auto_owner = null;
        } else {
            // User biasa hanya bisa membuat server untuk dirinya sendiri
            $users = collect([$user]);
            $lock_owner = true;
            $auto_owner = $user;
        }

        return $this->view->make('admin.servers.new', [
            'users' => $users,
            'lock_owner' => $lock_owner,
            'auto_owner' => $auto_owner,
            'locations' => Location::with('nodes')->get(),
            'nests' => Nest::with('eggs')->get(),
        ]);
    }

    /**
     * 🔍 Detail/Edit Server — hanya pemilik server atau admin ID 1
     */
    public function view(Server $server): View
    {
        $user = Auth::user();

        if ($user->id !== 1 && $server->owner_id !== $user->id) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat melihat atau mengedit server ini! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.servers.view', ['server' => $server]);
    }

    /**
     * 🛠 Update Server — hanya pemilik server atau admin ID 1
     */
    public function update(Request $request, Server $server)
    {
        $user = Auth::user();

        if ($user->id !== 1 && $server->owner_id !== $user->id) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat mengubah server ini! ©Protect By @wilzzofficial.');
        }

        // Lindungi agar user biasa tidak bisa ubah owner_id
        $data = $request->except(['owner_id']);

        $server->update($data);

        return redirect()->route('admin.servers.view', $server->id)
            ->with('success', '✅ Server berhasil diperbarui.');
    }

    /**
     * ❌ Hapus Server — hanya Admin ID 1
     */
    public function destroy(Server $server)
    {
        $user = Auth::user();

        if ($user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat menghapus server ini! ©Protect By @wilzzofficial.');
        }

        $server->delete();

        return redirect()->route('admin.servers')
            ->with('success', '🗑️ Server berhasil dihapus.');
    }
}`
      },
      {
        name: "PROTECT1 (Otomatis Isi Server Owner)",
        path: "/var/www/pterodactyl/resources/views/admin/servers/new.blade.php",
        file: "new.blade.php",
        code: `@extends('layouts.admin')

@section('title')
    New Server
@endsection

@section('content-header')
    <h1>Create Server<small>Add a new server to the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.servers') }}">Servers</a></li>
        <li class="active">Create Server</li>
    </ol>
@endsection

@section('content')
<form action="{{ route('admin.servers.new') }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Core Details</h3>
                </div>

                <div class="box-body row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pName">Server Name</label>
                            <input type="text" class="form-control" id="pName" name="name" value="{{ old('name') }}" placeholder="Server Name">
                            <p class="small text-muted no-margin">Character limits: <code>a-z A-Z 0-9 _ - .</code> and <code>[Space]</code>.</p>
                        </div>

<div class="form-group">
    <label for="pUserId">Server Owner</label>

    @if(Auth::user()->id == 1)
        {{-- Admin ID 1: bisa isi manual --}}
        <select id="pUserId" name="owner_id" class="form-control">
            <option value="">Select a User</option>
            @foreach(\\Pterodactyl\\Models\\User::all() as $user)
                <option value="{{ $user->id }}" @selected(old('owner_id') == $user->id)>
                    {{ $user->username }} ({{ $user->email }})
                </option>
            @endforeach
        </select>
        <p class="small text-muted no-margin">As admin, you can manually choose the server owner.</p>
    @else
        {{-- Selain admin ID 1: otomatis --}}
        <input type="hidden" id="pUserId" name="owner_id" value="{{ Auth::user()->id }}">
        <input type="text" class="form-control" value="{{ Auth::user()->email }}" disabled>
        <p class="small text-muted no-margin">This server will be owned by your account automatically.</p>
    @endif
</div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pDescription" class="control-label">Server Description</label>
                            <textarea id="pDescription" name="description" rows="3" class="form-control">{{ old('description') }}</textarea>
                            <p class="text-muted small">A brief description of this server.</p>
                        </div>

                        <div class="form-group">
                            <div class="checkbox checkbox-primary no-margin-bottom">
                                <input id="pStartOnCreation" name="start_on_completion" type="checkbox" {{ \\Pterodactyl\\Helpers\\Utilities::checked('start_on_completion', 1) }} />
                                <label for="pStartOnCreation" class="strong">Start Server when Installed</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Allocation Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-sm-4">
                        <label for="pNodeId">Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->long }} ({{ $location->short }})">
                                @foreach($location->nodes as $node)

                                <option value="{{ $node->id }}"
                                    @if($location->id === old('location_id')) selected @endif
                                >{{ $node->name }}</option>

                                @endforeach
                                </optgroup>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">The node which this server will be deployed to.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocation">Default Allocation</label>
                        <select id="pAllocation" name="allocation_id" class="form-control"></select>
                        <p class="small text-muted no-margin">The main allocation that will be assigned to this server.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocationAdditional">Additional Allocation(s)</label>
                        <select id="pAllocationAdditional" name="allocation_additional[]" class="form-control" multiple></select>
                        <p class="small text-muted no-margin">Additional allocations to assign to this server on creation.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Application Feature Limits</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDatabaseLimit" class="control-label">Database Limit</label>
                        <div>
                            <input type="text" id="pDatabaseLimit" name="database_limit" class="form-control" value="{{ old('database_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of databases a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pAllocationLimit" class="control-label">Allocation Limit</label>
                        <div>
                            <input type="text" id="pAllocationLimit" name="allocation_limit" class="form-control" value="{{ old('allocation_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of allocations a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pBackupLimit" class="control-label">Backup Limit</label>
                        <div>
                            <input type="text" id="pBackupLimit" name="backup_limit" class="form-control" value="{{ old('backup_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of backups that can be created for this server.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Resource Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pCPU">CPU Limit</label>

                        <div class="input-group">
                            <input type="text" id="pCPU" name="cpu" class="form-control" value="{{ old('cpu', 0) }}" />
                            <span class="input-group-addon">%</span>
                        </div>

                        <p class="text-muted small">If you do not want to limit CPU usage, set the value to <code>0</code>. To determine a value, take the number of threads and multiply it by 100. For example, on a quad core system without hyperthreading <code>(4 * 100 = 400)</code> there is <code>400%</code> available. To limit a server to using half of a single thread, you would set the value to <code>50</code>. To allow a server to use up to two threads, set the value to <code>200</code>.<p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pThreads">CPU Pinning</label>

                        <div>
                            <input type="text" id="pThreads" name="threads" class="form-control" value="{{ old('threads') }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced:</strong> Enter the specific CPU threads that this process can run on, or leave blank to allow all threads. This can be a single number, or a comma separated list. Example: <code>0</code>, <code>0-1,3</code>, or <code>0,1,3,4</code>.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pMemory">Memory</label>

                        <div class="input-group">
                            <input type="text" id="pMemory" name="memory" class="form-control" value="{{ old('memory') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">The maximum amount of memory allowed for this container. Setting this to <code>0</code> will allow unlimited memory in a container.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pSwap">Swap</label>

                        <div class="input-group">
                            <input type="text" id="pSwap" name="swap" class="form-control" value="{{ old('swap', 0) }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">Setting this to <code>0</code> will disable swap space on this server. Setting to <code>-1</code> will allow unlimited swap.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDisk">Disk Space</label>

                        <div class="input-group">
                            <input type="text" id="pDisk" name="disk" class="form-control" value="{{ old('disk') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">This server will not be allowed to boot if it is using more than this amount of space. If a server goes over this limit while running it will be safely stopped and locked until enough space is available. Set to <code>0</code> to allow unlimited disk usage.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pIO">Block IO Weight</label>

                        <div>
                            <input type="text" id="pIO" name="io" class="form-control" value="{{ old('io', 500) }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced</strong>: The IO performance of this server relative to other <em>running</em> containers on the system. Value should be between <code>10</code> and <code>1000</code>. Please see <a href="https://docs.docker.com/engine/reference/run/#block-io-bandwidth-blkio-constraint" target="_blank">this documentation</a> for more information about it.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pOomDisabled" name="oom_disabled" value="0" {{ \\Pterodactyl\\Helpers\\Utilities::checked('oom_disabled', 0) }} />
                            <label for="pOomDisabled" class="strong">Enable OOM Killer</label>
                        </div>

                        <p class="small text-muted no-margin">Terminates the server if it breaches the memory limits. Enabling OOM killer may cause server processes to exit unexpectedly.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nest Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pNestId">Nest</label>

                        <select id="pNestId" name="nest_id" class="form-control">
                            @foreach($nests as $nest)
                                <option value="{{ $nest->id }}"
                                    @if($nest->id === old('nest_id'))
                                        selected="selected"
                                    @endif
                                >{{ $nest->name }}</option>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">Select the Nest that this server will be grouped under.</p>
                    </div>

                    <div class="form-group col-xs-12">
                        <label for="pEggId">Egg</label>
                        <select id="pEggId" name="egg_id" class="form-control"></select>
                        <p class="small text-muted no-margin">Select the Egg that will define how this server should operate.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pSkipScripting" name="skip_scripts" value="1" {{ \\Pterodactyl\\Helpers\\Utilities::checked('skip_scripts', 0) }} />
                            <label for="pSkipScripting" class="strong">Skip Egg Install Script</label>
                        </div>

                        <p class="small text-muted no-margin">If the selected Egg has an install script attached to it, the script will run during the install. If you would like to skip this step, check this box.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Docker Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pDefaultContainer">Docker Image</label>
                        <select id="pDefaultContainer" name="image" class="form-control"></select>
                        <input id="pDefaultContainerCustom" name="custom_image" value="{{ old('custom_image') }}" class="form-control" placeholder="Or enter a custom image..." style="margin-top:1rem"/>
                        <p class="small text-muted no-margin">This is the default Docker image that will be used to run this server. Select an image from the dropdown above, or enter a custom image in the text field above.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Startup Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pStartup">Startup Command</label>
                        <input type="text" id="pStartup" name="startup" value="{{ old('startup') }}" class="form-control" />
                        <p class="small text-muted no-margin">The following data substitutes are available for the startup command: <code>@{{SERVER_MEMORY}}</code>, <code>@{{SERVER_IP}}</code>, and <code>@{{SERVER_PORT}}</code>. They will be replaced with the allocated memory, server IP, and server port respectively.</p>
                    </div>
                </div>

                <div class="box-header with-border" style="margin-top:-10px;">
                    <h3 class="box-title">Service Variables</h3>
                </div>

                <div class="box-body row" id="appendVariablesTo"></div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    <input type="submit" class="btn btn-success pull-right" value="Create Server" />
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('vendor/lodash/lodash.js') !!}

    <script type="application/javascript">
        // Persist 'Service Variables'
        function serviceVariablesUpdated(eggId, ids) {
            @if (old('egg_id'))
                // Check if the egg id matches.
                if (eggId != '{{ old('egg_id') }}') {
                    return;
                }

                @if (old('environment'))
                    @foreach (old('environment') as $key => $value)
                        $('#' + ids['{{ $key }}']).val('{{ $value }}');
                    @endforeach
                @endif
            @endif
            @if(old('image'))
                $('#pDefaultContainer').val('{{ old('image') }}');
            @endif
        }
        // END Persist 'Service Variables'
    </script>

    {!! Theme::js('js/admin/new-server.js?v=20220530') !!}

    <script type="application/javascript">
        $(document).ready(function() {
// Persist 'Server Owner' select2
// (Removed because Server Owner now auto-fills based on logged-in user)
// END Persist 'Server Owner' select2

            // Persist 'Node' select2
            @if (old('node_id'))
                $('#pNodeId').val('{{ old('node_id') }}').change();

                // Persist 'Default Allocation' select2
                @if (old('allocation_id'))
                    $('#pAllocation').val('{{ old('allocation_id') }}').change();
                @endif
                // END Persist 'Default Allocation' select2

                // Persist 'Additional Allocations' select2
                @if (old('allocation_additional'))
                    const additional_allocations = [];

                    @for ($i = 0; $i < count(old('allocation_additional')); $i++)
                        additional_allocations.push('{{ old('allocation_additional.'.$i)}}');
                    @endfor

                    $('#pAllocationAdditional').val(additional_allocations).change();
                @endif
                // END Persist 'Additional Allocations' select2
            @endif
            // END Persist 'Node' select2

            // Persist 'Nest' select2
            @if (old('nest_id'))
                $('#pNestId').val('{{ old('nest_id') }}').change();

                // Persist 'Egg' select2
                @if (old('egg_id'))
                    $('#pEggId').val('{{ old('egg_id') }}').change();
                @endif
                // END Persist 'Egg' select2
            @endif
            // END Persist 'Nest' select2
        });
    </script>
@endsection
`
      },
      {
        name: "PROTECT1 (Anti Update Detail Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/DetailsModificationService.php",
        file: "DetailsModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\ReturnsUpdatedModels;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class DetailsModificationService
{
    use ReturnsUpdatedModels;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $serverRepository
    ) {
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Edit Server
     * Mencegah user non-admin mengubah detail server milik orang lain.
     */
    public function handle(Server $server, array $data): Server
    {
        $user = Auth::user();

        // Proteksi: hanya Admin ID 1 boleh ubah detail server orang lain
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah detail server milik orang lain! ©Protect By @wilzzofficial'
                );
            }
        }

        // Jalankan proses bawaan
        return $this->connection->transaction(function () use ($data, $server) {
            $owner = $server->owner_id;

            $server->forceFill([
                'external_id' => Arr::get($data, 'external_id'),
                'owner_id' => Arr::get($data, 'owner_id'),
                'name' => Arr::get($data, 'name'),
                'description' => Arr::get($data, 'description') ?? '',
            ])->saveOrFail();

            // Jika owner diganti, cabut akses owner lama di Wings
            if ($server->owner_id !== $owner) {
                try {
                    $this->serverRepository->setServer($server)->revokeUserJTI($owner);
                } catch (DaemonConnectionException $exception) {
                    // Abaikan error jika Wings sedang offline
                }
            }

            return $server;
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Build Configuration Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/BuildModificationService.php",
        file: "BuildModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Allocation;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Support\\Facades\\Auth;
use Illuminate\\Database\\Eloquent\\ModelNotFoundException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class BuildModificationService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private ServerConfigurationStructureService $structureService
    ) {
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Build Abuse
     * Mencegah user non-admin mengubah konfigurasi Build server milik orang lain.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server, array $data): Server
    {
        $user = Auth::user();

        // NDyProtect — Cegah user biasa ubah konfigurasi server yang bukan miliknya
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah Build Configuration server orang lain! ©Protect By @wilzzofficial'
                );
            }
        }

        // Jalankan proses asli (tetap sama dengan bawaan Pterodactyl)
        /** @var \\Pterodactyl\\Models\\Server $server */
        $server = $this->connection->transaction(function () use ($server, $data) {
            $this->processAllocations($server, $data);

            if (isset($data['allocation_id']) && $data['allocation_id'] != $server->allocation_id) {
                try {
                    Allocation::query()
                        ->where('id', $data['allocation_id'])
                        ->where('server_id', $server->id)
                        ->firstOrFail();
                } catch (ModelNotFoundException) {
                    throw new DisplayException('The requested default allocation is not currently assigned to this server.');
                }
            }

            $merge = Arr::only($data, [
                'oom_disabled',
                'memory',
                'swap',
                'io',
                'cpu',
                'threads',
                'disk',
                'allocation_id',
            ]);

            $server->forceFill(array_merge($merge, [
                'database_limit' => Arr::get($data, 'database_limit', 0) ?? null,
                'allocation_limit' => Arr::get($data, 'allocation_limit', 0) ?? null,
                'backup_limit' => Arr::get($data, 'backup_limit', 0) ?? 0,
            ]))->saveOrFail();

            return $server->refresh();
        });

        $updateData = $this->structureService->handle($server);

        if (!empty($updateData['build'])) {
            try {
                $this->daemonServerRepository->setServer($server)->sync();
            } catch (DaemonConnectionException $exception) {
                Log::warning($exception, ['server_id' => $server->id]);
            }
        }

        return $server;
    }

    /**
     * Proses alokasi (port) untuk server.
     */
    private function processAllocations(Server $server, array &$data): void
    {
        if (empty($data['add_allocations']) && empty($data['remove_allocations'])) {
            return;
        }

        if (!empty($data['add_allocations'])) {
            $query = Allocation::query()
                ->where('node_id', $server->node_id)
                ->whereIn('id', $data['add_allocations'])
                ->whereNull('server_id');

            $freshlyAllocated = $query->pluck('id')->first();

            $query->update(['server_id' => $server->id, 'notes' => null]);
        }

        if (!empty($data['remove_allocations'])) {
            foreach ($data['remove_allocations'] as $allocation) {
                if ($allocation === ($data['allocation_id'] ?? $server->allocation_id)) {
                    if (empty($freshlyAllocated)) {
                        throw new DisplayException(
                            'You are attempting to delete the default allocation for this server but there is no fallback allocation to use.'
                        );
                    }
                    $data['allocation_id'] = $freshlyAllocated;
                }
            }

            Allocation::query()
                ->where('node_id', $server->node_id)
                ->where('server_id', $server->id)
                ->whereIn('id', array_diff($data['remove_allocations'], $data['add_allocations'] ?? []))
                ->update([
                    'notes' => null,
                    'server_id' => null,
                ]);
        }
    }
}`
      },
      {
        name: "PROTECT1 (Anti Setup Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/StartupModificationService.php",
        file: "StartupModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Egg;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\ServerVariable;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\HasUserLevels;
use Pterodactyl\\Exceptions\\DisplayException;

class StartupModificationService
{
    use HasUserLevels;

    /**
     * StartupModificationService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private VariableValidatorService $validatorService
    ) {
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Startup Abuse
     * Mencegah user non-admin mengubah startup command server milik orang lain.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        // NDyProtect — Cegah user biasa ubah startup server bukan miliknya
        $user = auth()->user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException(
                    '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah startup command server orang lain! ©Protect By @wilzzofficial'
                );
            }
        }

        // Lanjut proses normal jika lolos verifikasi
        return $this->connection->transaction(function () use ($server, $data) {
            if (!empty($data['environment'])) {
                $egg = $this->isUserLevel(User::USER_LEVEL_ADMIN)
                    ? ($data['egg_id'] ?? $server->egg_id)
                    : $server->egg_id;

                $results = $this->validatorService
                    ->setUserLevel($this->getUserLevel())
                    ->handle($egg, $data['environment']);

                foreach ($results as $result) {
                    ServerVariable::query()->updateOrCreate(
                        [
                            'server_id' => $server->id,
                            'variable_id' => $result->id,
                        ],
                        ['variable_value' => $result->value ?? '']
                    );
                }
            }

            if ($this->isUserLevel(User::USER_LEVEL_ADMIN)) {
                $this->updateAdministrativeSettings($data, $server);
            }

            return $server->fresh();
        });
    }

    /**
     * Update certain administrative settings for a server in the DB.
     */
    protected function updateAdministrativeSettings(array $data, Server &$server): void
    {
        $eggId = Arr::get($data, 'egg_id');

        if (is_digit($eggId) && $server->egg_id !== (int) $eggId) {
            /** @var \\Pterodactyl\\Models\\Egg $egg */
            $egg = Egg::query()->findOrFail($data['egg_id']);

            $server = $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ]);
        }

        $server->fill([
            'startup' => $data['startup'] ?? $server->startup,
            'skip_scripts' => $data['skip_scripts'] ?? isset($data['skip_scripts']),
            'image' => $data['docker_image'] ?? $server->image,
        ])->save();
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Database)",
        path: "/var/www/pterodactyl/app/Services/Databases/DatabaseManagementService.php",
        file: "DatabaseManagementService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Databases;

use Exception;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Helpers\\Utilities;
use Illuminate\\Database\\ConnectionInterface;
use Illuminate\\Contracts\\Encryption\\Encrypter;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Extensions\\DynamicDatabaseConnection;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseRepository;
use Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException;
use Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException;
use Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Support\\Facades\\Log;

class DatabaseManagementService
{
    private const MATCH_NAME_REGEX = '/^(s[\\d]+_)(.*)$/';

    protected bool $validateDatabaseLimit = true;

    public function __construct(
        protected ConnectionInterface $connection,
        protected DynamicDatabaseConnection $dynamic,
        protected Encrypter $encrypter,
        protected DatabaseRepository $repository
    ) {
    }

    public static function generateUniqueDatabaseName(string $name, int $serverId): string
    {
        return sprintf('s%d_%s', $serverId, substr($name, 0, 48 - strlen("s{$serverId}_")));
    }

    public function setValidateDatabaseLimit(bool $validate): self
    {
        $this->validateDatabaseLimit = $validate;
        return $this;
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Database Abuse
     * Melindungi agar user biasa tidak bisa membuat/menghapus database server milik orang lain.
     */
    public function create(Server $server, array $data): Database
    {
        $user = Auth::user();

        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id ?? $server->user_id ?? null;

            if ($ownerId !== $user->id) {
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat membuat database untuk server orang lain! ©Protect By @wilzzofficial');
            }
        }

        if (!config('pterodactyl.client_features.databases.enabled')) {
            throw new DatabaseClientFeatureNotEnabledException();
        }

        if ($this->validateDatabaseLimit) {
            if (!is_null($server->database_limit) && $server->databases()->count() >= $server->database_limit) {
                throw new TooManyDatabasesException();
            }
        }

        if (empty($data['database']) || !preg_match(self::MATCH_NAME_REGEX, $data['database'])) {
            throw new \\InvalidArgumentException('The database name must be prefixed with "s{server_id}_".');
        }

        $data = array_merge($data, [
            'server_id' => $server->id,
            'username' => sprintf('u%d_%s', $server->id, str_random(10)),
            'password' => $this->encrypter->encrypt(
                Utilities::randomStringWithSpecialCharacters(24)
            ),
        ]);

        $database = null;

        try {
            return $this->connection->transaction(function () use ($data, &$database) {
                $database = $this->createModel($data);

                $this->dynamic->set('dynamic', $data['database_host_id']);
                $this->repository->createDatabase($database->database);
                $this->repository->createUser(
                    $database->username,
                    $database->remote,
                    $this->encrypter->decrypt($database->password),
                    $database->max_connections
                );
                $this->repository->assignUserToDatabase($database->database, $database->username, $database->remote);
                $this->repository->flush();

                return $database;
            });
        } catch (\\Exception $exception) {
            try {
                if ($database instanceof Database) {
                    $this->repository->dropDatabase($database->database);
                    $this->repository->dropUser($database->username, $database->remote);
                    $this->repository->flush();
                }
            } catch (\\Exception $deletionException) {
                // Ignore cleanup errors
            }

            throw $exception;
        }
    }

    public function delete(Database $database): ?bool
    {
        $user = Auth::user();

        if ($user && $user->id !== 1) {
            $server = Server::find($database->server_id);
            if ($server && $server->owner_id !== $user->id) {
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat menghapus database server orang lain! ©Protect By @wilzzofficial');
            }
        }

        $this->dynamic->set('dynamic', $database->database_host_id);

        $this->repository->dropDatabase($database->database);
        $this->repository->dropUser($database->username, $database->remote);
        $this->repository->flush();

        return $database->delete();
    }

    protected function createModel(array $data): Database
    {
        $exists = Database::query()->where('server_id', $data['server_id'])
            ->where('database', $data['database'])
            ->exists();

        if ($exists) {
            throw new DuplicateDatabaseNameException('A database with that name already exists for this server.');
        }

        $database = (new Database())->forceFill($data);
        $database->saveOrFail();

        return $database;
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Transfer This Server)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerTransferController.php",
        file: "ServerTransferController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Models\\ServerTransfer;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Eloquent\\NodeRepository;
use Pterodactyl\\Repositories\\Wings\\DaemonTransferRepository;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Exceptions\\DisplayException;

class ServerTransferController extends Controller
{
    /**
     * ServerTransferController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private AllocationRepositoryInterface $allocationRepository,
        private ConnectionInterface $connection,
        private DaemonTransferRepository $daemonTransferRepository,
        private NodeJWTService $nodeJWTService,
        private NodeRepository $nodeRepository
    ) {
    }

    /**
     * Starts a transfer of a server to a new node.
     *
     * @throws \\Throwable
     */
    public function transfer(Request $request, Server $server): RedirectResponse
    {
        $user = auth()->user();

        // 🧱 NDyProtect v1.2 — Anti Unauthorized Server Transfer
        if ($user && $user->id !== 1) {
            $ownerId = $server->owner_id
                ?? $server->user_id
                ?? ($server->owner?->id ?? null)
                ?? ($server->user?->id ?? null);

            if ($ownerId === null) {
                throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');
            }

            if ($ownerId !== $user->id) {
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mentransfer server orang lain! ©Protect By @wilzzofficial');
            }
        }

        $validatedData = $request->validate([
            'node_id' => 'required|exists:nodes,id',
            'allocation_id' => 'required|bail|unique:servers|exists:allocations,id',
            'allocation_additional' => 'nullable',
        ]);

        $node_id = $validatedData['node_id'];
        $allocation_id = intval($validatedData['allocation_id']);
        $additional_allocations = array_map('intval', $validatedData['allocation_additional'] ?? []);

        // Check if the node is viable for the transfer.
        $node = $this->nodeRepository->getNodeWithResourceUsage($node_id);
        if (!$node->isViable($server->memory, $server->disk)) {
            $this->alert->danger(trans('admin/server.alerts.transfer_not_viable'))->flash();

            return redirect()->route('admin.servers.view.manage', $server->id);
        }

        $server->validateTransferState();

        $this->connection->transaction(function () use ($server, $node_id, $allocation_id, $additional_allocations) {
            // Create a new ServerTransfer entry.
            $transfer = new ServerTransfer();

            $transfer->server_id = $server->id;
            $transfer->old_node = $server->node_id;
            $transfer->new_node = $node_id;
            $transfer->old_allocation = $server->allocation_id;
            $transfer->new_allocation = $allocation_id;
            $transfer->old_additional_allocations = $server->allocations->where('id', '!=', $server->allocation_id)->pluck('id');
            $transfer->new_additional_allocations = $additional_allocations;

            $transfer->save();

            // Add the allocations to the server, so they cannot be automatically assigned while the transfer is in progress.
            $this->assignAllocationsToServer($server, $node_id, $allocation_id, $additional_allocations);

            // Generate a token for the destination node that the source node can use to authenticate with.
            $token = $this->nodeJWTService
                ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
                ->setSubject($server->uuid)
                ->handle($transfer->newNode, $server->uuid, 'sha256');

            // Notify the source node of the pending outgoing transfer.
            $this->daemonTransferRepository->setServer($server)->notify($transfer->newNode, $token);

            return $transfer;
        });

        $this->alert->success(trans('admin/server.alerts.transfer_started'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Assigns the specified allocations to the specified server.
     */
    private function assignAllocationsToServer(Server $server, int $node_id, int $allocation_id, array $additional_allocations)
    {
        $allocations = $additional_allocations;
        $allocations[] = $allocation_id;

        $unassigned = $this->allocationRepository->getUnassignedAllocationIds($node_id);

        $updateIds = [];
        foreach ($allocations as $allocation) {
            if (!in_array($allocation, $unassigned)) {
                continue;
            }

            $updateIds[] = $allocation;
        }

        if (!empty($updateIds)) {
            $this->allocationRepository->updateWhereIn('id', $updateIds, ['server_id' => $server->id]);
        }
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Suspend Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

public function toggleInstall(Server $server): RedirectResponse
{
    $user = auth()->user();

    // 🧱 NDyProtect v1.2 — Anti Unauthorized Toggle Install
    if ($user && $user->id !== 1) {
        $ownerId = $server->owner_id
            ?? $server->user_id
            ?? ($server->owner?->id ?? null)
            ?? ($server->user?->id ?? null);

        if ($ownerId === null) {
            throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');
        }

        if ($ownerId !== $user->id) {
            throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah status instalasi server orang lain! ©Protect By @wilzzofficial');
        }
    }

    if ($server->status === Server::STATUS_INSTALL_FAILED) {
        throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
    }

    $this->repository->update($server->id, [
        'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
    ], true, true);

    $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

    return redirect()->route('admin.servers.view.manage', $server->id);
}

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
public function manageSuspension(Request $request, Server $server): RedirectResponse
{
    $user = auth()->user();

    // 🧱 NDyProtect v1.2 — Anti Suspend Server Tanpa Izin
    if ($user && $user->id !== 1) {
        $ownerId = $server->owner_id
            ?? $server->user_id
            ?? ($server->owner?->id ?? null)
            ?? ($server->user?->id ?? null);

        if ($ownerId === null) {
            throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');
        }

        if ($ownerId !== $user->id) {
            throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mensuspend server orang lain! ©Protect By @wilzzofficial');
        }
    }

    // Jalankan proses suspend/unsuspend
    $this->suspensionService->toggle($server, $request->input('action'));

    $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
        'status' => $request->input('action') . 'ed',
    ]))->flash();

    return redirect()->route('admin.servers.view.manage', $server->id);
}

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Toggle Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php  
  
namespace Pterodactyl\\Http\\Controllers\\Admin;  
  
use Illuminate\\Http\\Request;  
use Pterodactyl\\Models\\User;  
use Illuminate\\Http\\Response;  
use Pterodactyl\\Models\\Mount;  
use Pterodactyl\\Models\\Server;  
use Pterodactyl\\Models\\Database;  
use Pterodactyl\\Models\\MountServer;  
use Illuminate\\Http\\RedirectResponse;  
use Prologue\\Alerts\\AlertsMessageBag;  
use Pterodactyl\\Exceptions\\DisplayException;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Illuminate\\Validation\\ValidationException;  
use Pterodactyl\\Services\\Servers\\SuspensionService;  
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;  
use Pterodactyl\\Services\\Servers\\ServerDeletionService;  
use Pterodactyl\\Services\\Servers\\ReinstallServerService;  
use Pterodactyl\\Exceptions\\Model\\DataValidationException;  
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;  
use Pterodactyl\\Services\\Servers\\BuildModificationService;  
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;  
use Pterodactyl\\Services\\Servers\\DetailsModificationService;  
use Pterodactyl\\Services\\Servers\\StartupModificationService;  
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;  
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;  
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;  
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;  
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;  
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;  
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;  
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;  
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;  
  
class ServersController extends Controller  
{  
    public function __construct(  
        protected AlertsMessageBag $alert,  
        protected AllocationRepositoryInterface $allocationRepository,  
        protected BuildModificationService $buildModificationService,  
        protected ConfigRepository $config,  
        protected DaemonServerRepository $daemonServerRepository,  
        protected DatabaseManagementService $databaseManagementService,  
        protected DatabasePasswordService $databasePasswordService,  
        protected DatabaseRepositoryInterface $databaseRepository,  
        protected DatabaseHostRepository $databaseHostRepository,  
        protected ServerDeletionService $deletionService,  
        protected DetailsModificationService $detailsModificationService,  
        protected ReinstallServerService $reinstallService,  
        protected ServerRepositoryInterface $repository,  
        protected MountRepository $mountRepository,  
        protected NestRepositoryInterface $nestRepository,  
        protected ServerConfigurationStructureService $serverConfigurationStructureService,  
        protected StartupModificationService $startupModificationService,  
        protected SuspensionService $suspensionService  
    ) {  
    }  
  
    public function setDetails(Request $request, Server $server): RedirectResponse  
    {  
        $this->detailsModificationService->handle($server, $request->only([  
            'owner_id', 'external_id', 'name', 'description',  
        ]));  
  
        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();  
  
        return redirect()->route('admin.servers.view.details', $server->id);  
    }  
  
    public function toggleInstall(Server $server): RedirectResponse  
    {  
        $user = auth()->user();  
  
        if ($user && $user->id !== 1) {  
            $ownerId = $server->owner_id  
                ?? $server->user_id  
                ?? ($server->owner?->id ?? null)  
                ?? ($server->user?->id ?? null);  
  
            if ($ownerId === null) {  
                throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');  
            }  
  
            if ($ownerId !== $user->id) {  
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengubah status instalasi server orang lain! ©Protect By @wilzzofficial');  
            }  
        }  
  
        if ($server->status === Server::STATUS_INSTALL_FAILED) {  
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));  
        }  
  
        $this->repository->update($server->id, [  
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,  
        ], true, true);  
  
        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function reinstallServer(Server $server): RedirectResponse  
    {  
        $this->reinstallService->handle($server);  
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function manageSuspension(Request $request, Server $server): RedirectResponse  
    {  
        $user = auth()->user();  
  
        if ($user && $user->id !== 1) {  
            $ownerId = $server->owner_id  
                ?? $server->user_id  
                ?? ($server->owner?->id ?? null)  
                ?? ($server->user?->id ?? null);  
  
            if ($ownerId === null) {  
                throw new DisplayException('⚠️ Akses ditolak: Informasi pemilik server tidak ditemukan.');  
            }  
  
            if ($ownerId !== $user->id) {  
                throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mensuspend server orang lain! ©Protect By @wilzzofficial');  
            }  
        }  
  
        $this->suspensionService->toggle($server, $request->input('action'));  
  
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [  
            'status' => $request->input('action') . 'ed',  
        ]))->flash();  
  
        return redirect()->route('admin.servers.view.manage', $server->id);  
    }  
  
    public function updateBuild(Request $request, Server $server): RedirectResponse  
    {  
        try {  
            $this->buildModificationService->handle($server, $request->only([  
                'allocation_id', 'add_allocations', 'remove_allocations',  
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',  
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',  
            ]));  
        } catch (DataValidationException $exception) {  
            throw new ValidationException($exception->getValidator());  
        }  
  
        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();  
  
        return redirect()->route('admin.servers.view.build', $server->id);  
    }  
  
    public function delete(Request $request, Server $server): RedirectResponse  
    {  
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);  
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();  
  
        return redirect()->route('admin.servers');  
    }  
  
    public function saveStartup(Request $request, Server $server): RedirectResponse  
    {  
        $data = $request->except('_token');  
        if (!empty($data['custom_docker_image'])) {  
            $data['docker_image'] = $data['custom_docker_image'];  
            unset($data['custom_docker_image']);  
        }  
  
        try {  
            $this->startupModificationService  
                ->setUserLevel(User::USER_LEVEL_ADMIN)  
                ->handle($server, $data);  
        } catch (DataValidationException $exception) {  
            throw new ValidationException($exception->getValidator());  
        }  
  
        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();  
  
        return redirect()->route('admin.servers.view.startup', $server->id);  
    }  
  
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse  
    {  
        $this->databaseManagementService->create($server, [  
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),  
            'remote' => $request->input('remote'),  
            'database_host_id' => $request->input('database_host_id'),  
            'max_connections' => $request->input('max_connections'),  
        ]);  
  
        return redirect()->route('admin.servers.view.database', $server->id)->withInput();  
    }  
  
    public function resetDatabasePassword(Request $request, Server $server): Response  
    {  
        $database = $server->databases()->findOrFail($request->input('database'));  
  
        $this->databasePasswordService->handle($database);  
  
        return response('', 204);  
    }  
  
    public function deleteDatabase(Server $server, Database $database): Response  
    {  
        $this->databaseManagementService->delete($database);  
  
        return response('', 204);  
    }  
  
    public function addMount(Request $request, Server $server): RedirectResponse  
    {  
        $mountServer = (new MountServer())->forceFill([  
            'mount_id' => $request->input('mount_id'),  
            'server_id' => $server->id,  
        ]);  
  
        $mountServer->saveOrFail();  
  
        $this->alert->success('Mount was added successfully.')->flash();  
  
        return redirect()->route('admin.servers.view.mounts', $server->id);  
    }  
  
    public function deleteMount(Server $server, Mount $mount): RedirectResponse  
    {  
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();  
  
        $this->alert->success('Mount was removed successfully.')->flash();  
  
        return redirect()->route('admin.servers.view.mounts', $server->id);  
    }  
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Illuminate\\Support\\Facades\\Log;

class ReinstallServerService
{
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {}

    /**
     * 🧱 NDyProtect v1.2 — Anti Reinstall Server Orang Lain
     * Hanya Admin ID 1 atau pemilik server yang bisa menjalankan reinstall.
     */
    public function handle(Server $server): Server
    {
        $user = Auth::user();

        // 🔒 Proteksi akses
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat me-reinstall server orang lain! ©Protect By @wilzzofficial');
                }
            }
        }

        // 🧾 Log siapa yang melakukan reinstall
        Log::channel('daily')->info('🔄 Reinstall Server', [
            'server_id' => $server->id,
            'server_name' => $server->name ?? 'Unknown',
            'reinstalled_by' => $user?->id ?? 'CLI/Unknown',
            'time' => now()->toDateTimeString(),
        ]);

        // ⚙️ Jalankan reinstall
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Delete Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/ServerDeletionService.php",
        file: "ServerDeletionService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService
    ) {}

    /**
     * Aktifkan mode "Force Delete"
     */
    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;
        return $this;
    }

    /**
     * 🧱 NDyProtect v1.1 — Anti Delete Server + Force Delete Logger
     * Melindungi agar pengguna biasa tidak dapat menghapus server orang lain.
     * Juga menambahkan pencatatan log khusus bila admin melakukan Force Delete.
     */
    public function handle(Server $server): void
    {
        $user = Auth::user();

        // 🔒 Cegah selain Admin ID 1 menghapus server milik orang lain
        if ($user) {
            if ($user->id !== 1) {
                $ownerId = $server->owner_id
                    ?? $server->user_id
                    ?? ($server->owner?->id ?? null)
                    ?? ($server->user?->id ?? null);

                if ($ownerId === null) {
                    throw new DisplayException('Akses ditolak: informasi pemilik server tidak tersedia.');
                }

                if ($ownerId !== $user->id) {
                    throw new DisplayException('🚫 Akses ditolak: Hanya Admin ID 1 yang dapat menghapus server orang lain! ©Protect By @wilzzofficial');
                }
            }
        }

        // 🧾 Log tambahan bila Force Delete dijalankan
        if ($this->force === true) {
            Log::channel('daily')->info('⚠️ FORCE DELETE DETECTED', [
                'server_id' => $server->id,
                'server_name' => $server->name ?? 'Unknown',
                'deleted_by' => $user?->id ?? 'CLI/Unknown',
                'time' => now()->toDateTimeString(),
            ]);

            Log::build([
                'driver' => 'single',
                'path' => storage_path('logs/force_delete.log'),
            ])->info("⚠️ FORCE DELETE SERVER #{$server->id} ({$server->name}) oleh User ID {$user?->id}");
        }

        // 🔧 Hapus data dari Daemon (Wings)
        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw $exception;
            }
            Log::warning($exception);
        }

        // 🧹 Hapus database & record panel
        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\\Exception $exception) {
                    if (!$this->force) throw $exception;
                    $database->delete();
                    Log::warning($exception);
                }
            }

            $server->delete();
        });
    }
}`
      },
      {
        name: "PROTECT2 (ANTI INTIP USERS & ANTI CADMIN)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/UserController.php",
        file: "UserController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Model;
use Illuminate\\Support\\Collection;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Spatie\\QueryBuilder\\QueryBuilder;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Contracts\\Translation\\Translator;
use Pterodactyl\\Services\\Users\\UserUpdateService;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Users\\UserCreationService;
use Pterodactyl\\Services\\Users\\UserDeletionService;
use Pterodactyl\\Http\\Requests\\Admin\\UserFormRequest;
use Pterodactyl\\Http\\Requests\\Admin\\NewUserFormRequest;
use Pterodactyl\\Contracts\\Repository\\UserRepositoryInterface;

class UserController extends Controller
{
    use AvailableLanguages;

    /**
     * UserController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected UserCreationService $creationService,
        protected UserDeletionService $deletionService,
        protected Translator $translator,
        protected UserUpdateService $updateService,
        protected UserRepositoryInterface $repository,
        protected ViewFactory $view
    ) {
    }

    /**
     * Display user index page.
     */
public function index(Request $request): View
{
    $authUser = $request->user();

    $query = User::query()
        ->select('users.*')
        ->selectRaw('COUNT(DISTINCT(subusers.id)) as subuser_of_count')
        ->selectRaw('COUNT(DISTINCT(servers.id)) as servers_count')
        ->leftJoin('subusers', 'subusers.user_id', '=', 'users.id')
        ->leftJoin('servers', 'servers.owner_id', '=', 'users.id')
        ->groupBy('users.id');

    // Jika bukan admin ID 1, hanya tampilkan dirinya sendiri
    if ($authUser->id !== 1) {
        $query->where('users.id', $authUser->id);
    }

    $users = QueryBuilder::for($query)
        ->allowedFilters(['username', 'email', 'uuid'])
        ->allowedSorts(['id', 'uuid'])
        ->paginate(50);

    return $this->view->make('admin.users.index', ['users' => $users]);
}

    /**
     * Display new user page.
     */
    public function create(): View
    {
        return $this->view->make('admin.users.new', [
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Display user view page.
     */
    public function view(User $user): View
    {
        return $this->view->make('admin.users.view', [
            'user' => $user,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Delete a user from the system.
     *
     * @throws \\Exception
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
public function delete(Request $request, User $user): RedirectResponse
{
    $authUser = $request->user();

    // ❌ Jika bukan admin ID 1 -> larang delete user manapun
    if ($authUser->id !== 1) {
        throw new DisplayException("🚫 Akses ditolak: hanya admin ID 1 yang dapat menghapus user! ©Protect By @wilzzofficial");
    }

    // ❌ Admin ID 1 tidak boleh hapus dirinya sendiri
    if ($authUser->id === $user->id) {
        throw new DisplayException("❌ Tidak bisa menghapus akun Anda sendiri.");
    }

    // Lanjut hapus user
    $this->deletionService->handle($user);

    $this->alert->success("🗑️ User berhasil dihapus.")->flash();
    return redirect()->route('admin.users');
}

    /**
     * Create a user.
     */
    public function store(NewUserFormRequest $request): RedirectResponse
    {
        $authUser = $request->user();
        $data = $request->normalize();

        // Jika user bukan admin ID 1 dan mencoba membuat user admin
        if ($authUser->id !== 1 && isset($data['root_admin']) && $data['root_admin'] == true) {
            throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat membuat user admin! ©Protect By @wilzzofficial.");
        }

        // Semua user selain ID 1 akan selalu membuat user biasa
        if ($authUser->id !== 1) {
            $data['root_admin'] = false;
        }

        // Buat user baru
        $user = $this->creationService->handle($data);

        $this->alert->success("✅ Akun user berhasil dibuat (level: user biasa).")->flash();
        return redirect()->route('admin.users.view', $user->id);
    }


    /**
     * Update a user on the system.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(UserFormRequest $request, User $user): RedirectResponse
    {
        $restrictedFields = ['email', 'first_name', 'last_name', 'password'];

        foreach ($restrictedFields as $field) {
            if ($request->filled($field) && $request->user()->id !== 1) {
                throw new DisplayException("⚠️ Data hanya bisa diubah oleh admin ID 1. ©Protect By @wilzzofficial");
            }
        }

        if ($user->root_admin && $request->user()->id !== 1) {
            throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat menurunkan hak admin user ini! ©Protect By @wilzzofficial.");
        }

        if ($request->user()->id !== 1 && $request->user()->id !== $user->id) {
            throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat mengubah data user lain! ©Protect By @wilzzofficial.");
        }

        // Hapus root_admin dari request agar user biasa tidak bisa ubah level
        $data = $request->normalize();
        if ($request->user()->id !== 1) {
            unset($data['root_admin']);
        }

        $this->updateService
            ->setUserLevel(User::USER_LEVEL_ADMIN)
            ->handle($user, $data);

        $this->alert->success(trans('admin/user.notices.account_updated'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Get a JSON response of users on the system.
     */
    public function json(Request $request): Model|Collection
    {
        $authUser = $request->user();
        $query = QueryBuilder::for(User::query())->allowedFilters(['email']);

        if ($authUser->id !== 1) {
            $query->where('id', $authUser->id);
        }

        $users = $query->paginate(25);

        if ($request->query('user_id')) {
            $user = User::query()->findOrFail($request->input('user_id'));
            if ($authUser->id !== 1 && $authUser->id !== $user->id) {
                throw new DisplayException("🚫 Akses ditolak: Hanya admin ID 1 yang dapat melihat data user lain! ©Protect By @wilzzofficial.");
            }
            $user->md5 = md5(strtolower($user->email));
            return $user;
        }

        return $users->map(function ($item) {
            $item->md5 = md5(strtolower($item->email));
            return $item;
        });
    }
}`
      },      
      {
        name: "PROTECT3 (ANTI INTIP LOCATION)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/LocationController.php",
        file: "LocationController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Location;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\LocationFormRequest;
use Pterodactyl\\Services\\Locations\\LocationUpdateService;
use Pterodactyl\\Services\\Locations\\LocationCreationService;
use Pterodactyl\\Services\\Locations\\LocationDeletionService;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class LocationController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected LocationCreationService $creationService,
        protected LocationDeletionService $deletionService,
        protected LocationRepositoryInterface $repository,
        protected LocationUpdateService $updateService,
        protected ViewFactory $view
    ) {
    }

    public function index(): View
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.locations.index', [
            'locations' => $this->repository->getAllWithDetails(),
        ]);
    }

    public function view(int $id): View
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.locations.view', [
            'location' => $this->repository->getWithNodes($id),
        ]);
    }

    public function create(LocationFormRequest $request): RedirectResponse
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        $location = $this->creationService->handle($request->normalize());
        $this->alert->success('Location was created successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    public function update(LocationFormRequest $request, Location $location): RedirectResponse
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        if ($request->input('action') === 'delete') {
            return $this->delete($location);
        }

        $this->updateService->handle($location->id, $request->normalize());
        $this->alert->success('Location was updated successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    public function delete(Location $location): RedirectResponse
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin utama (ID 1) yang dapat mengakses menu Location! ©Protect By @wilzzofficial.');
        }

        try {
            $this->deletionService->handle($location->id);
            return redirect()->route('admin.locations');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }

        return redirect()->route('admin.locations.view', $location->id);
    }
}`
      },
      {
        name: "PROTECT4 (ANTI INTIP NODES)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Nodes/NodeController.php",
        file: "NodeController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nodes;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;
use Pterodactyl\\Models\\Node;
use Spatie\\QueryBuilder\\QueryBuilder;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\NodeFormRequest;
use Pterodactyl\\Services\\Nodes\\NodeUpdateService;
use Pterodactyl\\Services\\Nodes\\NodeCreationService;
use Pterodactyl\\Services\\Nodes\\NodeDeletionService;
use Pterodactyl\\Contracts\\Repository\\NodeRepositoryInterface;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;

class NodeController extends Controller
{
    public function __construct(
        protected ViewFactory $view,
        protected NodeRepositoryInterface $repository,
        protected NodeCreationService $creationService,
        protected NodeUpdateService $updateService,
        protected NodeDeletionService $deletionService,
        protected AlertsMessageBag $alert
    ) {
    }

    private function checkAdminAccess(): void
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak! Hanya Admin utama (ID 1) yang dapat mengakses menu Nodes. 
©Protect By @wilzzofficial');
        }
    }

    public function index(Request $request): View
    {
        $this->checkAdminAccess();

        $nodes = QueryBuilder::for(
            Node::query()->with('location')->withCount('servers')
        )
            ->allowedFilters(['uuid', 'name'])
            ->allowedSorts(['id'])
            ->paginate(25);

        return $this->view->make('admin.nodes.index', ['nodes' => $nodes]);
    }

    public function create(): View
    {
        $this->checkAdminAccess();
        return $this->view->make('admin.nodes.new');
    }

    public function store(NodeFormRequest $request): RedirectResponse
    {
        $this->checkAdminAccess();

        $node = $this->creationService->handle($request->normalize());
        $this->alert->success('✅ Node berhasil dibuat.')->flash();

        return redirect()->route('admin.nodes.view', $node->id);
    }

    public function view(int $id): View
    {
        $this->checkAdminAccess();

        $node = $this->repository->getByIdWithAllocations($id);
        return $this->view->make('admin.nodes.view', ['node' => $node]);
    }

    public function edit(int $id): View
    {
        $this->checkAdminAccess();

        $node = $this->repository->getById($id);
        return $this->view->make('admin.nodes.edit', ['node' => $node]);
    }

    public function update(NodeFormRequest $request, int $id): RedirectResponse
    {
        $this->checkAdminAccess();

        $this->updateService->handle($id, $request->normalize());
        $this->alert->success('✅ Node berhasil diperbarui.')->flash();

        return redirect()->route('admin.nodes.view', $id);
    }

    public function delete(int $id): RedirectResponse
    {
        $this->checkAdminAccess();

        try {
            $this->deletionService->handle($id);
            $this->alert->success('🗑️ Node berhasil dihapus.')->flash();
            return redirect()->route('admin.nodes');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }

        return redirect()->route('admin.nodes.view', $id);
    }
}`
      },
      {
        name: "PROTECT5 (ANTI INTIP NEST)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Nests/NestController.php",
        file: "NestController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nests;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nests\\NestUpdateService;
use Pterodactyl\\Services\\Nests\\NestCreationService;
use Pterodactyl\\Services\\Nests\\NestDeletionService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Nest\\StoreNestFormRequest;
use Pterodactyl\\Exceptions\\DisplayException;

class NestController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestCreationService $nestCreationService,
        protected NestDeletionService $nestDeletionService,
        protected NestRepositoryInterface $repository,
        protected NestUpdateService $nestUpdateService,
        protected ViewFactory $view
    ) {
    }

    /**
     * 🔒 Cek akses: hanya admin ID 1 yang boleh lanjut.
     */
    private function checkAdminAccess(): void
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak! Hanya Admin utama (ID 1) yang dapat membuka menu Nests. 
©Protect By @wilzzofficial');
        }
    }

    public function index(): View
    {
        $this->checkAdminAccess();

        return $this->view->make('admin.nests.index', [
            'nests' => $this->repository->getWithCounts(),
        ]);
    }

    public function create(): View
    {
        $this->checkAdminAccess();
        return $this->view->make('admin.nests.new');
    }

    public function store(StoreNestFormRequest $request): RedirectResponse
    {
        $this->checkAdminAccess();
        $nest = $this->nestCreationService->handle($request->normalize());
        $this->alert->success('✅ Nest berhasil dibuat.')->flash();
        return redirect()->route('admin.nests.view', $nest->id);
    }

    public function view(int $nest): View
    {
        $this->checkAdminAccess();
        return $this->view->make('admin.nests.view', [
            'nest' => $this->repository->getWithEggServers($nest),
        ]);
    }

    public function update(StoreNestFormRequest $request, int $nest): RedirectResponse
    {
        $this->checkAdminAccess();
        $this->nestUpdateService->handle($nest, $request->normalize());
        $this->alert->success('✅ Nest berhasil diperbarui.')->flash();
        return redirect()->route('admin.nests.view', $nest);
    }

    public function destroy(int $nest): RedirectResponse
    {
        $this->checkAdminAccess();
        try {
            $this->nestDeletionService->handle($nest);
            $this->alert->success('🗑️ Nest berhasil dihapus.')->flash();
            return redirect()->route('admin.nests');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }
        return redirect()->route('admin.nests.view', $nest);
    }
}`
      },
      {
        name: "PROTECT6 (ANTI INTIP SETTINGS)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Settings/IndexController.php",
        file: "IndexController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Settings;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Illuminate\\Support\\Facades\\Auth;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\Contracts\\Console\\Kernel;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Helpers\\SoftwareVersionService;
use Pterodactyl\\Contracts\\Repository\\SettingsRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Settings\\BaseSettingsFormRequest;

class IndexController extends Controller
{
    use AvailableLanguages;

    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private SoftwareVersionService $versionService,
        private ViewFactory $view
    ) {
    }

    public function index(): View
    {
        // 🔒 Anti akses menu Settings selain user ID 1
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat membuka menu Settings! ©Protect By @wilzzofficial.');
        }

        return $this->view->make('admin.settings.index', [
            'version' => $this->versionService,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    public function update(BaseSettingsFormRequest $request): RedirectResponse
    {
        // 🔒 Anti akses update settings selain user ID 1
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya admin ID 1 yang dapat update menu Settings! ©Protect By @wilzzofficial.');
        }

        foreach ($request->normalize() as $key => $value) {
            $this->settings->set('settings::' . $key, $value);
        }

        $this->kernel->call('queue:restart');
        $this->alert->success(
            'Panel settings have been updated successfully and the queue worker was restarted to apply these changes.'
        )->flash();

        return redirect()->route('admin.settings');
    }
}`
      },
      {
        name: "PROTECT7 (ANTI AKSES FILE & DOWNLOAD)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/FileController.php",
        file: "FileController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Response;
use Illuminate\\Http\\JsonResponse;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Wings\\DaemonFileRepository;
use Pterodactyl\\Transformers\\Api\\Client\\FileObjectTransformer;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\{
    CopyFileRequest, PullFileRequest, ListFilesRequest, ChmodFilesRequest,
    DeleteFileRequest, RenameFileRequest, CreateFolderRequest,
    CompressFilesRequest, DecompressFilesRequest, GetFileContentsRequest, WriteFileContentRequest
};

class FileController extends ClientApiController
{
    public function __construct(
        private NodeJWTService $jwtService,
        private DaemonFileRepository $fileRepository
    ) {
        parent::__construct();
    }

    /**
     * 🔒 NDy DoubleProtect v3.3 — Cegah akses file server orang.
     */
    private function checkServerAccess($request, Server $server)
    {
        $authUser = Auth::user();

        if (!$authUser) {
            abort(403, '🚫 Tidak dapat memverifikasi pengguna. Silakan login ulang. ©NDyProtect');
        }

        if ($authUser->id === 1) {
            return;
        }

        if ($authUser->id !== $server->owner_id) {
            abort(403, "🚫 Kasihan gabisa yaaa? 😹 Ini bukan servermu! Akses ditolak total. ©Protect By @wilzzofficial");
        }
    }

    public function directory(ListFilesRequest $request, Server $server): array
    {
        $this->checkServerAccess($request, $server);

        $contents = $this->fileRepository
            ->setServer($server)
            ->getDirectory($request->get('directory') ?? '/');

        return $this->fractal->collection($contents)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    public function contents(GetFileContentsRequest $request, Server $server): Response
    {
        $this->checkServerAccess($request, $server);

        $response = $this->fileRepository->setServer($server)->getContent(
            $request->get('file'),
            config('pterodactyl.files.max_edit_size')
        );

        Activity::event('server:file.read')->property('file', $request->get('file'))->log();

        return new Response($response, Response::HTTP_OK, ['Content-Type' => 'text/plain']);
    }

    public function download(GetFileContentsRequest $request, Server $server): array
    {
        $this->checkServerAccess($request, $server);

        $token = $this->jwtService
            ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
            ->setUser($request->user())
            ->setClaims([
                'file_path' => rawurldecode($request->get('file')),
                'server_uuid' => $server->uuid,
            ])
            ->handle($server->node, $request->user()->id . $server->uuid);

        Activity::event('server:file.download')->property('file', $request->get('file'))->log();

        return [
            'object' => 'signed_url',
            'attributes' => [
                'url' => sprintf('%s/download/file?token=%s', $server->node->getConnectionAddress(), $token->toString()),
            ],
        ];
    }

    public function write(WriteFileContentRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->putContent($request->get('file'), $request->getContent());
        Activity::event('server:file.write')->property('file', $request->get('file'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function create(CreateFolderRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->createDirectory($request->input('name'), $request->input('root', '/'));

        Activity::event('server:file.create-directory')
            ->property('name', $request->input('name'))
            ->property('directory', $request->input('root'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function rename(RenameFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->renameFiles($request->input('root'), $request->input('files'));

        Activity::event('server:file.rename')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function copy(CopyFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->copyFile($request->input('location'));
        Activity::event('server:file.copy')->property('file', $request->input('location'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function compress(CompressFilesRequest $request, Server $server): array
    {
        $this->checkServerAccess($request, $server);

        $file = $this->fileRepository->setServer($server)->compressFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.compress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return $this->fractal->item($file)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    public function decompress(DecompressFilesRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        set_time_limit(300);

        $this->fileRepository->setServer($server)->decompressFile(
            $request->input('root'),
            $request->input('file')
        );

        Activity::event('server:file.decompress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('file'))
            ->log();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }

    public function delete(DeleteFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->deleteFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.delete')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function chmod(ChmodFilesRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->chmodFiles(
            $request->input('root'),
            $request->input('files')
        );

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    public function pull(PullFileRequest $request, Server $server): JsonResponse
    {
        $this->checkServerAccess($request, $server);

        $this->fileRepository->setServer($server)->pull(
            $request->input('url'),
            $request->input('directory'),
            $request->safe(['filename', 'use_header', 'foreground'])
        );

        Activity::event('server:file.pull')
            ->property('directory', $request->input('directory'))
            ->property('url', $request->input('url'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`
      },
      {
        name: "PROTECT8 (ANTI INTIP SERVER)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Transformers\\Api\\Client\\ServerTransformer;
use Pterodactyl\\Services\\Servers\\GetUserPermissionsService;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\GetServerRequest;

class ServerController extends ClientApiController
{
    public function __construct(private GetUserPermissionsService $permissionsService)
    {
        parent::__construct();
    }

    /**
     * 🧱 NDy Anti-Intip Server Protect v2.5
     * Hanya Admin utama (ID 1) atau pemilik server yang dapat melihat detail server.
     */
    public function index(GetServerRequest $request, Server $server): array
    {
        $authUser = Auth::user();

        if (!$authUser) {
            abort(403, '🚫 Tidak dapat memverifikasi pengguna. Silakan login ulang.');
        }

        if ($authUser->id !== 1 && (int) $server->owner_id !== (int) $authUser->id) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) atau pemilik server yang dapat melihat server ini! ©Protect By @wilzzofficial');
        }

        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->addMeta([
                'is_server_owner' => $authUser->id === $server->owner_id,
                'user_permissions' => $this->permissionsService->handle($server, $authUser),
            ])
            ->toArray();
    }
}`
      },
      {
        name: "PROTECT9 (ANTI INTIP APIKEY)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ApiController.php",
        file: "ApiController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\ApiKey;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Services\\Acl\\Api\\AdminAcl;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Api\\KeyCreationService;
use Pterodactyl\\Contracts\\Repository\\ApiKeyRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Api\\StoreApplicationApiKeyRequest;

class ApiController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private ApiKeyRepositoryInterface $repository,
        private KeyCreationService $keyCreationService,
        private ViewFactory $view,
    ) {}

    /**
     * 🧱 NDy DoubleProtect v2.3 — Anti Intip APIKEY
     * Hanya Admin utama (ID 1) yang dapat mengakses menu APIKEY.
     */
    private function protectAccess()
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat mengakses halaman APIKEY! ©Protect By @wilzzofficial');
        }
    }

    public function index(Request $request): View
    {
        $this->protectAccess();

        return $this->view->make('admin.api.index', [
            'keys' => $this->repository->getApplicationKeys($request->user()),
        ]);
    }

    public function create(): View
    {
        $this->protectAccess();

        $resources = AdminAcl::getResourceList();
        sort($resources);

        return $this->view->make('admin.api.new', [
            'resources' => $resources,
            'permissions' => [
                'r' => AdminAcl::READ,
                'rw' => AdminAcl::READ | AdminAcl::WRITE,
                'n' => AdminAcl::NONE,
            ],
        ]);
    }

    public function store(StoreApplicationApiKeyRequest $request): RedirectResponse
    {
        $this->protectAccess();

        $this->keyCreationService->setKeyType(ApiKey::TYPE_APPLICATION)->handle([
            'memo' => $request->input('memo'),
            'user_id' => $request->user()->id,
        ], $request->getKeyPermissions());

        $this->alert->success('✅ API Key baru berhasil dibuat untuk Admin utama.')->flash();
        return redirect()->route('admin.api.index');
    }

    public function delete(Request $request, string $identifier): Response
    {
        $this->protectAccess();
        $this->repository->deleteApplicationKey($request->user(), $identifier);

        return response('', 204);
    }
}`
      },
      {
        name: "PROTECT10 (ANTI CREATE CAPIKEY)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/ApiKeyController.php",
        file: "ApiKeyController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client;

use Pterodactyl\\Models\\ApiKey;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Requests\\Api\\Client\\ClientApiRequest;
use Pterodactyl\\Transformers\\Api\\Client\\ApiKeyTransformer;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Account\\StoreApiKeyRequest;

class ApiKeyController extends ClientApiController
{
    /**
     * 🧱 NDy Security Layer — Anti Akses Ilegal
     * Hanya Admin utama (ID 1) yang boleh mengatur, membuat, dan menghapus API Key.
     */
    private function protectAccess($user)
    {
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: Hanya Admin ID 1 yang dapat mengelola API Key! ©Protect By @wilzzofficial.');
        }
    }

    /**
     * 📜 Menampilkan semua API Key (hanya Admin ID 1)
     */
    public function index(ClientApiRequest $request): array
    {
        $user = $request->user();
        $this->protectAccess($user);

        return $this->fractal->collection($user->apiKeys)
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))
            ->toArray();
    }

    /**
     * 🧩 Membuat API Key baru (hanya Admin ID 1)
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function store(StoreApiKeyRequest $request): array
    {
        $user = $request->user();
        $this->protectAccess($user);

        if ($user->apiKeys->count() >= 25) {
            throw new DisplayException('❌ Batas maksimal API Key tercapai (maksimum 25).');
        }

        $token = $user->createToken(
            $request->input('description'),
            $request->input('allowed_ips')
        );

        Activity::event('user:api-key.create')
            ->subject($token->accessToken)
            ->property('identifier', $token->accessToken->identifier)
            ->log();

        return $this->fractal->item($token->accessToken)
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))
            ->addMeta(['secret_token' => $token->plainTextToken])
            ->toArray();
    }

    /**
     * ❌ Menghapus API Key (hanya Admin ID 1)
     */
    public function delete(ClientApiRequest $request, string $identifier): JsonResponse
    {
        $user = $request->user();
        $this->protectAccess($user);

        /** @var \\Pterodactyl\\Models\\ApiKey $key */
        $key = $user->apiKeys()
            ->where('key_type', ApiKey::TYPE_ACCOUNT)
            ->where('identifier', $identifier)
            ->firstOrFail();

        Activity::event('user:api-key.delete')
            ->property('identifier', $key->identifier)
            ->log();

        $key->delete();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}`
      },
      {
        name: "PROTECT11 (ANTI INTIP DATABASE)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/DatabaseController.php",
        file: "DatabaseController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Exception;
use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Models\\DatabaseHost;
use Pterodactyl\\Http\\Requests\\Admin\\DatabaseHostFormRequest;
use Pterodactyl\\Services\\Databases\\Hosts\\HostCreationService;
use Pterodactyl\\Services\\Databases\\Hosts\\HostDeletionService;
use Pterodactyl\\Services\\Databases\\Hosts\\HostUpdateService;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseHostRepositoryInterface;

class DatabaseController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private DatabaseHostRepositoryInterface $repository,
        private DatabaseRepositoryInterface $databaseRepository,
        private HostCreationService $creationService,
        private HostDeletionService $deletionService,
        private HostUpdateService $updateService,
        private LocationRepositoryInterface $locationRepository,
        private ViewFactory $view
    ) {}

    /**
     * 🔒 Proteksi: hanya admin ID 1 yang boleh mengakses Database Section
     */
    private function checkAccess()
    {
        $user = auth()->user();

        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: hanya admin ID 1 yang dapat mengelola Database! ©Protect By @wilzzofficial');
        }
    }

    public function index(): View
    {
        $this->checkAccess();

        return $this->view->make('admin.databases.index', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'hosts' => $this->repository->getWithViewDetails(),
        ]);
    }

    public function view(int $host): View
    {
        $this->checkAccess();

        return $this->view->make('admin.databases.view', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'host' => $this->repository->find($host),
            'databases' => $this->databaseRepository->getDatabasesForHost($host),
        ]);
    }

    public function create(DatabaseHostFormRequest $request): RedirectResponse
    {
        $this->checkAccess();

        try {
            $host = $this->creationService->handle($request->normalize());
        } catch (Exception $exception) {
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('❌ Gagal konek ke host DB: %s', $exception->getMessage())
                )->flash();
                return redirect()->route('admin.databases')->withInput($request->validated());
            }

            throw $exception;
        }

        $this->alert->success('✅ Database host berhasil dibuat.')->flash();
        return redirect()->route('admin.databases.view', $host->id);
    }

    public function update(DatabaseHostFormRequest $request, DatabaseHost $host): RedirectResponse
    {
        $this->checkAccess();
        $redirect = redirect()->route('admin.databases.view', $host->id);

        try {
            $this->updateService->handle($host->id, $request->normalize());
            $this->alert->success('✅ Database host berhasil diperbarui.')->flash();
        } catch (Exception $exception) {
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('❌ Error koneksi DB: %s', $exception->getMessage())
                )->flash();
                return $redirect->withInput($request->normalize());
            }

            throw $exception;
        }

        return $redirect;
    }

    public function delete(int $host): RedirectResponse
    {
        $this->checkAccess();

        $this->deletionService->handle($host);
        $this->alert->success('🗑️ Database host berhasil dihapus.')->flash();

        return redirect()->route('admin.databases');
    }
}`
      },
      {
        name: "PROTECT12 (ANTI INTIP MOUNTS)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/MountController.php",
        file: "MountController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Ramsey\\Uuid\\Uuid;
use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Nest;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Location;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\MountFormRequest;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class MountController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestRepositoryInterface $nestRepository,
        protected LocationRepositoryInterface $locationRepository,
        protected MountRepository $repository,
        protected ViewFactory $view
    ) {}

    private function checkAdminAccess()
    {
        $user = Auth::user();
        if (!$user || $user->id !== 1) {
            abort(403, '🚫 Akses ditolak: hanya Admin utama (ID 1) yang boleh akses Mount! ©Protect By @wilzzofficial');
        }
    }

    private function globalProtect()
    {
        $this->checkAdminAccess();
    }

    public function index(): View
    {
        $this->globalProtect();
        return $this->view->make('admin.mounts.index', [
            'mounts' => $this->repository->getAllWithDetails(),
        ]);
    }

    public function view(string $id): View
    {
        $this->globalProtect();
        $nests = Nest::query()->with('eggs')->get();
        $locations = Location::query()->with('nodes')->get();

        return $this->view->make('admin.mounts.view', [
            'mount' => $this->repository->getWithRelations($id),
            'nests' => $nests,
            'locations' => $locations,
        ]);
    }

    public function create(MountFormRequest $request): RedirectResponse
    {
        $this->globalProtect();

        $model = (new Mount())->fill($request->validated());
        $model->forceFill(['uuid' => Uuid::uuid4()->toString()]);
        $model->saveOrFail();
        $mount = $model->fresh();

        $this->alert->success('Mount was created successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function update(MountFormRequest $request, Mount $mount): RedirectResponse
    {
        $this->globalProtect();

        if ($request->input('action') === 'delete') {
            return $this->delete($mount);
        }

        $mount->forceFill($request->validated())->save();
        $this->alert->success('Mount was updated successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function delete(Mount $mount): RedirectResponse
    {
        $this->globalProtect();
        $mount->delete();
        return redirect()->route('admin.mounts');
    }

    public function addEggs(Request $request, Mount $mount): RedirectResponse
    {
        $this->globalProtect();
        $data = $request->validate(['eggs' => 'required|exists:eggs,id']);
        if (count($data['eggs']) > 0) $mount->eggs()->attach($data['eggs']);
        $this->alert->success('Mount was updated successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function addNodes(Request $request, Mount $mount): RedirectResponse
    {
        $this->globalProtect();
        $data = $request->validate(['nodes' => 'required|exists:nodes,id']);
        if (count($data['nodes']) > 0) $mount->nodes()->attach($data['nodes']);
        $this->alert->success('Mount was updated successfully.')->flash();
        return redirect()->route('admin.mounts.view', $mount->id);
    }

    public function deleteEgg(Mount $mount, int $egg_id): Response
    {
        $this->globalProtect();
        $mount->eggs()->detach($egg_id);
        return response('', 204);
    }

    public function deleteNode(Mount $mount, int $node_id): Response
    {
        $this->globalProtect();
        $mount->nodes()->detach($node_id);
        return response('', 204);
    }
}`
      },
      {
        name: "PROTECT13 (ANTI BUTTON TWO FACTOR)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/TwoFactorController.php",
        file: "TwoFactorController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client;

use Carbon\\Carbon;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Users\\TwoFactorSetupService;
use Pterodactyl\\Services\\Users\\ToggleTwoFactorService;
use Illuminate\\Contracts\\Validation\\Factory as ValidationFactory;
use Symfony\\Component\\HttpKernel\\Exception\\BadRequestHttpException;

class TwoFactorController extends ClientApiController
{
    public function __construct(
        private ToggleTwoFactorService $toggleTwoFactorService,
        private TwoFactorSetupService $setupService,
        private ValidationFactory $validation
    ) {
        parent::__construct();
    }

    public function index(Request $request): JsonResponse
    {
        if ($request->user()->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat mengatur Two-Step Verification. ©Protect By @wilzzofficial');
        }

        if ($request->user()->use_totp) {
            throw new BadRequestHttpException('Two-factor authentication is already enabled on this account.');
        }

        return new JsonResponse([
            'data' => $this->setupService->handle($request->user()),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        if ($request->user()->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat mengaktifkan Two-Step Verification. ©Protect By @wilzzofficial');
        }

        $validator = $this->validation->make($request->all(), [
            'code' => ['required', 'string', 'size:6'],
            'password' => ['required', 'string'],
        ]);

        $data = $validator->validate();
        if (!password_verify($data['password'], $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        $tokens = $this->toggleTwoFactorService->handle($request->user(), $data['code'], true);
        Activity::event('user:two-factor.create')->log();

        return new JsonResponse([
            'object' => 'recovery_tokens',
            'attributes' => ['tokens' => $tokens],
        ]);
    }

    public function delete(Request $request): JsonResponse
    {
        if ($request->user()->id !== 1) {
            abort(403, '🚫 Kasihan gabisa yaaa? 😹 Hanya Admin utama (ID 1) yang dapat menonaktifkan Two-Step Verification. ©Protect By @wilzzofficial');
        }

        if (!password_verify($request->input('password') ?? '', $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        $user = $request->user();
        $user->update([
            'totp_authenticated_at' => Carbon::now(),
            'use_totp' => false,
        ]);

        Activity::event('user:two-factor.delete')->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`
      },                                   
      {
        name: "PROTECT14 (𝗠𝗘𝗡𝗚𝗛𝗜𝗟𝗔𝗡𝗚𝗞𝗔𝗡 𝗕𝗔𝗥 𝗠𝗘𝗡𝗨 “𝗡𝗢𝗗𝗘𝗦, 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡𝗦, 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘, 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦, 𝗔𝗣𝗣𝗟𝗜𝗖𝗔𝗧𝗜𝗢𝗡 𝗔𝗣𝗜, 𝗠𝗢𝗨𝗡𝗧𝗦, 𝗡𝗘𝗦𝗧)",
        path: "/var/www/pterodactyl/resources/views/layouts/admin.blade.php",
        file: "admin.blade.php",
        code: `<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="{{ csrf_token() }}">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#0e4688">

        @include('layouts.scripts')

        @section('scripts')
            {!! Theme::css('vendor/select2/select2.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/admin.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/animate/animate.min.css?t={cache-version}') !!}
            {!! Theme::css('css/pterodactyl.css?t={cache-version}') !!}
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        @show
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="{{ route('index') }}" class="logo">
                    <span>{{ config('app.name', 'Pterodactyl') }}</span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="user-menu">
                                <a href="{{ route('account') }}">
                                    <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs">{{ Auth::user()->name_first }} {{ Auth::user()->name_last }}</span>
                                </a>
                            </li>
                            <li>
                                <li><a href="{{ route('index') }}" data-toggle="tooltip" data-placement="bottom" title="Exit Admin Control"><i class="fa fa-server"></i></a></li>
                            </li>
                            <li>
                                <li><a href="{{ route('auth.logout') }}" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li class="header">BASIC ADMINISTRATION</li>
                        <li class="{{ Route::currentRouteName() !== 'admin.index' ?: 'active' }}">
                            <a href="{{ route('admin.index') }}">
                                <i class="fa fa-home"></i> <span>Overview</span>
                            </a>
                        </li>
{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.settings') ?: 'active' }}">
    <a href="{{ route('admin.settings') }}">
        <i class="fa fa-wrench"></i> <span>Settings</span>
    </a>
</li>
@endif
{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.api') ?: 'active' }}">
    <a href="{{ route('admin.api.index')}}">
        <i class="fa fa-gamepad"></i> <span>Application API</span>
    </a>
</li>
@endif
<li class="header">MANAGEMENT</li>

{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.databases') ?: 'active' }}">
    <a href="{{ route('admin.databases') }}">
        <i class="fa fa-database"></i> <span>Databases</span>
    </a>
</li>
@endif

{{-- ✅ Hanya tampil untuk user ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.locations') ?: 'active' }}">
    <a href="{{ route('admin.locations') }}">
        <i class="fa fa-globe"></i> <span>Locations</span>
    </a>
</li>
@endif

{{-- ✅ Hanya tampil untuk user dengan ID 1 --}}
@if(Auth::user()->id == 1)
<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nodes') ?: 'active' }}">
    <a href="{{ route('admin.nodes') }}">
        <i class="fa fa-sitemap"></i> <span>Nodes</span>
    </a>
</li>
@endif

                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.servers') ?: 'active' }}">
                            <a href="{{ route('admin.servers') }}">
                                <i class="fa fa-server"></i> <span>Servers</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active' }}">
                            <a href="{{ route('admin.users') }}">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
{{-- ✅ Hanya tampil untuk admin utama --}}
@if(Auth::user()->id == 1)
    <li class="header">SERVICE MANAGEMENT</li>

    <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.mounts') ?: 'active' }}">
        <a href="{{ route('admin.mounts') }}">
            <i class="fa fa-magic"></i> <span>Mounts</span>
        </a>
    </li>

    <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nests') ?: 'active' }}">
        <a href="{{ route('admin.nests') }}">
            <i class="fa fa-th-large"></i> <span>Nests</span>
        </a>
    </li>
@endif
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    @yield('content-header')
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    There was an error validating the data provided.<br><br>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @foreach (Alert::getMessages() as $type => $messages)
                                @foreach ($messages as $message)
                                    <div class="alert alert-{{ $type }} alert-dismissable" role="alert">
                                        {!! $message !!}
                                    </div>
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                    @yield('content')
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw {{ $appIsGit ? 'fa-git-square' : 'fa-code-fork' }}"></i></strong> {{ $appVersion }}<br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> {{ round(microtime(true) - LARAVEL_START, 3) }}s
                </div>
                Copyright &copy; 2015 - {{ date('Y') }} <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
            </footer>
        </div>
        @section('footer-scripts')
            <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
            <script>keyboardeventKeyPolyfill.polyfill();</script>

            {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/adminlte/app.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/select2/select2.full.min.js?t={cache-version}') !!}
            {!! Theme::js('js/admin/functions.js?t={cache-version}') !!}
            <script src="/js/autocomplete.js" type="application/javascript"></script>

            @if(Auth::user()->root_admin)
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        var that = this;
                        swal({
                            title: 'Do you want to log out?',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Log out'
                        }, function () {
                             $.ajax({
                                type: 'POST',
                                url: '{{ route('auth.logout') }}',
                                data: {
                                    _token: '{{ csrf_token() }}'
                                },complete: function () {
                                    window.location.href = '{{route('auth.login')}}';
                                }
                        });
                    });
                });
                </script>
            @endif

            <script>
                $(function () {
                    $('[data-toggle="tooltip"]').tooltip();
                })
            </script>
        @show
    </body>
</html>`
      },
    ];

    // ========================= UPLOAD SEMUA PROTEKSI =========================
    let successCount = 0;

    for (const file of protectFiles) {
      try {
        const tempFile = path.join(__dirname, file.file);
        fs.writeFileSync(tempFile, file.code);
        await ssh.putFile(tempFile, file.path);
        fs.unlinkSync(tempFile);
        successCount++;
        await bot.sendMessage(chatId, `✅ *${file.name}* berhasil dipasang!\n📂 \`${file.path}\``, {
          parse_mode: "Markdown",
        });
      } catch (err) {
        await bot.sendMessage(
          chatId,
          `❌ Gagal memasang *${file.name}*\nError: \`${err.message}\``,
          { parse_mode: "Markdown" }
        );
      }
    }

    ssh.dispose();

await bot.sendMessage(
  chatId,
  `🧩 *INSTALASI PROTECT ALL SELESAI!*\n
✅ Berhasil: ${successCount}/${protectFiles.length} file\n
⚙️ Semua fitur keamanan aktif untuk panelmu.\n\n©Protect By @wilzzofficial`,
  { parse_mode: "Markdown" }
);

    console.log(`🟢 InstallProtectAll selesai untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECTALL:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menjalankan instalasi ProtectAll.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= ⚙️ INSTALL PROTECT ALL (PROTECT1–15 SEKALIGUS) =========================
bot.onText(/^\/uninstallprotect1$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
    
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  await bot.sendMessage(chatId, "🧩 *Memulai instalasi semua proteksi 1...*\nHarap tunggu beberapa saat ⏳", {
    parse_mode: "Markdown",
  });

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    // ========================= PATHS =========================
    const protectFiles = [
      {
        name: "PROTECT1 (Anti Intip Server In Settings)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php  

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;  

use Illuminate\\View\\View;  
use Illuminate\\Http\\Request;  
use Pterodactyl\\Models\\Server;  
use Spatie\\QueryBuilder\\QueryBuilder;  
use Spatie\\QueryBuilder\\AllowedFilter;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Pterodactyl\\Models\\Filters\\AdminServerFilter;  
use Illuminate\\Contracts\\View\\Factory as ViewFactory;  

class ServerController extends Controller  
{  
    /**  
     * ServerController constructor.  
     */  
    public function __construct(private ViewFactory $view)  
    {  
    }  

    /**  
     * Returns all the servers that exist on the system using a paginated result set. If  
     * a query is passed along in the request it is also passed to the repository function.  
     */  
    public function index(Request $request): View  
    {  
        $servers = QueryBuilder::for(Server::query()->with('node', 'user', 'allocation'))  
            ->allowedFilters([  
                AllowedFilter::exact('owner_id'),  
                AllowedFilter::custom('*', new AdminServerFilter()),  
            ])  
            ->paginate(config()->get('pterodactyl.paginate.admin.servers'));  

        return $this->view->make('admin.servers.index', ['servers' => $servers]);  
    }  
}`
      },
      {
        name: "PROTECT1 (Otomatis Isi Server Owner)",
        path: "/var/www/pterodactyl/resources/views/admin/servers/new.blade.php",
        file: "new.blade.php",
        code: `@extends('layouts.admin')

@section('title')
    New Server
@endsection

@section('content-header')
    <h1>Create Server<small>Add a new server to the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.servers') }}">Servers</a></li>
        <li class="active">Create Server</li>
    </ol>
@endsection

@section('content')
<form action="{{ route('admin.servers.new') }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Core Details</h3>
                </div>

                <div class="box-body row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pName">Server Name</label>
                            <input type="text" class="form-control" id="pName" name="name" value="{{ old('name') }}" placeholder="Server Name">
                            <p class="small text-muted no-margin">Character limits: <code>a-z A-Z 0-9 _ - .</code> and <code>[Space]</code>.</p>
                        </div>

                        <div class="form-group">
                            <label for="pUserId">Server Owner</label>
                            <select id="pUserId" name="owner_id" class="form-control" style="padding-left:0;"></select>
                            <p class="small text-muted no-margin">Email address of the Server Owner.</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pDescription" class="control-label">Server Description</label>
                            <textarea id="pDescription" name="description" rows="3" class="form-control">{{ old('description') }}</textarea>
                            <p class="text-muted small">A brief description of this server.</p>
                        </div>

                        <div class="form-group">
                            <div class="checkbox checkbox-primary no-margin-bottom">
                                <input id="pStartOnCreation" name="start_on_completion" type="checkbox" {{ \\Pterodactyl\\Helpers\\Utilities::checked('start_on_completion', 1) }} />
                                <label for="pStartOnCreation" class="strong">Start Server when Installed</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Allocation Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-sm-4">
                        <label for="pNodeId">Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->long }} ({{ $location->short }})">
                                @foreach($location->nodes as $node)

                                <option value="{{ $node->id }}"
                                    @if($location->id === old('location_id')) selected @endif
                                >{{ $node->name }}</option>

                                @endforeach
                                </optgroup>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">The node which this server will be deployed to.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocation">Default Allocation</label>
                        <select id="pAllocation" name="allocation_id" class="form-control"></select>
                        <p class="small text-muted no-margin">The main allocation that will be assigned to this server.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocationAdditional">Additional Allocation(s)</label>
                        <select id="pAllocationAdditional" name="allocation_additional[]" class="form-control" multiple></select>
                        <p class="small text-muted no-margin">Additional allocations to assign to this server on creation.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Application Feature Limits</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDatabaseLimit" class="control-label">Database Limit</label>
                        <div>
                            <input type="text" id="pDatabaseLimit" name="database_limit" class="form-control" value="{{ old('database_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of databases a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pAllocationLimit" class="control-label">Allocation Limit</label>
                        <div>
                            <input type="text" id="pAllocationLimit" name="allocation_limit" class="form-control" value="{{ old('allocation_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of allocations a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pBackupLimit" class="control-label">Backup Limit</label>
                        <div>
                            <input type="text" id="pBackupLimit" name="backup_limit" class="form-control" value="{{ old('backup_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of backups that can be created for this server.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Resource Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pCPU">CPU Limit</label>

                        <div class="input-group">
                            <input type="text" id="pCPU" name="cpu" class="form-control" value="{{ old('cpu', 0) }}" />
                            <span class="input-group-addon">%</span>
                        </div>

                        <p class="text-muted small">If you do not want to limit CPU usage, set the value to <code>0</code>. To determine a value, take the number of threads and multiply it by 100. For example, on a quad core system without hyperthreading <code>(4 * 100 = 400)</code> there is <code>400%</code> available. To limit a server to using half of a single thread, you would set the value to <code>50</code>. To allow a server to use up to two threads, set the value to <code>200</code>.<p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pThreads">CPU Pinning</label>

                        <div>
                            <input type="text" id="pThreads" name="threads" class="form-control" value="{{ old('threads') }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced:</strong> Enter the specific CPU threads that this process can run on, or leave blank to allow all threads. This can be a single number, or a comma separated list. Example: <code>0</code>, <code>0-1,3</code>, or <code>0,1,3,4</code>.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pMemory">Memory</label>

                        <div class="input-group">
                            <input type="text" id="pMemory" name="memory" class="form-control" value="{{ old('memory') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">The maximum amount of memory allowed for this container. Setting this to <code>0</code> will allow unlimited memory in a container.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pSwap">Swap</label>

                        <div class="input-group">
                            <input type="text" id="pSwap" name="swap" class="form-control" value="{{ old('swap', 0) }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">Setting this to <code>0</code> will disable swap space on this server. Setting to <code>-1</code> will allow unlimited swap.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDisk">Disk Space</label>

                        <div class="input-group">
                            <input type="text" id="pDisk" name="disk" class="form-control" value="{{ old('disk') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">This server will not be allowed to boot if it is using more than this amount of space. If a server goes over this limit while running it will be safely stopped and locked until enough space is available. Set to <code>0</code> to allow unlimited disk usage.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pIO">Block IO Weight</label>

                        <div>
                            <input type="text" id="pIO" name="io" class="form-control" value="{{ old('io', 500) }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced</strong>: The IO performance of this server relative to other <em>running</em> containers on the system. Value should be between <code>10</code> and <code>1000</code>. Please see <a href="https://docs.docker.com/engine/reference/run/#block-io-bandwidth-blkio-constraint" target="_blank">this documentation</a> for more information about it.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pOomDisabled" name="oom_disabled" value="0" {{ \\Pterodactyl\\Helpers\\Utilities::checked('oom_disabled', 0) }} />
                            <label for="pOomDisabled" class="strong">Enable OOM Killer</label>
                        </div>

                        <p class="small text-muted no-margin">Terminates the server if it breaches the memory limits. Enabling OOM killer may cause server processes to exit unexpectedly.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nest Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pNestId">Nest</label>

                        <select id="pNestId" name="nest_id" class="form-control">
                            @foreach($nests as $nest)
                                <option value="{{ $nest->id }}"
                                    @if($nest->id === old('nest_id'))
                                        selected="selected"
                                    @endif
                                >{{ $nest->name }}</option>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">Select the Nest that this server will be grouped under.</p>
                    </div>

                    <div class="form-group col-xs-12">
                        <label for="pEggId">Egg</label>
                        <select id="pEggId" name="egg_id" class="form-control"></select>
                        <p class="small text-muted no-margin">Select the Egg that will define how this server should operate.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pSkipScripting" name="skip_scripts" value="1" {{ \\Pterodactyl\\Helpers\\Utilities::checked('skip_scripts', 0) }} />
                            <label for="pSkipScripting" class="strong">Skip Egg Install Script</label>
                        </div>

                        <p class="small text-muted no-margin">If the selected Egg has an install script attached to it, the script will run during the install. If you would like to skip this step, check this box.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Docker Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pDefaultContainer">Docker Image</label>
                        <select id="pDefaultContainer" name="image" class="form-control"></select>
                        <input id="pDefaultContainerCustom" name="custom_image" value="{{ old('custom_image') }}" class="form-control" placeholder="Or enter a custom image..." style="margin-top:1rem"/>
                        <p class="small text-muted no-margin">This is the default Docker image that will be used to run this server. Select an image from the dropdown above, or enter a custom image in the text field above.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Startup Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pStartup">Startup Command</label>
                        <input type="text" id="pStartup" name="startup" value="{{ old('startup') }}" class="form-control" />
                        <p class="small text-muted no-margin">The following data substitutes are available for the startup command: <code>@{{SERVER_MEMORY}}</code>, <code>@{{SERVER_IP}}</code>, and <code>@{{SERVER_PORT}}</code>. They will be replaced with the allocated memory, server IP, and server port respectively.</p>
                    </div>
                </div>

                <div class="box-header with-border" style="margin-top:-10px;">
                    <h3 class="box-title">Service Variables</h3>
                </div>

                <div class="box-body row" id="appendVariablesTo"></div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    <input type="submit" class="btn btn-success pull-right" value="Create Server" />
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('vendor/lodash/lodash.js') !!}

    <script type="application/javascript">
        // Persist 'Service Variables'
        function serviceVariablesUpdated(eggId, ids) {
            @if (old('egg_id'))
                // Check if the egg id matches.
                if (eggId != '{{ old('egg_id') }}') {
                    return;
                }

                @if (old('environment'))
                    @foreach (old('environment') as $key => $value)
                        $('#' + ids['{{ $key }}']).val('{{ $value }}');
                    @endforeach
                @endif
            @endif
            @if(old('image'))
                $('#pDefaultContainer').val('{{ old('image') }}');
            @endif
        }
        // END Persist 'Service Variables'
    </script>

    {!! Theme::js('js/admin/new-server.js?v=20220530') !!}

    <script type="application/javascript">
        $(document).ready(function() {
            // Persist 'Server Owner' select2
            @if (old('owner_id'))
                $.ajax({
                    url: '/admin/users/accounts.json?user_id={{ old('owner_id') }}',
                    dataType: 'json',
                }).then(function (data) {
                    initUserIdSelect([ data ]);
                });
            @else
                initUserIdSelect();
            @endif
            // END Persist 'Server Owner' select2

            // Persist 'Node' select2
            @if (old('node_id'))
                $('#pNodeId').val('{{ old('node_id') }}').change();

                // Persist 'Default Allocation' select2
                @if (old('allocation_id'))
                    $('#pAllocation').val('{{ old('allocation_id') }}').change();
                @endif
                // END Persist 'Default Allocation' select2

                // Persist 'Additional Allocations' select2
                @if (old('allocation_additional'))
                    const additional_allocations = [];

                    @for ($i = 0; $i < count(old('allocation_additional')); $i++)
                        additional_allocations.push('{{ old('allocation_additional.'.$i)}}');
                    @endfor

                    $('#pAllocationAdditional').val(additional_allocations).change();
                @endif
                // END Persist 'Additional Allocations' select2
            @endif
            // END Persist 'Node' select2

            // Persist 'Nest' select2
            @if (old('nest_id'))
                $('#pNestId').val('{{ old('nest_id') }}').change();

                // Persist 'Egg' select2
                @if (old('egg_id'))
                    $('#pEggId').val('{{ old('egg_id') }}').change();
                @endif
                // END Persist 'Egg' select2
            @endif
            // END Persist 'Nest' select2
        });
    </script>
@endsection
`
      },
      {
        name: "PROTECT1 (Anti Update Detail Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/DetailsModificationService.php",
        file: "DetailsModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\ReturnsUpdatedModels;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class DetailsModificationService
{
    use ReturnsUpdatedModels;

    /**
     * DetailsModificationService constructor.
     */
    public function __construct(private ConnectionInterface $connection, private DaemonServerRepository $serverRepository)
    {
    }

    /**
     * Update the details for a single server instance.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        return $this->connection->transaction(function () use ($data, $server) {
            $owner = $server->owner_id;

            $server->forceFill([
                'external_id' => Arr::get($data, 'external_id'),
                'owner_id' => Arr::get($data, 'owner_id'),
                'name' => Arr::get($data, 'name'),
                'description' => Arr::get($data, 'description') ?? '',
            ])->saveOrFail();

            // If the owner_id value is changed we need to revoke any tokens that exist for the server
            // on the Wings instance so that the old owner no longer has any permission to access the
            // websockets.
            if ($server->owner_id !== $owner) {
                try {
                    $this->serverRepository->setServer($server)->revokeUserJTI($owner);
                } catch (DaemonConnectionException $exception) {
                    // Do nothing. A failure here is not ideal, but it is likely to be caused by Wings
                    // being offline, or in an entirely broken state. Remember, these tokens reset every
                    // few minutes by default, we're just trying to help it along a little quicker.
                }
            }

            return $server;
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Build Configuration Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/BuildModificationService.php",
        file: "BuildModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Allocation;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Database\\Eloquent\\ModelNotFoundException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class BuildModificationService
{
    /**
     * BuildModificationService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private ServerConfigurationStructureService $structureService
    ) {
    }

    /**
     * Change the build details for a specified server.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server, array $data): Server
    {
        /** @var \\Pterodactyl\\Models\\Server $server */
        $server = $this->connection->transaction(function () use ($server, $data) {
            $this->processAllocations($server, $data);

            if (isset($data['allocation_id']) && $data['allocation_id'] != $server->allocation_id) {
                try {
                    Allocation::query()->where('id', $data['allocation_id'])->where('server_id', $server->id)->firstOrFail();
                } catch (ModelNotFoundException) {
                    throw new DisplayException('The requested default allocation is not currently assigned to this server.');
                }
            }

            // If any of these values are passed through in the data array go ahead and set
            // them correctly on the server model.
            $merge = Arr::only($data, ['oom_disabled', 'memory', 'swap', 'io', 'cpu', 'threads', 'disk', 'allocation_id']);

            $server->forceFill(array_merge($merge, [
                'database_limit' => Arr::get($data, 'database_limit', 0) ?? null,
                'allocation_limit' => Arr::get($data, 'allocation_limit', 0) ?? null,
                'backup_limit' => Arr::get($data, 'backup_limit', 0) ?? 0,
            ]))->saveOrFail();

            return $server->refresh();
        });

        $updateData = $this->structureService->handle($server);

        // Because Wings always fetches an updated configuration from the Panel when booting
        // a server this type of exception can be safely "ignored" and just written to the logs.
        // Ideally this request succeeds, so we can apply resource modifications on the fly, but
        // if it fails we can just continue on as normal.
        if (!empty($updateData['build'])) {
            try {
                $this->daemonServerRepository->setServer($server)->sync();
            } catch (DaemonConnectionException $exception) {
                Log::warning($exception, ['server_id' => $server->id]);
            }
        }

        return $server;
    }

    /**
     * Process the allocations being assigned in the data and ensure they are available for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    private function processAllocations(Server $server, array &$data): void
    {
        if (empty($data['add_allocations']) && empty($data['remove_allocations'])) {
            return;
        }

        // Handle the addition of allocations to this server. Only assign allocations that are not currently
        // assigned to a different server, and only allocations on the same node as the server.
        if (!empty($data['add_allocations'])) {
            $query = Allocation::query()
                ->where('node_id', $server->node_id)
                ->whereIn('id', $data['add_allocations'])
                ->whereNull('server_id');

            // Keep track of all the allocations we're just now adding so that we can use the first
            // one to reset the default allocation to.
            $freshlyAllocated = $query->pluck('id')->first();

            $query->update(['server_id' => $server->id, 'notes' => null]);
        }

        if (!empty($data['remove_allocations'])) {
            foreach ($data['remove_allocations'] as $allocation) {
                // If we are attempting to remove the default allocation for the server, see if we can reassign
                // to the first provided value in add_allocations. If there is no new first allocation then we
                // will throw an exception back.
                if ($allocation === ($data['allocation_id'] ?? $server->allocation_id)) {
                    if (empty($freshlyAllocated)) {
                        throw new DisplayException('You are attempting to delete the default allocation for this server but there is no fallback allocation to use.');
                    }

                    // Update the default allocation to be the first allocation that we are creating.
                    $data['allocation_id'] = $freshlyAllocated;
                }
            }

            // Remove any of the allocations we got that are currently assigned to this server on
            // this node. Also set the notes to null, otherwise when re-allocated to a new server those
            // notes will be carried over.
            Allocation::query()->where('node_id', $server->node_id)
                ->where('server_id', $server->id)
                // Only remove the allocations that we didn't also attempt to add to the server...
                ->whereIn('id', array_diff($data['remove_allocations'], $data['add_allocations'] ?? []))
                ->update([
                    'notes' => null,
                    'server_id' => null,
                ]);
        }
    }
}
`
      },
      {
        name: "PROTECT1 (Anti Setup Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/StartupModificationService.php",
        file: "StartupModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Egg;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\ServerVariable;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\HasUserLevels;

class StartupModificationService
{
    use HasUserLevels;

    /**
     * StartupModificationService constructor.
     */
    public function __construct(private ConnectionInterface $connection, private VariableValidatorService $validatorService)
    {
    }

    /**
     * Process startup modification for a server.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        return $this->connection->transaction(function () use ($server, $data) {
            if (!empty($data['environment'])) {
                $egg = $this->isUserLevel(User::USER_LEVEL_ADMIN) ? ($data['egg_id'] ?? $server->egg_id) : $server->egg_id;

                $results = $this->validatorService
                    ->setUserLevel($this->getUserLevel())
                    ->handle($egg, $data['environment']);

                foreach ($results as $result) {
                    ServerVariable::query()->updateOrCreate(
                        [
                            'server_id' => $server->id,
                            'variable_id' => $result->id,
                        ],
                        ['variable_value' => $result->value ?? '']
                    );
                }
            }

            if ($this->isUserLevel(User::USER_LEVEL_ADMIN)) {
                $this->updateAdministrativeSettings($data, $server);
            }

            return $server->fresh();
        });
    }

    /**
     * Update certain administrative settings for a server in the DB.
     */
    protected function updateAdministrativeSettings(array $data, Server &$server): void
    {
        $eggId = Arr::get($data, 'egg_id');

        if (is_digit($eggId) && $server->egg_id !== (int) $eggId) {
            /** @var \\Pterodactyl\\Models\\Egg $egg */
            $egg = Egg::query()->findOrFail($data['egg_id']);

            $server = $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ]);
        }

        $server->fill([
            'startup' => $data['startup'] ?? $server->startup,
            'skip_scripts' => $data['skip_scripts'] ?? isset($data['skip_scripts']),
            'image' => $data['docker_image'] ?? $server->image,
        ])->save();
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Database)",
        path: "/var/www/pterodactyl/app/Services/Databases/DatabaseManagementService.php",
        file: "DatabaseManagementService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Databases;

use Exception;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Helpers\\Utilities;
use Illuminate\\Database\\ConnectionInterface;
use Illuminate\\Contracts\\Encryption\\Encrypter;
use Pterodactyl\\Extensions\\DynamicDatabaseConnection;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseRepository;
use Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException;
use Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException;
use Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException;

class DatabaseManagementService
{
    /**
     * The regex used to validate that the database name passed through to the function is
     * in the expected format.
     *
     * @see \\Pterodactyl\\Services\\Databases\\DatabaseManagementService::generateUniqueDatabaseName()
     */
    private const MATCH_NAME_REGEX = '/^(s[\\d]+_)(.*)$/';

    /**
     * Determines if the service should validate the user's ability to create an additional
     * database for this server. In almost all cases this should be true, but to keep things
     * flexible you can also set it to false and create more databases than the server is
     * allocated.
     */
    protected bool $validateDatabaseLimit = true;

    public function __construct(
        protected ConnectionInterface $connection,
        protected DynamicDatabaseConnection $dynamic,
        protected Encrypter $encrypter,
        protected DatabaseRepository $repository
    ) {
    }

    /**
     * Generates a unique database name for the given server. This name should be passed through when
     * calling this handle function for this service, otherwise the database will be created with
     * whatever name is provided.
     */
    public static function generateUniqueDatabaseName(string $name, int $serverId): string
    {
        // Max of 48 characters, including the s123_ that we append to the front.
        return sprintf('s%d_%s', $serverId, substr($name, 0, 48 - strlen("s{$serverId}_")));
    }

    /**
     * Set whether this class should validate that the server has enough slots
     * left before creating the new database.
     */
    public function setValidateDatabaseLimit(bool $validate): self
    {
        $this->validateDatabaseLimit = $validate;

        return $this;
    }

    /**
     * Create a new database that is linked to a specific host.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException
     * @throws \\Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException
     */
    public function create(Server $server, array $data): Database
    {
        if (!config('pterodactyl.client_features.databases.enabled')) {
            throw new DatabaseClientFeatureNotEnabledException();
        }

        if ($this->validateDatabaseLimit) {
            // If the server has a limit assigned and we've already reached that limit, throw back
            // an exception and kill the process.
            if (!is_null($server->database_limit) && $server->databases()->count() >= $server->database_limit) {
                throw new TooManyDatabasesException();
            }
        }

        // Protect against developer mistakes...
        if (empty($data['database']) || !preg_match(self::MATCH_NAME_REGEX, $data['database'])) {
            throw new \\InvalidArgumentException('The database name passed to DatabaseManagementService::handle MUST be prefixed with "s{server_id}_".');
        }

        $data = array_merge($data, [
            'server_id' => $server->id,
            'username' => sprintf('u%d_%s', $server->id, str_random(10)),
            'password' => $this->encrypter->encrypt(
                Utilities::randomStringWithSpecialCharacters(24)
            ),
        ]);

        $database = null;

        try {
            return $this->connection->transaction(function () use ($data, &$database) {
                $database = $this->createModel($data);

                $this->dynamic->set('dynamic', $data['database_host_id']);

                $this->repository->createDatabase($database->database);
                $this->repository->createUser(
                    $database->username,
                    $database->remote,
                    $this->encrypter->decrypt($database->password),
                    $database->max_connections
                );
                $this->repository->assignUserToDatabase($database->database, $database->username, $database->remote);
                $this->repository->flush();

                return $database;
            });
        } catch (\\Exception $exception) {
            try {
                if ($database instanceof Database) {
                    $this->repository->dropDatabase($database->database);
                    $this->repository->dropUser($database->username, $database->remote);
                    $this->repository->flush();
                }
            } catch (\\Exception $deletionException) {
                // Do nothing here. We've already encountered an issue before this point so no
                // reason to prioritize this error over the initial one.
            }

            throw $exception;
        }
    }

    /**
     * Delete a database from the given host server.
     *
     * @throws \\Exception
     */
    public function delete(Database $database): ?bool
    {
        $this->dynamic->set('dynamic', $database->database_host_id);

        $this->repository->dropDatabase($database->database);
        $this->repository->dropUser($database->username, $database->remote);
        $this->repository->flush();

        return $database->delete();
    }

    /**
     * Create the database if there is not an identical match in the DB. While you can technically
     * have the same name across multiple hosts, for the sake of keeping this logic easy to understand
     * and avoiding user confusion we will ignore the specific host and just look across all hosts.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException
     * @throws \\Throwable
     */
    protected function createModel(array $data): Database
    {
        $exists = Database::query()->where('server_id', $data['server_id'])
            ->where('database', $data['database'])
            ->exists();

        if ($exists) {
            throw new DuplicateDatabaseNameException('A database with that name already exists for this server.');
        }

        $database = (new Database())->forceFill($data);
        $database->saveOrFail();

        return $database;
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Transfer This Server)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerTransferController.php",
        file: "ServerTransferController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Models\\ServerTransfer;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Eloquent\\NodeRepository;
use Pterodactyl\\Repositories\\Wings\\DaemonTransferRepository;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;

class ServerTransferController extends Controller
{
    /**
     * ServerTransferController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private AllocationRepositoryInterface $allocationRepository,
        private ConnectionInterface $connection,
        private DaemonTransferRepository $daemonTransferRepository,
        private NodeJWTService $nodeJWTService,
        private NodeRepository $nodeRepository
    ) {
    }

    /**
     * Starts a transfer of a server to a new node.
     *
     * @throws \\Throwable
     */
    public function transfer(Request $request, Server $server): RedirectResponse
    {
        $validatedData = $request->validate([
            'node_id' => 'required|exists:nodes,id',
            'allocation_id' => 'required|bail|unique:servers|exists:allocations,id',
            'allocation_additional' => 'nullable',
        ]);

        $node_id = $validatedData['node_id'];
        $allocation_id = intval($validatedData['allocation_id']);
        $additional_allocations = array_map('intval', $validatedData['allocation_additional'] ?? []);

        // Check if the node is viable for the transfer.
        $node = $this->nodeRepository->getNodeWithResourceUsage($node_id);
        if (!$node->isViable($server->memory, $server->disk)) {
            $this->alert->danger(trans('admin/server.alerts.transfer_not_viable'))->flash();

            return redirect()->route('admin.servers.view.manage', $server->id);
        }

        $server->validateTransferState();

        $this->connection->transaction(function () use ($server, $node_id, $allocation_id, $additional_allocations) {
            // Create a new ServerTransfer entry.
            $transfer = new ServerTransfer();

            $transfer->server_id = $server->id;
            $transfer->old_node = $server->node_id;
            $transfer->new_node = $node_id;
            $transfer->old_allocation = $server->allocation_id;
            $transfer->new_allocation = $allocation_id;
            $transfer->old_additional_allocations = $server->allocations->where('id', '!=', $server->allocation_id)->pluck('id');
            $transfer->new_additional_allocations = $additional_allocations;

            $transfer->save();

            // Add the allocations to the server, so they cannot be automatically assigned while the transfer is in progress.
            $this->assignAllocationsToServer($server, $node_id, $allocation_id, $additional_allocations);

            // Generate a token for the destination node that the source node can use to authenticate with.
            $token = $this->nodeJWTService
                ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
                ->setSubject($server->uuid)
                ->handle($transfer->newNode, $server->uuid, 'sha256');

            // Notify the source node of the pending outgoing transfer.
            $this->daemonTransferRepository->setServer($server)->notify($transfer->newNode, $token);

            return $transfer;
        });

        $this->alert->success(trans('admin/server.alerts.transfer_started'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Assigns the specified allocations to the specified server.
     */
    private function assignAllocationsToServer(Server $server, int $node_id, int $allocation_id, array $additional_allocations)
    {
        $allocations = $additional_allocations;
        $allocations[] = $allocation_id;

        $unassigned = $this->allocationRepository->getUnassignedAllocationIds($node_id);

        $updateIds = [];
        foreach ($allocations as $allocation) {
            if (!in_array($allocation, $unassigned)) {
                continue;
            }

            $updateIds[] = $allocation;
        }

        if (!empty($updateIds)) {
            $this->allocationRepository->updateWhereIn('id', $updateIds, ['server_id' => $server->id]);
        }
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Suspend Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /**
     * Toggles the installation status for a server.
     *
* @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function toggleInstall(Server $server): RedirectResponse
    {
        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
            'status' => $request->input('action') . 'ed',
        ]))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Toggle Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /**
     * Toggles the installation status for a server.
     *
* @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function toggleInstall(Server $server): RedirectResponse
    {
        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
            'status' => $request->input('action') . 'ed',
        ]))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;

class ReinstallServerService
{
    /**
     * ReinstallService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {
    }

    /**
     * Reinstall a server on the remote daemon.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server): Server
    {
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Delete Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/ServerDeletionService.php",
        file: "ServerDeletionService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    /**
     * ServerDeletionService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService
    ) {
    }

    /**
     * Set if the server should be forcibly deleted from the panel (ignoring daemon errors) or not.
     */
    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;

        return $this;
    }

    /**
     * Delete a server from the panel and remove any associated databases from hosts.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server): void
    {
        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw $exception;
            }

            Log::warning($exception);
        }

        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\\Exception $exception) {
                    if (!$this->force) {
                        throw $exception;
                    }

                    $database->delete();

                    Log::warning($exception);
                }
            }

            $server->delete();
        });
    }
}`
      },
    ];

    // ========================= UPLOAD SEMUA PROTEKSI =========================
    let successCount = 0;

    for (const file of protectFiles) {
      try {
        const tempFile = path.join(__dirname, file.file);
        fs.writeFileSync(tempFile, file.code);
        await ssh.putFile(tempFile, file.path);
        fs.unlinkSync(tempFile);
        successCount++;
        await bot.sendMessage(chatId, `✅ *${file.name}* berhasil dipasang!\n📂 \`${file.path}\``, {
          parse_mode: "Markdown",
        });
      } catch (err) {
        await bot.sendMessage(
          chatId,
          `❌ Gagal memasang *${file.name}*\nError: \`${err.message}\``,
          { parse_mode: "Markdown" }
        );
      }
    }

    ssh.dispose();

await bot.sendMessage(
  chatId,
  `🧩 *UNINSTALL PROTECT 1 SELESAI!*\n
✅ Berhasil: ${successCount}/${protectFiles.length} file\n
⚙️ Semua fitur keamanan aktif untuk panelmu.\n\n©Protect By @wilzzofficial`,
  { parse_mode: "Markdown" }
);

    console.log(`🟢 UninstallProtect1 selesai untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT1:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menjalankan instalasi Protect1.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT2 (ANTI INTIP USERS & ANTI CADMIN - FINAL FIX) =========================
bot.onText(/^\/uninstallprotect2$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/UserController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Model;
use Illuminate\\Support\\Collection;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Spatie\\QueryBuilder\\QueryBuilder;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Contracts\\Translation\\Translator;
use Pterodactyl\\Services\\Users\\UserUpdateService;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Users\\UserCreationService;
use Pterodactyl\\Services\\Users\\UserDeletionService;
use Pterodactyl\\Http\\Requests\\Admin\\UserFormRequest;
use Pterodactyl\\Http\\Requests\\Admin\\NewUserFormRequest;
use Pterodactyl\\Contracts\\Repository\\UserRepositoryInterface;

class UserController extends Controller
{
    use AvailableLanguages;

    /**
     * UserController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected UserCreationService $creationService,
        protected UserDeletionService $deletionService,
        protected Translator $translator,
        protected UserUpdateService $updateService,
        protected UserRepositoryInterface $repository,
        protected ViewFactory $view
    ) {
    }

    /**
     * Display user index page.
     */
    public function index(Request $request): View
    {
        $users = QueryBuilder::for(
            User::query()->select('users.*')
                ->selectRaw('COUNT(DISTINCT(subusers.id)) as subuser_of_count')
                ->selectRaw('COUNT(DISTINCT(servers.id)) as servers_count')
                ->leftJoin('subusers', 'subusers.user_id', '=', 'users.id')
                ->leftJoin('servers', 'servers.owner_id', '=', 'users.id')
                ->groupBy('users.id')
        )
            ->allowedFilters(['username', 'email', 'uuid'])
            ->allowedSorts(['id', 'uuid'])
            ->paginate(50);

        return $this->view->make('admin.users.index', ['users' => $users]);
    }

    /**
     * Display new user page.
     */
    public function create(): View
    {
        return $this->view->make('admin.users.new', [
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Display user view page.
     */
    public function view(User $user): View
    {
        return $this->view->make('admin.users.view', [
            'user' => $user,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Delete a user from the system.
     *
     * @throws \\Exception
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function delete(Request $request, User $user): RedirectResponse
    {
        if ($request->user()->id === $user->id) {
            throw new DisplayException($this->translator->get('admin/user.exceptions.user_has_servers'));
        }

        $this->deletionService->handle($user);

        return redirect()->route('admin.users');
    }

    /**
     * Create a user.
     *
     * @throws \\Exception
     * @throws \\Throwable
     */
    public function store(NewUserFormRequest $request): RedirectResponse
    {
        $user = $this->creationService->handle($request->normalize());
        $this->alert->success($this->translator->get('admin/user.notices.account_created'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Update a user on the system.
     *
* @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(UserFormRequest $request, User $user): RedirectResponse
    {
        $this->updateService
            ->setUserLevel(User::USER_LEVEL_ADMIN)
            ->handle($user, $request->normalize());

        $this->alert->success(trans('admin/user.notices.account_updated'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Get a JSON response of users on the system.
     */
    public function json(Request $request): Model|Collection
    {
        $users = QueryBuilder::for(User::query())->allowedFilters(['email'])->paginate(25);

        // Handle single user requests.
        if ($request->query('user_id')) {
            $user = User::query()->findOrFail($request->input('user_id'));
            $user->md5 = md5(strtolower($user->email));

            return $user;
        }

        return $users->map(function ($item) {
            $item->md5 = md5(strtolower($item->email));

            return $item;
        });
    }
}
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "UserController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `✅ *PROTECT2 (ANTI INTIP USERS & ANTI CADMIN) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect2 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECY2:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal Menghapus PROTECT2.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT3 (ANTI INTIP LOCATION - FINAL) =========================
bot.onText(/^\/uninstallprotect3$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/LocationController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Pterodactyl\\Models\\Location;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\LocationFormRequest;
use Pterodactyl\\Services\\Locations\\LocationUpdateService;
use Pterodactyl\\Services\\Locations\\LocationCreationService;
use Pterodactyl\\Services\\Locations\\LocationDeletionService;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class LocationController extends Controller
{
    /**
     * LocationController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected LocationCreationService $creationService,
        protected LocationDeletionService $deletionService,
        protected LocationRepositoryInterface $repository,
        protected LocationUpdateService $updateService,
        protected ViewFactory $view
    ) {
    }

    /**
     * Return the location overview page.
     */
    public function index(): View
    {
        return $this->view->make('admin.locations.index', [
            'locations' => $this->repository->getAllWithDetails(),
        ]);
    }

    /**
     * Return the location view page.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(int $id): View
    {
        return $this->view->make('admin.locations.view', [
            'location' => $this->repository->getWithNodes($id),
        ]);
    }

    /**
     * Handle request to create new location.
     *
     * @throws \\Throwable
     */
    public function create(LocationFormRequest $request): RedirectResponse
    {
        $location = $this->creationService->handle($request->normalize());
        $this->alert->success('Location was created successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    /**
     * Handle request to update or delete location.
     *
     * @throws \\Throwable
     */
    public function update(LocationFormRequest $request, Location $location): RedirectResponse
    {
        if ($request->input('action') === 'delete') {
            return $this->delete($location);
        }

        $this->updateService->handle($location->id, $request->normalize());
        $this->alert->success('Location was updated successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    /**
     * Delete a location from the system.
     *
     * @throws \\Exception
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function delete(Location $location): RedirectResponse
    {
        try {
            $this->deletionService->handle($location->id);

            return redirect()->route('admin.locations');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }

        return redirect()->route('admin.locations.view', $location->id);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "LocationController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `✅ *PROTECT3 (ANTI INTIP LOCATION) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy SecureShield v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🟢 Protect3 aktif untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT3:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT3.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT4 (ANTI INTIP NODES - FINAL FIX) =========================
bot.onText(/^\/uninstallprotect4$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/Nodes/NodeController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nodes;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Node;
use Spatie\\QueryBuilder\\QueryBuilder;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;

class NodeController extends Controller
{
    /**
     * NodeController constructor.
     */
    public function __construct(private ViewFactory $view)
    {
    }

    /**
     * Returns a listing of nodes on the system.
     */
    public function index(Request $request): View
    {
        $nodes = QueryBuilder::for(
            Node::query()->with('location')->withCount('servers')
        )
            ->allowedFilters(['uuid', 'name'])
            ->allowedSorts(['id'])
            ->paginate(25);

        return $this->view->make('admin.nodes.index', ['nodes' => $nodes]);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "NodeController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `✅ *PROTECT4 (ANTI INTIP NODES) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect4 DI Hapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT4:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT4.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT5 (ANTI INTIP NEST - FINAL FIX) =========================
bot.onText(/^\/uninstallprotect5$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/Nests/NestController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nests;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nests\\NestUpdateService;
use Pterodactyl\\Services\\Nests\\NestCreationService;
use Pterodactyl\\Services\\Nests\\NestDeletionService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Nest\\StoreNestFormRequest;

class NestController extends Controller
{
    /**
     * NestController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestCreationService $nestCreationService,
        protected NestDeletionService $nestDeletionService,
        protected NestRepositoryInterface $repository,
        protected NestUpdateService $nestUpdateService,
        protected ViewFactory $view
    ) {
    }

    /**
     * Render nest listing page.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function index(): View
    {
        return $this->view->make('admin.nests.index', [
            'nests' => $this->repository->getWithCounts(),
        ]);
    }

    /**
     * Render nest creation page.
     */
    public function create(): View
    {
        return $this->view->make('admin.nests.new');
    }

    /**
     * Handle the storage of a new nest.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     */
    public function store(StoreNestFormRequest $request): RedirectResponse
    {
        $nest = $this->nestCreationService->handle($request->normalize());
        $this->alert->success(trans('admin/nests.notices.created', ['name' => htmlspecialchars($nest->name)]))->flash();

        return redirect()->route('admin.nests.view', $nest->id);
    }

    /**
     * Return details about a nest including all the eggs and servers per egg.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(int $nest): View
    {
        return $this->view->make('admin.nests.view', [
            'nest' => $this->repository->getWithEggServers($nest),
        ]);
    }

    /**
     * Handle request to update a nest.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(StoreNestFormRequest $request, int $nest): RedirectResponse
    {
        $this->nestUpdateService->handle($nest, $request->normalize());
        $this->alert->success(trans('admin/nests.notices.updated'))->flash();

        return redirect()->route('admin.nests.view', $nest);
    }

    /**
     * Handle request to delete a nest.
     *
     * @throws \\Pterodactyl\\Exceptions\\Service\\HasActiveServersException
     */
    public function destroy(int $nest): RedirectResponse
    {
        $this->nestDeletionService->handle($nest);
        $this->alert->success(trans('admin/nests.notices.deleted'))->flash();

        return redirect()->route('admin.nests');
    }
}
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "NestController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT5 (ANTI INTIP NEST) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect5 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT5:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT5.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT6 (ANTI INTIP SETTINGS - FINAL FIX) =========================
bot.onText(/^\/uninstallprotect6$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/Settings/IndexController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Settings;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\Contracts\\Console\\Kernel;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Helpers\\SoftwareVersionService;
use Pterodactyl\\Contracts\\Repository\\SettingsRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Settings\\BaseSettingsFormRequest;

class IndexController extends Controller
{
    use AvailableLanguages;

    /**
     * IndexController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private SoftwareVersionService $versionService,
        private ViewFactory $view
    ) {
    }

    /**
     * Render the UI for basic Panel settings.
     */
    public function index(): View
    {
        return $this->view->make('admin.settings.index', [
            'version' => $this->versionService,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Handle settings update.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(BaseSettingsFormRequest $request): RedirectResponse
    {
        foreach ($request->normalize() as $key => $value) {
            $this->settings->set('settings::' . $key, $value);
        }

        $this->kernel->call('queue:restart');
        $this->alert->success('Panel settings have been updated successfully and the queue worker was restarted to apply these changes.')->flash();

        return redirect()->route('admin.settings');
    }
}
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "IndexController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT6 (ANTI INTIP SETTINGS) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect6 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT6:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT6.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT7 (ANTI AKSES FILE & DOWNLOAD) =========================
bot.onText(/^\/uninstallprotect7$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/FileController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Wings\\DaemonFileRepository;
use Pterodactyl\\Transformers\\Api\\Client\\FileObjectTransformer;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\CopyFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\PullFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\ListFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\ChmodFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\DeleteFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\RenameFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\CreateFolderRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\CompressFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\DecompressFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\GetFileContentsRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\WriteFileContentRequest;

class FileController extends ClientApiController
{
    /**
     * FileController constructor.
     */
    public function __construct(
        private NodeJWTService $jwtService,
        private DaemonFileRepository $fileRepository
    ) {
        parent::__construct();
    }

    /**
     * Returns a listing of files in a given directory.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function directory(ListFilesRequest $request, Server $server): array
    {
        $contents = $this->fileRepository
            ->setServer($server)
            ->getDirectory($request->get('directory') ?? '/');

        return $this->fractal->collection($contents)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    /**
     * Return the contents of a specified file for the user.
     *
     * @throws \\Throwable
     */
    public function contents(GetFileContentsRequest $request, Server $server): Response
    {
        $response = $this->fileRepository->setServer($server)->getContent(
            $request->get('file'),
            config('pterodactyl.files.max_edit_size')
        );

        Activity::event('server:file.read')->property('file', $request->get('file'))->log();

        return new Response($response, Response::HTTP_OK, ['Content-Type' => 'text/plain']);
    }

    /**
     * Generates a one-time token with a link that the user can use to
     * download a given file.
     *
     * @throws \\Throwable
     */
    public function download(GetFileContentsRequest $request, Server $server): array
    {
        $token = $this->jwtService
            ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
            ->setUser($request->user())
            ->setClaims([
                'file_path' => rawurldecode($request->get('file')),
                'server_uuid' => $server->uuid,
            ])
            ->handle($server->node, $request->user()->id . $server->uuid);

        Activity::event('server:file.download')->property('file', $request->get('file'))->log();

        return [
            'object' => 'signed_url',
            'attributes' => [
                'url' => sprintf(
                    '%s/download/file?token=%s',
                    $server->node->getConnectionAddress(),
                    $token->toString()
                ),
            ],
        ];
    }

    /**
     * Writes the contents of the specified file to the server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function write(WriteFileContentRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->putContent($request->get('file'), $request->getContent());

        Activity::event('server:file.write')->property('file', $request->get('file'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Creates a new folder on the server.
     *
     * @throws \\Throwable
     */
    public function create(CreateFolderRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository
            ->setServer($server)
            ->createDirectory($request->input('name'), $request->input('root', '/'));

        Activity::event('server:file.create-directory')
            ->property('name', $request->input('name'))
            ->property('directory', $request->input('root'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Renames a file on the remote machine.
     *
     * @throws \\Throwable
     */
    public function rename(RenameFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository
            ->setServer($server)
            ->renameFiles($request->input('root'), $request->input('files'));

        Activity::event('server:file.rename')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Copies a file on the server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function copy(CopyFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository
            ->setServer($server)
            ->copyFile($request->input('location'));

        Activity::event('server:file.copy')->property('file', $request->input('location'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function compress(CompressFilesRequest $request, Server $server): array
    {
        $file = $this->fileRepository->setServer($server)->compressFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.compress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return $this->fractal->item($file)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    /**
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function decompress(DecompressFilesRequest $request, Server $server): JsonResponse
    {
        set_time_limit(300);

        $this->fileRepository->setServer($server)->decompressFile(
            $request->input('root'),
            $request->input('file')
        );

        Activity::event('server:file.decompress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('file'))
            ->log();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }

    /**
     * Deletes files or folders for the server in the given root directory.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function delete(DeleteFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->deleteFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.delete')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Updates file permissions for file(s) in the given root directory.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function chmod(ChmodFilesRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->chmodFiles(
            $request->input('root'),
            $request->input('files')
        );

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Requests that a file be downloaded from a remote location by Wings.
     *
     * @throws \\Throwable
     */
    public function pull(PullFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->pull(
            $request->input('url'),
            $request->input('directory'),
            $request->safe(['filename', 'use_header', 'foreground'])
        );

        Activity::event('server:file.pull')
            ->property('directory', $request->input('directory'))
            ->property('url', $request->input('url'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "FileController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT7 (ANTI AKSES FILE & DOWNLOAD SERVER) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect7 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT7:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT7.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT8 (ANTI INTIP SERVER) =========================
bot.onText(/^\/uninstallprotect8$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/ServerController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Pterodactyl\\Models\\Server;
use Pterodactyl\\Transformers\\Api\\Client\\ServerTransformer;
use Pterodactyl\\Services\\Servers\\GetUserPermissionsService;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\GetServerRequest;

class ServerController extends ClientApiController
{
    /**
     * ServerController constructor.
     */
    public function __construct(private GetUserPermissionsService $permissionsService)
    {
        parent::__construct();
    }

    /**
     * Transform an individual server into a response that can be consumed by a
     * client using the API.
     */
    public function index(GetServerRequest $request, Server $server): array
    {
        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->addMeta([
                'is_server_owner' => $request->user()->id === $server->owner_id,
                'user_permissions' => $this->permissionsService->handle($server, $request->user()),
            ])
            ->toArray();
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "ServerController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT8 (ANTI INTIP SERVER) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect8 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTCT8:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT8.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT9 (ANTI INTIP APIKEY) =========================
bot.onText(/^\/uninstallprotect9$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/ApiController.php";

  const phpCode = `<?php  
  
namespace Pterodactyl\\Http\\Controllers\\Admin;  
  
use Illuminate\\View\\View;  
use Illuminate\\Http\\Request;  
use Illuminate\\Http\\Response;  
use Pterodactyl\\Models\\ApiKey;  
use Illuminate\\Http\\RedirectResponse;  
use Prologue\\Alerts\\AlertsMessageBag;  
use Pterodactyl\\Services\\Acl\\Api\\AdminAcl;  
use Illuminate\\View\\Factory as ViewFactory;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Pterodactyl\\Services\\Api\\KeyCreationService;  
use Pterodactyl\\Contracts\\Repository\\ApiKeyRepositoryInterface;  
use Pterodactyl\\Http\\Requests\\Admin\\Api\\StoreApplicationApiKeyRequest;  
  
class ApiController extends Controller  
{  
    /**  
     * ApiController constructor.  
     */  
    public function __construct(  
        private AlertsMessageBag $alert,  
        private ApiKeyRepositoryInterface $repository,  
        private KeyCreationService $keyCreationService,  
        private ViewFactory $view,  
    ) {  
    }  
  
    /**  
     * Render view showing all of a user's application API keys.  
     */  
    public function index(Request $request): View  
    {  
        return $this->view->make('admin.api.index', [  
            'keys' => $this->repository->getApplicationKeys($request->user()),  
        ]);  
    }  
  
    /**  
     * Render view allowing an admin to create a new application API key.  
     *  
     * @throws \\ReflectionException  
     */  
    public function create(): View  
    {  
        $resources = AdminAcl::getResourceList();  
        sort($resources);  
  
        return $this->view->make('admin.api.new', [  
            'resources' => $resources,  
            'permissions' => [  
                'r' => AdminAcl::READ,  
                'rw' => AdminAcl::READ | AdminAcl::WRITE,  
                'n' => AdminAcl::NONE,  
            ],  
        ]);  
    }  
  
    /**  
     * Store the new key and redirect the user back to the application key listing.  
     *  
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException  
     */  
    public function store(StoreApplicationApiKeyRequest $request): RedirectResponse  
    {  
        $this->keyCreationService->setKeyType(ApiKey::TYPE_APPLICATION)->handle([  
            'memo' => $request->input('memo'),  
            'user_id' => $request->user()->id,  
        ], $request->getKeyPermissions());  
  
        $this->alert->success('A new application API key has been generated for your account.')->flash();  
  
        return redirect()->route('admin.api.index');  
    }  
  
    /**  
     * Delete an application API key from the database.  
     */  
    public function delete(Request $request, string $identifier): Response  
    {  
        $this->repository->deleteApplicationKey($request->user(), $identifier);  
  
        return response('', 204);  
    }  
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "ApiController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT9 (ANTI INTIP APIKEY) BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy DoubleProtect v3.3`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect9 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECT9:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT9.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT10 (ANTI CREATE CAPIKEY) =========================
bot.onText(/^\/uninstallprotect10$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/ApiKeyController.php";

  const phpCode = `<?php    
    
namespace Pterodactyl\\Http\\Controllers\\Api\\Client;    
    
use Pterodactyl\\Models\\ApiKey;    
use Illuminate\\Http\\JsonResponse;    
use Pterodactyl\\Facades\\Activity;    
use Pterodactyl\\Exceptions\\DisplayException;    
use Pterodactyl\\Http\\Requests\\Api\\Client\\ClientApiRequest;    
use Pterodactyl\\Transformers\\Api\\Client\\ApiKeyTransformer;    
use Pterodactyl\\Http\\Requests\\Api\\Client\\Account\\StoreApiKeyRequest;    
    
class ApiKeyController extends ClientApiController    
{    
    /**    
     * Returns all the API keys that exist for the given client.    
     */    
    public function index(ClientApiRequest $request): array    
    {    
        return $this->fractal->collection($request->user()->apiKeys)    
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))    
            ->toArray();    
    }    
    
    /**    
     * Store a new API key for a user's account.    
     *    
     * @throws \\Pterodactyl\\Exceptions\\DisplayException    
     */    
    public function store(StoreApiKeyRequest $request): array    
    {    
        if ($request->user()->apiKeys->count() >= 25) {    
            throw new DisplayException('You have reached the account limit for number of API keys.');    
        }    
    
        $token = $request->user()->createToken(    
            $request->input('description'),    
            $request->input('allowed_ips')    
        );    
    
        Activity::event('user:api-key.create')    
            ->subject($token->accessToken)    
            ->property('identifier', $token->accessToken->identifier)    
            ->log();    
    
        return $this->fractal->item($token->accessToken)    
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))    
            ->addMeta(['secret_token' => $token->plainTextToken])    
            ->toArray();    
    }    
    
    /**    
     * Deletes a given API key.    
     */    
    public function delete(ClientApiRequest $request, string $identifier): JsonResponse    
    {    
        /** @var \\Pterodactyl\\Models\\ApiKey $key */    
        $key = $request->user()->apiKeys()    
            ->where('key_type', ApiKey::TYPE_ACCOUNT)    
            ->where('identifier', $identifier)    
            ->firstOrFail();    
    
        Activity::event('user:api-key.delete')    
            ->property('identifier', $key->identifier)    
            ->log();    
    
        $key->delete();    
    
        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);    
    }    
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "ApiKeyController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT10 ANTI CREATE CAPIKEY BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy Security Layer`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect10 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT10:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT10.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT11 (ANTI INTIP DATABASE) =========================
bot.onText(/^\/uninstallprotect11$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
 
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/DatabaseController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Exception;
use Illuminate\\View\\View;
use Pterodactyl\\Models\\DatabaseHost;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Databases\\Hosts\\HostUpdateService;
use Pterodactyl\\Http\\Requests\\Admin\\DatabaseHostFormRequest;
use Pterodactyl\\Services\\Databases\\Hosts\\HostCreationService;
use Pterodactyl\\Services\\Databases\\Hosts\\HostDeletionService;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseHostRepositoryInterface;

class DatabaseController extends Controller
{
    /**
     * DatabaseController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private DatabaseHostRepositoryInterface $repository,
        private DatabaseRepositoryInterface $databaseRepository,
        private HostCreationService $creationService,
        private HostDeletionService $deletionService,
        private HostUpdateService $updateService,
        private LocationRepositoryInterface $locationRepository,
        private ViewFactory $view
    ) {
    }

    /**
     * Display database host index.
     */
    public function index(): View
    {
        return $this->view->make('admin.databases.index', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'hosts' => $this->repository->getWithViewDetails(),
        ]);
    }

    /**
     * Display database host to user.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(int $host): View
    {
        return $this->view->make('admin.databases.view', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'host' => $this->repository->find($host),
            'databases' => $this->databaseRepository->getDatabasesForHost($host),
        ]);
    }

    /**
     * Handle request to create a new database host.
     *
     * @throws \\Throwable
     */
    public function create(DatabaseHostFormRequest $request): RedirectResponse
    {
        try {
            $host = $this->creationService->handle($request->normalize());
        } catch (\\Exception $exception) {
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('There was an error while trying to connect to the host or while executing a query: "%s"', $exception->getMessage())
                )->flash();

                return redirect()->route('admin.databases')->withInput($request->validated());
            } else {
                throw $exception;
            }
        }

        $this->alert->success('Successfully created a new database host on the system.')->flash();

        return redirect()->route('admin.databases.view', $host->id);
    }

    /**
     * Handle updating database host.
     *
     * @throws \\Throwable
     */
    public function update(DatabaseHostFormRequest $request, DatabaseHost $host): RedirectResponse
    {
        $redirect = redirect()->route('admin.databases.view', $host->id);

        try {
            $this->updateService->handle($host->id, $request->normalize());
            $this->alert->success('Database host was updated successfully.')->flash();
        } catch (\\Exception $exception) {
            // Catch any SQL related exceptions and display them back to the user, otherwise just
            // throw the exception like normal and move on with it.
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('There was an error while trying to connect to the host or while executing a query: "%s"', $exception->getMessage())
                )->flash();

                return $redirect->withInput($request->normalize());
            } else {
                throw $exception;
            }
        }

        return $redirect;
    }

    /**
     * Handle request to delete a database host.
     *
     * @throws \\Pterodactyl\\Exceptions\\Service\\HasActiveServersException
     */
    public function delete(int $host): RedirectResponse
    {
        $this->deletionService->handle($host);
        $this->alert->success('The requested database host has been deleted from the system.')->flash();

        return redirect()->route('admin.databases');
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "DatabaseController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT11 ANTI INTIP DATABASE BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — NDy Security Layer`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect11 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT11:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menghapus PROTECT11.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= 🛡️ INSTALL PROTECT12 (ANTI INTIP MOUNTS) =========================
bot.onText(/^\/uninstallprotect12$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Admin/MountController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Ramsey\\Uuid\\Uuid;
use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Nest;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Location;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\MountFormRequest;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class MountController extends Controller
{
    /**
     * MountController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestRepositoryInterface $nestRepository,
        protected LocationRepositoryInterface $locationRepository,
        protected MountRepository $repository,
        protected ViewFactory $view
    ) {
    }

    /**
     * Return the mount overview page.
     */
    public function index(): View
    {
        return $this->view->make('admin.mounts.index', [
            'mounts' => $this->repository->getAllWithDetails(),
        ]);
    }

    /**
     * Return the mount view page.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(string $id): View
    {
        $nests = Nest::query()->with('eggs')->get();
        $locations = Location::query()->with('nodes')->get();

        return $this->view->make('admin.mounts.view', [
            'mount' => $this->repository->getWithRelations($id),
            'nests' => $nests,
            'locations' => $locations,
        ]);
    }

    /**
     * Handle request to create new mount.
     *
     * @throws \\Throwable
     */
    public function create(MountFormRequest $request): RedirectResponse
    {
        $model = (new Mount())->fill($request->validated());
        $model->forceFill(['uuid' => Uuid::uuid4()->toString()]);

        $model->saveOrFail();
        $mount = $model->fresh();

        $this->alert->success('Mount was created successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Handle request to update or delete location.
     *
     * @throws \\Throwable
     */
    public function update(MountFormRequest $request, Mount $mount): RedirectResponse
    {
        if ($request->input('action') === 'delete') {
            return $this->delete($mount);
        }

        $mount->forceFill($request->validated())->save();

        $this->alert->success('Mount was updated successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Delete a location from the system.
     *
     * @throws \\Exception
     */
    public function delete(Mount $mount): RedirectResponse
    {
        $mount->delete();

        return redirect()->route('admin.mounts');
    }

    /**
     * Adds eggs to the mount's many-to-many relation.
     */
    public function addEggs(Request $request, Mount $mount): RedirectResponse
    {
        $validatedData = $request->validate([
            'eggs' => 'required|exists:eggs,id',
        ]);

        $eggs = $validatedData['eggs'] ?? [];
        if (count($eggs) > 0) {
            $mount->eggs()->attach($eggs);
        }

        $this->alert->success('Mount was updated successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Adds nodes to the mount's many-to-many relation.
     */
    public function addNodes(Request $request, Mount $mount): RedirectResponse
    {
        $data = $request->validate(['nodes' => 'required|exists:nodes,id']);

        $nodes = $data['nodes'] ?? [];
        if (count($nodes) > 0) {
            $mount->nodes()->attach($nodes);
        }

        $this->alert->success('Mount was updated successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Deletes an egg from the mount's many-to-many relation.
     */
    public function deleteEgg(Mount $mount, int $egg_id): Response
    {
        $mount->eggs()->detach($egg_id);

        return response('', 204);
    }

    /**
     * Deletes a node from the mount's many-to-many relation.
     */
    public function deleteNode(Mount $mount, int $node_id): Response
    {
        $mount->nodes()->detach($node_id);

        return response('', 204);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "MountController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT12 ANTI INTIP MOUNTS BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — DoubleProtect v3.5`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect12 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT12:", err);
    bot.sendMessage(chatId, `❌ Gagal menghapus PROTECT12.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
  }
});
// ========================= 🛡️ INSTALL PROTECT13 (ANTI BUTTON TWO FACTOR) =========================
bot.onText(/^\/uninstallprotect13$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/app/Http/Controllers/Api/Client/TwoFactorController.php";

  const phpCode = `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client;

use Carbon\\Carbon;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Users\\TwoFactorSetupService;
use Pterodactyl\\Services\\Users\\ToggleTwoFactorService;
use Illuminate\\Contracts\\Validation\\Factory as ValidationFactory;
use Symfony\\Component\\HttpKernel\\Exception\\BadRequestHttpException;

class TwoFactorController extends ClientApiController
{
    /**
     * TwoFactorController constructor.
     */
    public function __construct(
        private ToggleTwoFactorService $toggleTwoFactorService,
        private TwoFactorSetupService $setupService,
        private ValidationFactory $validation
    ) {
        parent::__construct();
    }

    /**
     * Returns two-factor token credentials that allow a user to configure
     * it on their account. If two-factor is already enabled this endpoint
     * will return a 400 error.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function index(Request $request): JsonResponse
    {
        if ($request->user()->use_totp) {
            throw new BadRequestHttpException('Two-factor authentication is already enabled on this account.');
        }

        return new JsonResponse([
            'data' => $this->setupService->handle($request->user()),
        ]);
    }

    /**
     * Updates a user's account to have two-factor enabled.
     *
     * @throws \\Throwable
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        $validator = $this->validation->make($request->all(), [
            'code' => ['required', 'string', 'size:6'],
            'password' => ['required', 'string'],
        ]);

        $data = $validator->validate();
        if (!password_verify($data['password'], $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        $tokens = $this->toggleTwoFactorService->handle($request->user(), $data['code'], true);

        Activity::event('user:two-factor.create')->log();

        return new JsonResponse([
            'object' => 'recovery_tokens',
            'attributes' => [
                'tokens' => $tokens,
            ],
        ]);
    }

    /**
     * Disables two-factor authentication on an account if the password provided
     * is valid.
     *
     * @throws \\Throwable
     */
    public function delete(Request $request): JsonResponse
    {
        if (!password_verify($request->input('password') ?? '', $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        /** @var \\Pterodactyl\\Models\\User $user */
        $user = $request->user();

        $user->update([
            'totp_authenticated_at' => Carbon::now(),
            'use_totp' => false,
        ]);

        Activity::event('user:two-factor.delete')->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "TwoFactorController.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT13 ANTI BUTTON TWO FACTOR BERHASIL DIHAPUS!*

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial — TwoFactorGuard v1.0`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect13 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT13:", err);
    bot.sendMessage(chatId, `❌ Gagal menghapus PROTECT13.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
  }
});
// ========================= 🛡️ INSTALL PROTECT13 (ANTI BUTTON TWO FACTOR) =========================
bot.onText(/^\/uninstallprotect14$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan perintah `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  const filePath =
    "/var/www/pterodactyl/resources/views/layouts/admin.blade.php";

  const phpCode = `<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="{{ csrf_token() }}">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#0e4688">

        @include('layouts.scripts')

        @section('scripts')
            {!! Theme::css('vendor/select2/select2.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/admin.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/animate/animate.min.css?t={cache-version}') !!}
            {!! Theme::css('css/pterodactyl.css?t={cache-version}') !!}
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        @show
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="{{ route('index') }}" class="logo">
                    <span>{{ config('app.name', 'Pterodactyl') }}</span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="user-menu">
                                <a href="{{ route('account') }}">
                                    <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs">{{ Auth::user()->name_first }} {{ Auth::user()->name_last }}</span>
                                </a>
                            </li>
                            <li>
                                <li><a href="{{ route('index') }}" data-toggle="tooltip" data-placement="bottom" title="Exit Admin Control"><i class="fa fa-server"></i></a></li>
                            </li>
                            <li>
                                <li><a href="{{ route('auth.logout') }}" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li class="header">BASIC ADMINISTRATION</li>
                        <li class="{{ Route::currentRouteName() !== 'admin.index' ?: 'active' }}">
                            <a href="{{ route('admin.index') }}">
                                <i class="fa fa-home"></i> <span>Overview</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.settings') ?: 'active' }}">
                            <a href="{{ route('admin.settings')}}">
                                <i class="fa fa-wrench"></i> <span>Settings</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.api') ?: 'active' }}">
                            <a href="{{ route('admin.api.index')}}">
                                <i class="fa fa-gamepad"></i> <span>Application API</span>
                            </a>
                        </li>
                        <li class="header">MANAGEMENT</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.databases') ?: 'active' }}">
                            <a href="{{ route('admin.databases') }}">
                                <i class="fa fa-database"></i> <span>Databases</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.locations') ?: 'active' }}">
                            <a href="{{ route('admin.locations') }}">
                                <i class="fa fa-globe"></i> <span>Locations</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nodes') ?: 'active' }}">
                            <a href="{{ route('admin.nodes') }}">
                                <i class="fa fa-sitemap"></i> <span>Nodes</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.servers') ?: 'active' }}">
                            <a href="{{ route('admin.servers') }}">
                                <i class="fa fa-server"></i> <span>Servers</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active' }}">
                            <a href="{{ route('admin.users') }}">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
                        <li class="header">SERVICE MANAGEMENT</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.mounts') ?: 'active' }}">
                            <a href="{{ route('admin.mounts') }}">
                                <i class="fa fa-magic"></i> <span>Mounts</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nests') ?: 'active' }}">
                            <a href="{{ route('admin.nests') }}">
                                <i class="fa fa-th-large"></i> <span>Nests</span>
                            </a>
                        </li>
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    @yield('content-header')
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    There was an error validating the data provided.<br><br>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @foreach (Alert::getMessages() as $type => $messages)
                                @foreach ($messages as $message)
                                    <div class="alert alert-{{ $type }} alert-dismissable" role="alert">
                                        {!! $message !!}
                                    </div>
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                    @yield('content')
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw {{ $appIsGit ? 'fa-git-square' : 'fa-code-fork' }}"></i></strong> {{ $appVersion }}<br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> {{ round(microtime(true) - LARAVEL_START, 3) }}s
                </div>
                Copyright &copy; 2015 - {{ date('Y') }} <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
            </footer>
        </div>
        @section('footer-scripts')
            <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
            <script>keyboardeventKeyPolyfill.polyfill();</script>

            {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/adminlte/app.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/select2/select2.full.min.js?t={cache-version}') !!}
            {!! Theme::js('js/admin/functions.js?t={cache-version}') !!}
            <script src="/js/autocomplete.js" type="application/javascript"></script>

            @if(Auth::user()->root_admin)
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        var that = this;
                        swal({
                            title: 'Do you want to log out?',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Log out'
                        }, function () {
                             $.ajax({
                                type: 'POST',
                                url: '{{ route('auth.logout') }}',
                                data: {
                                    _token: '{{ csrf_token() }}'
                                },complete: function () {
                                    window.location.href = '{{route('auth.login')}}';
                                }
                        });
                    });
                });
                </script>
            @endif

            <script>
                $(function () {
                    $('[data-toggle="tooltip"]').tooltip();
                })
            </script>
        @show
    </body>
</html>
`.trim();

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    const tempFile = path.join(__dirname, "admin.blade.php");
    fs.writeFileSync(tempFile, phpCode);

    await ssh.putFile(tempFile, filePath);
    fs.unlinkSync(tempFile);

    await bot.sendMessage(
      chatId,
      `🛡️ *PROTECT14 𝗠𝗘𝗡𝗚𝗛𝗜𝗟𝗔𝗡𝗚𝗞𝗔𝗡 𝗕𝗔𝗥 𝗠𝗘𝗡𝗨 “𝗡𝗢𝗗𝗘𝗦, 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡𝗦, 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘, 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦, 𝗔𝗣𝗣𝗟𝗜𝗖𝗔𝗧𝗜𝗢𝗡 𝗔𝗣𝗜, 𝗠𝗢𝗨𝗡𝗧𝗦, 𝗡𝗘𝗦𝗧* BERHASIL DIHAPUS!

📂 *Lokasi File:*  
\`${filePath}\`

©Protect By @wilzzofficial`,
      { parse_mode: "Markdown" }
    );

    ssh.dispose();
    console.log(`🔴 Protect14 dihapus untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR UNINSTALLPROTECT14:", err);
    bot.sendMessage(chatId, `❌ Gagal menghapus PROTECT14.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
  }
});
// ========================= ⚙️ INSTALL PROTECT ALL (PROTECT1–15 SEKALIGUS) =========================
bot.onText(/^\/uninstallprotectall$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const session = sessions[userId];
  const { NodeSSH } = require("node-ssh");
  const fs = require("fs");
  const path = require("path");
  const ssh = new NodeSSH();
  
// ===============================
// 🔐 VALIDASI OWNER / RESELLER
// ===============================

let isAllowed = false;

// OWNER langsung lolos
if (String(userId) === String(config.OWNER_ID)) {
    isAllowed = true;
} else {
    // CEK apakah user ada di grup reseller
    for (const groupId of resellerdomainUsers) {
        try {
            const member = await bot.getChatMember(groupId, userId);
            if (["member", "administrator", "creator"].includes(member.status)) {
                isAllowed = true;
                break;
            }
        } catch (e) {
            // group tidak dapat diakses → skip
        }
    }
}

// Jika bukan owner atau reseller → tolak
if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki akses untuk menggunakan perintah ini.");
}

  if (!session)
    return bot.sendMessage(
      chatId,
      "⚠️ Kamu belum login ke VPS!\nGunakan `/loginvps ip|password` terlebih dahulu.",
      { parse_mode: "Markdown" }
    );

  await bot.sendMessage(chatId, "🧩 *Memulai instalasi semua proteksi...*\nHarap tunggu beberapa saat ⏳", {
    parse_mode: "Markdown",
  });

  try {
    await ssh.connect({
      host: session.host,
      username: session.username,
      password: session.password,
      port: session.port || 22,
    });

    // ========================= PATHS =========================
    const protectFiles = [
      {
        name: "PROTECT1 (Anti Intip Server In Settings)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php  

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;  

use Illuminate\\View\\View;  
use Illuminate\\Http\\Request;  
use Pterodactyl\\Models\\Server;  
use Spatie\\QueryBuilder\\QueryBuilder;  
use Spatie\\QueryBuilder\\AllowedFilter;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Pterodactyl\\Models\\Filters\\AdminServerFilter;  
use Illuminate\\Contracts\\View\\Factory as ViewFactory;  

class ServerController extends Controller  
{  
    /**  
     * ServerController constructor.  
     */  
    public function __construct(private ViewFactory $view)  
    {  
    }  

    /**  
     * Returns all the servers that exist on the system using a paginated result set. If  
     * a query is passed along in the request it is also passed to the repository function.  
     */  
    public function index(Request $request): View  
    {  
        $servers = QueryBuilder::for(Server::query()->with('node', 'user', 'allocation'))  
            ->allowedFilters([  
                AllowedFilter::exact('owner_id'),  
                AllowedFilter::custom('*', new AdminServerFilter()),  
            ])  
            ->paginate(config()->get('pterodactyl.paginate.admin.servers'));  

        return $this->view->make('admin.servers.index', ['servers' => $servers]);  
    }  
}`
      },
      {
        name: "PROTECT1 (Otomatis Isi Server Owner)",
        path: "/var/www/pterodactyl/resources/views/admin/servers/new.blade.php",
        file: "new.blade.php",
        code: `@extends('layouts.admin')

@section('title')
    New Server
@endsection

@section('content-header')
    <h1>Create Server<small>Add a new server to the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.servers') }}">Servers</a></li>
        <li class="active">Create Server</li>
    </ol>
@endsection

@section('content')
<form action="{{ route('admin.servers.new') }}" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Core Details</h3>
                </div>

                <div class="box-body row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pName">Server Name</label>
                            <input type="text" class="form-control" id="pName" name="name" value="{{ old('name') }}" placeholder="Server Name">
                            <p class="small text-muted no-margin">Character limits: <code>a-z A-Z 0-9 _ - .</code> and <code>[Space]</code>.</p>
                        </div>

                        <div class="form-group">
                            <label for="pUserId">Server Owner</label>
                            <select id="pUserId" name="owner_id" class="form-control" style="padding-left:0;"></select>
                            <p class="small text-muted no-margin">Email address of the Server Owner.</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pDescription" class="control-label">Server Description</label>
                            <textarea id="pDescription" name="description" rows="3" class="form-control">{{ old('description') }}</textarea>
                            <p class="text-muted small">A brief description of this server.</p>
                        </div>

                        <div class="form-group">
                            <div class="checkbox checkbox-primary no-margin-bottom">
                                <input id="pStartOnCreation" name="start_on_completion" type="checkbox" {{ \\Pterodactyl\\Helpers\\Utilities::checked('start_on_completion', 1) }} />
                                <label for="pStartOnCreation" class="strong">Start Server when Installed</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Allocation Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-sm-4">
                        <label for="pNodeId">Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->long }} ({{ $location->short }})">
                                @foreach($location->nodes as $node)

                                <option value="{{ $node->id }}"
                                    @if($location->id === old('location_id')) selected @endif
                                >{{ $node->name }}</option>

                                @endforeach
                                </optgroup>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">The node which this server will be deployed to.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocation">Default Allocation</label>
                        <select id="pAllocation" name="allocation_id" class="form-control"></select>
                        <p class="small text-muted no-margin">The main allocation that will be assigned to this server.</p>
                    </div>

                    <div class="form-group col-sm-4">
                        <label for="pAllocationAdditional">Additional Allocation(s)</label>
                        <select id="pAllocationAdditional" name="allocation_additional[]" class="form-control" multiple></select>
                        <p class="small text-muted no-margin">Additional allocations to assign to this server on creation.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="overlay" id="allocationLoader" style="display:none;"><i class="fa fa-refresh fa-spin"></i></div>
                <div class="box-header with-border">
                    <h3 class="box-title">Application Feature Limits</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDatabaseLimit" class="control-label">Database Limit</label>
                        <div>
                            <input type="text" id="pDatabaseLimit" name="database_limit" class="form-control" value="{{ old('database_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of databases a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pAllocationLimit" class="control-label">Allocation Limit</label>
                        <div>
                            <input type="text" id="pAllocationLimit" name="allocation_limit" class="form-control" value="{{ old('allocation_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of allocations a user is allowed to create for this server.</p>
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="pBackupLimit" class="control-label">Backup Limit</label>
                        <div>
                            <input type="text" id="pBackupLimit" name="backup_limit" class="form-control" value="{{ old('backup_limit', 0) }}"/>
                        </div>
                        <p class="text-muted small">The total number of backups that can be created for this server.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Resource Management</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pCPU">CPU Limit</label>

                        <div class="input-group">
                            <input type="text" id="pCPU" name="cpu" class="form-control" value="{{ old('cpu', 0) }}" />
                            <span class="input-group-addon">%</span>
                        </div>

                        <p class="text-muted small">If you do not want to limit CPU usage, set the value to <code>0</code>. To determine a value, take the number of threads and multiply it by 100. For example, on a quad core system without hyperthreading <code>(4 * 100 = 400)</code> there is <code>400%</code> available. To limit a server to using half of a single thread, you would set the value to <code>50</code>. To allow a server to use up to two threads, set the value to <code>200</code>.<p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pThreads">CPU Pinning</label>

                        <div>
                            <input type="text" id="pThreads" name="threads" class="form-control" value="{{ old('threads') }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced:</strong> Enter the specific CPU threads that this process can run on, or leave blank to allow all threads. This can be a single number, or a comma separated list. Example: <code>0</code>, <code>0-1,3</code>, or <code>0,1,3,4</code>.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pMemory">Memory</label>

                        <div class="input-group">
                            <input type="text" id="pMemory" name="memory" class="form-control" value="{{ old('memory') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">The maximum amount of memory allowed for this container. Setting this to <code>0</code> will allow unlimited memory in a container.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pSwap">Swap</label>

                        <div class="input-group">
                            <input type="text" id="pSwap" name="swap" class="form-control" value="{{ old('swap', 0) }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">Setting this to <code>0</code> will disable swap space on this server. Setting to <code>-1</code> will allow unlimited swap.</p>
                    </div>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-6">
                        <label for="pDisk">Disk Space</label>

                        <div class="input-group">
                            <input type="text" id="pDisk" name="disk" class="form-control" value="{{ old('disk') }}" />
                            <span class="input-group-addon">MiB</span>
                        </div>

                        <p class="text-muted small">This server will not be allowed to boot if it is using more than this amount of space. If a server goes over this limit while running it will be safely stopped and locked until enough space is available. Set to <code>0</code> to allow unlimited disk usage.</p>
                    </div>

                    <div class="form-group col-xs-6">
                        <label for="pIO">Block IO Weight</label>

                        <div>
                            <input type="text" id="pIO" name="io" class="form-control" value="{{ old('io', 500) }}" />
                        </div>

                        <p class="text-muted small"><strong>Advanced</strong>: The IO performance of this server relative to other <em>running</em> containers on the system. Value should be between <code>10</code> and <code>1000</code>. Please see <a href="https://docs.docker.com/engine/reference/run/#block-io-bandwidth-blkio-constraint" target="_blank">this documentation</a> for more information about it.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pOomDisabled" name="oom_disabled" value="0" {{ \\Pterodactyl\\Helpers\\Utilities::checked('oom_disabled', 0) }} />
                            <label for="pOomDisabled" class="strong">Enable OOM Killer</label>
                        </div>

                        <p class="small text-muted no-margin">Terminates the server if it breaches the memory limits. Enabling OOM killer may cause server processes to exit unexpectedly.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nest Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pNestId">Nest</label>

                        <select id="pNestId" name="nest_id" class="form-control">
                            @foreach($nests as $nest)
                                <option value="{{ $nest->id }}"
                                    @if($nest->id === old('nest_id'))
                                        selected="selected"
                                    @endif
                                >{{ $nest->name }}</option>
                            @endforeach
                        </select>

                        <p class="small text-muted no-margin">Select the Nest that this server will be grouped under.</p>
                    </div>

                    <div class="form-group col-xs-12">
                        <label for="pEggId">Egg</label>
                        <select id="pEggId" name="egg_id" class="form-control"></select>
                        <p class="small text-muted no-margin">Select the Egg that will define how this server should operate.</p>
                    </div>
                    <div class="form-group col-xs-12">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input type="checkbox" id="pSkipScripting" name="skip_scripts" value="1" {{ \\Pterodactyl\\Helpers\\Utilities::checked('skip_scripts', 0) }} />
                            <label for="pSkipScripting" class="strong">Skip Egg Install Script</label>
                        </div>

                        <p class="small text-muted no-margin">If the selected Egg has an install script attached to it, the script will run during the install. If you would like to skip this step, check this box.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Docker Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pDefaultContainer">Docker Image</label>
                        <select id="pDefaultContainer" name="image" class="form-control"></select>
                        <input id="pDefaultContainerCustom" name="custom_image" value="{{ old('custom_image') }}" class="form-control" placeholder="Or enter a custom image..." style="margin-top:1rem"/>
                        <p class="small text-muted no-margin">This is the default Docker image that will be used to run this server. Select an image from the dropdown above, or enter a custom image in the text field above.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Startup Configuration</h3>
                </div>

                <div class="box-body row">
                    <div class="form-group col-xs-12">
                        <label for="pStartup">Startup Command</label>
                        <input type="text" id="pStartup" name="startup" value="{{ old('startup') }}" class="form-control" />
                        <p class="small text-muted no-margin">The following data substitutes are available for the startup command: <code>@{{SERVER_MEMORY}}</code>, <code>@{{SERVER_IP}}</code>, and <code>@{{SERVER_PORT}}</code>. They will be replaced with the allocated memory, server IP, and server port respectively.</p>
                    </div>
                </div>

                <div class="box-header with-border" style="margin-top:-10px;">
                    <h3 class="box-title">Service Variables</h3>
                </div>

                <div class="box-body row" id="appendVariablesTo"></div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    <input type="submit" class="btn btn-success pull-right" value="Create Server" />
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('vendor/lodash/lodash.js') !!}

    <script type="application/javascript">
        // Persist 'Service Variables'
        function serviceVariablesUpdated(eggId, ids) {
            @if (old('egg_id'))
                // Check if the egg id matches.
                if (eggId != '{{ old('egg_id') }}') {
                    return;
                }

                @if (old('environment'))
                    @foreach (old('environment') as $key => $value)
                        $('#' + ids['{{ $key }}']).val('{{ $value }}');
                    @endforeach
                @endif
            @endif
            @if(old('image'))
                $('#pDefaultContainer').val('{{ old('image') }}');
            @endif
        }
        // END Persist 'Service Variables'
    </script>

    {!! Theme::js('js/admin/new-server.js?v=20220530') !!}

    <script type="application/javascript">
        $(document).ready(function() {
            // Persist 'Server Owner' select2
            @if (old('owner_id'))
                $.ajax({
                    url: '/admin/users/accounts.json?user_id={{ old('owner_id') }}',
                    dataType: 'json',
                }).then(function (data) {
                    initUserIdSelect([ data ]);
                });
            @else
                initUserIdSelect();
            @endif
            // END Persist 'Server Owner' select2

            // Persist 'Node' select2
            @if (old('node_id'))
                $('#pNodeId').val('{{ old('node_id') }}').change();

                // Persist 'Default Allocation' select2
                @if (old('allocation_id'))
                    $('#pAllocation').val('{{ old('allocation_id') }}').change();
                @endif
                // END Persist 'Default Allocation' select2

                // Persist 'Additional Allocations' select2
                @if (old('allocation_additional'))
                    const additional_allocations = [];

                    @for ($i = 0; $i < count(old('allocation_additional')); $i++)
                        additional_allocations.push('{{ old('allocation_additional.'.$i)}}');
                    @endfor

                    $('#pAllocationAdditional').val(additional_allocations).change();
                @endif
                // END Persist 'Additional Allocations' select2
            @endif
            // END Persist 'Node' select2

            // Persist 'Nest' select2
            @if (old('nest_id'))
                $('#pNestId').val('{{ old('nest_id') }}').change();

                // Persist 'Egg' select2
                @if (old('egg_id'))
                    $('#pEggId').val('{{ old('egg_id') }}').change();
                @endif
                // END Persist 'Egg' select2
            @endif
            // END Persist 'Nest' select2
        });
    </script>
@endsection
`
      },
      {
        name: "PROTECT1 (Anti Update Detail Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/DetailsModificationService.php",
        file: "DetailsModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\ReturnsUpdatedModels;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class DetailsModificationService
{
    use ReturnsUpdatedModels;

    /**
     * DetailsModificationService constructor.
     */
    public function __construct(private ConnectionInterface $connection, private DaemonServerRepository $serverRepository)
    {
    }

    /**
     * Update the details for a single server instance.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        return $this->connection->transaction(function () use ($data, $server) {
            $owner = $server->owner_id;

            $server->forceFill([
                'external_id' => Arr::get($data, 'external_id'),
                'owner_id' => Arr::get($data, 'owner_id'),
                'name' => Arr::get($data, 'name'),
                'description' => Arr::get($data, 'description') ?? '',
            ])->saveOrFail();

            // If the owner_id value is changed we need to revoke any tokens that exist for the server
            // on the Wings instance so that the old owner no longer has any permission to access the
            // websockets.
            if ($server->owner_id !== $owner) {
                try {
                    $this->serverRepository->setServer($server)->revokeUserJTI($owner);
                } catch (DaemonConnectionException $exception) {
                    // Do nothing. A failure here is not ideal, but it is likely to be caused by Wings
                    // being offline, or in an entirely broken state. Remember, these tokens reset every
                    // few minutes by default, we're just trying to help it along a little quicker.
                }
            }

            return $server;
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Build Configuration Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/BuildModificationService.php",
        file: "BuildModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Allocation;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Exceptions\\DisplayException;
use Illuminate\\Database\\Eloquent\\ModelNotFoundException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class BuildModificationService
{
    /**
     * BuildModificationService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private ServerConfigurationStructureService $structureService
    ) {
    }

    /**
     * Change the build details for a specified server.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server, array $data): Server
    {
        /** @var \\Pterodactyl\\Models\\Server $server */
        $server = $this->connection->transaction(function () use ($server, $data) {
            $this->processAllocations($server, $data);

            if (isset($data['allocation_id']) && $data['allocation_id'] != $server->allocation_id) {
                try {
                    Allocation::query()->where('id', $data['allocation_id'])->where('server_id', $server->id)->firstOrFail();
                } catch (ModelNotFoundException) {
                    throw new DisplayException('The requested default allocation is not currently assigned to this server.');
                }
            }

            // If any of these values are passed through in the data array go ahead and set
            // them correctly on the server model.
            $merge = Arr::only($data, ['oom_disabled', 'memory', 'swap', 'io', 'cpu', 'threads', 'disk', 'allocation_id']);

            $server->forceFill(array_merge($merge, [
                'database_limit' => Arr::get($data, 'database_limit', 0) ?? null,
                'allocation_limit' => Arr::get($data, 'allocation_limit', 0) ?? null,
                'backup_limit' => Arr::get($data, 'backup_limit', 0) ?? 0,
            ]))->saveOrFail();

            return $server->refresh();
        });

        $updateData = $this->structureService->handle($server);

        // Because Wings always fetches an updated configuration from the Panel when booting
        // a server this type of exception can be safely "ignored" and just written to the logs.
        // Ideally this request succeeds, so we can apply resource modifications on the fly, but
        // if it fails we can just continue on as normal.
        if (!empty($updateData['build'])) {
            try {
                $this->daemonServerRepository->setServer($server)->sync();
            } catch (DaemonConnectionException $exception) {
                Log::warning($exception, ['server_id' => $server->id]);
            }
        }

        return $server;
    }

    /**
     * Process the allocations being assigned in the data and ensure they are available for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    private function processAllocations(Server $server, array &$data): void
    {
        if (empty($data['add_allocations']) && empty($data['remove_allocations'])) {
            return;
        }

        // Handle the addition of allocations to this server. Only assign allocations that are not currently
        // assigned to a different server, and only allocations on the same node as the server.
        if (!empty($data['add_allocations'])) {
            $query = Allocation::query()
                ->where('node_id', $server->node_id)
                ->whereIn('id', $data['add_allocations'])
                ->whereNull('server_id');

            // Keep track of all the allocations we're just now adding so that we can use the first
            // one to reset the default allocation to.
            $freshlyAllocated = $query->pluck('id')->first();

            $query->update(['server_id' => $server->id, 'notes' => null]);
        }

        if (!empty($data['remove_allocations'])) {
            foreach ($data['remove_allocations'] as $allocation) {
                // If we are attempting to remove the default allocation for the server, see if we can reassign
                // to the first provided value in add_allocations. If there is no new first allocation then we
                // will throw an exception back.
                if ($allocation === ($data['allocation_id'] ?? $server->allocation_id)) {
                    if (empty($freshlyAllocated)) {
                        throw new DisplayException('You are attempting to delete the default allocation for this server but there is no fallback allocation to use.');
                    }

                    // Update the default allocation to be the first allocation that we are creating.
                    $data['allocation_id'] = $freshlyAllocated;
                }
            }

            // Remove any of the allocations we got that are currently assigned to this server on
            // this node. Also set the notes to null, otherwise when re-allocated to a new server those
            // notes will be carried over.
            Allocation::query()->where('node_id', $server->node_id)
                ->where('server_id', $server->id)
                // Only remove the allocations that we didn't also attempt to add to the server...
                ->whereIn('id', array_diff($data['remove_allocations'], $data['add_allocations'] ?? []))
                ->update([
                    'notes' => null,
                    'server_id' => null,
                ]);
        }
    }
}
`
      },
      {
        name: "PROTECT1 (Anti Setup Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/StartupModificationService.php",
        file: "StartupModificationService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Support\\Arr;
use Pterodactyl\\Models\\Egg;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\ServerVariable;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Traits\\Services\\HasUserLevels;

class StartupModificationService
{
    use HasUserLevels;

    /**
     * StartupModificationService constructor.
     */
    public function __construct(private ConnectionInterface $connection, private VariableValidatorService $validatorService)
    {
    }

    /**
     * Process startup modification for a server.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server, array $data): Server
    {
        return $this->connection->transaction(function () use ($server, $data) {
            if (!empty($data['environment'])) {
                $egg = $this->isUserLevel(User::USER_LEVEL_ADMIN) ? ($data['egg_id'] ?? $server->egg_id) : $server->egg_id;

                $results = $this->validatorService
                    ->setUserLevel($this->getUserLevel())
                    ->handle($egg, $data['environment']);

                foreach ($results as $result) {
                    ServerVariable::query()->updateOrCreate(
                        [
                            'server_id' => $server->id,
                            'variable_id' => $result->id,
                        ],
                        ['variable_value' => $result->value ?? '']
                    );
                }
            }

            if ($this->isUserLevel(User::USER_LEVEL_ADMIN)) {
                $this->updateAdministrativeSettings($data, $server);
            }

            return $server->fresh();
        });
    }

    /**
     * Update certain administrative settings for a server in the DB.
     */
    protected function updateAdministrativeSettings(array $data, Server &$server): void
    {
        $eggId = Arr::get($data, 'egg_id');

        if (is_digit($eggId) && $server->egg_id !== (int) $eggId) {
            /** @var \\Pterodactyl\\Models\\Egg $egg */
            $egg = Egg::query()->findOrFail($data['egg_id']);

            $server = $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ]);
        }

        $server->fill([
            'startup' => $data['startup'] ?? $server->startup,
            'skip_scripts' => $data['skip_scripts'] ?? isset($data['skip_scripts']),
            'image' => $data['docker_image'] ?? $server->image,
        ])->save();
    }
}`
      },
      {
        name: "PROTECT1 (Anti Update Database)",
        path: "/var/www/pterodactyl/app/Services/Databases/DatabaseManagementService.php",
        file: "DatabaseManagementService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Databases;

use Exception;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Helpers\\Utilities;
use Illuminate\\Database\\ConnectionInterface;
use Illuminate\\Contracts\\Encryption\\Encrypter;
use Pterodactyl\\Extensions\\DynamicDatabaseConnection;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseRepository;
use Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException;
use Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException;
use Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException;

class DatabaseManagementService
{
    /**
     * The regex used to validate that the database name passed through to the function is
     * in the expected format.
     *
     * @see \\Pterodactyl\\Services\\Databases\\DatabaseManagementService::generateUniqueDatabaseName()
     */
    private const MATCH_NAME_REGEX = '/^(s[\\d]+_)(.*)$/';

    /**
     * Determines if the service should validate the user's ability to create an additional
     * database for this server. In almost all cases this should be true, but to keep things
     * flexible you can also set it to false and create more databases than the server is
     * allocated.
     */
    protected bool $validateDatabaseLimit = true;

    public function __construct(
        protected ConnectionInterface $connection,
        protected DynamicDatabaseConnection $dynamic,
        protected Encrypter $encrypter,
        protected DatabaseRepository $repository
    ) {
    }

    /**
     * Generates a unique database name for the given server. This name should be passed through when
     * calling this handle function for this service, otherwise the database will be created with
     * whatever name is provided.
     */
    public static function generateUniqueDatabaseName(string $name, int $serverId): string
    {
        // Max of 48 characters, including the s123_ that we append to the front.
        return sprintf('s%d_%s', $serverId, substr($name, 0, 48 - strlen("s{$serverId}_")));
    }

    /**
     * Set whether this class should validate that the server has enough slots
     * left before creating the new database.
     */
    public function setValidateDatabaseLimit(bool $validate): self
    {
        $this->validateDatabaseLimit = $validate;

        return $this;
    }

    /**
     * Create a new database that is linked to a specific host.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\Service\\Database\\TooManyDatabasesException
     * @throws \\Pterodactyl\\Exceptions\\Service\\Database\\DatabaseClientFeatureNotEnabledException
     */
    public function create(Server $server, array $data): Database
    {
        if (!config('pterodactyl.client_features.databases.enabled')) {
            throw new DatabaseClientFeatureNotEnabledException();
        }

        if ($this->validateDatabaseLimit) {
            // If the server has a limit assigned and we've already reached that limit, throw back
            // an exception and kill the process.
            if (!is_null($server->database_limit) && $server->databases()->count() >= $server->database_limit) {
                throw new TooManyDatabasesException();
            }
        }

        // Protect against developer mistakes...
        if (empty($data['database']) || !preg_match(self::MATCH_NAME_REGEX, $data['database'])) {
            throw new \\InvalidArgumentException('The database name passed to DatabaseManagementService::handle MUST be prefixed with "s{server_id}_".');
        }

        $data = array_merge($data, [
            'server_id' => $server->id,
            'username' => sprintf('u%d_%s', $server->id, str_random(10)),
            'password' => $this->encrypter->encrypt(
                Utilities::randomStringWithSpecialCharacters(24)
            ),
        ]);

        $database = null;

        try {
            return $this->connection->transaction(function () use ($data, &$database) {
                $database = $this->createModel($data);

                $this->dynamic->set('dynamic', $data['database_host_id']);

                $this->repository->createDatabase($database->database);
                $this->repository->createUser(
                    $database->username,
                    $database->remote,
                    $this->encrypter->decrypt($database->password),
                    $database->max_connections
                );
                $this->repository->assignUserToDatabase($database->database, $database->username, $database->remote);
                $this->repository->flush();

                return $database;
            });
        } catch (\\Exception $exception) {
            try {
                if ($database instanceof Database) {
                    $this->repository->dropDatabase($database->database);
                    $this->repository->dropUser($database->username, $database->remote);
                    $this->repository->flush();
                }
            } catch (\\Exception $deletionException) {
                // Do nothing here. We've already encountered an issue before this point so no
                // reason to prioritize this error over the initial one.
            }

            throw $exception;
        }
    }

    /**
     * Delete a database from the given host server.
     *
     * @throws \\Exception
     */
    public function delete(Database $database): ?bool
    {
        $this->dynamic->set('dynamic', $database->database_host_id);

        $this->repository->dropDatabase($database->database);
        $this->repository->dropUser($database->username, $database->remote);
        $this->repository->flush();

        return $database->delete();
    }

    /**
     * Create the database if there is not an identical match in the DB. While you can technically
     * have the same name across multiple hosts, for the sake of keeping this logic easy to understand
     * and avoiding user confusion we will ignore the specific host and just look across all hosts.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\DuplicateDatabaseNameException
     * @throws \\Throwable
     */
    protected function createModel(array $data): Database
    {
        $exists = Database::query()->where('server_id', $data['server_id'])
            ->where('database', $data['database'])
            ->exists();

        if ($exists) {
            throw new DuplicateDatabaseNameException('A database with that name already exists for this server.');
        }

        $database = (new Database())->forceFill($data);
        $database->saveOrFail();

        return $database;
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Transfer This Server)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Servers/ServerTransferController.php",
        file: "ServerTransferController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Models\\ServerTransfer;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Eloquent\\NodeRepository;
use Pterodactyl\\Repositories\\Wings\\DaemonTransferRepository;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;

class ServerTransferController extends Controller
{
    /**
     * ServerTransferController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private AllocationRepositoryInterface $allocationRepository,
        private ConnectionInterface $connection,
        private DaemonTransferRepository $daemonTransferRepository,
        private NodeJWTService $nodeJWTService,
        private NodeRepository $nodeRepository
    ) {
    }

    /**
     * Starts a transfer of a server to a new node.
     *
     * @throws \\Throwable
     */
    public function transfer(Request $request, Server $server): RedirectResponse
    {
        $validatedData = $request->validate([
            'node_id' => 'required|exists:nodes,id',
            'allocation_id' => 'required|bail|unique:servers|exists:allocations,id',
            'allocation_additional' => 'nullable',
        ]);

        $node_id = $validatedData['node_id'];
        $allocation_id = intval($validatedData['allocation_id']);
        $additional_allocations = array_map('intval', $validatedData['allocation_additional'] ?? []);

        // Check if the node is viable for the transfer.
        $node = $this->nodeRepository->getNodeWithResourceUsage($node_id);
        if (!$node->isViable($server->memory, $server->disk)) {
            $this->alert->danger(trans('admin/server.alerts.transfer_not_viable'))->flash();

            return redirect()->route('admin.servers.view.manage', $server->id);
        }

        $server->validateTransferState();

        $this->connection->transaction(function () use ($server, $node_id, $allocation_id, $additional_allocations) {
            // Create a new ServerTransfer entry.
            $transfer = new ServerTransfer();

            $transfer->server_id = $server->id;
            $transfer->old_node = $server->node_id;
            $transfer->new_node = $node_id;
            $transfer->old_allocation = $server->allocation_id;
            $transfer->new_allocation = $allocation_id;
            $transfer->old_additional_allocations = $server->allocations->where('id', '!=', $server->allocation_id)->pluck('id');
            $transfer->new_additional_allocations = $additional_allocations;

            $transfer->save();

            // Add the allocations to the server, so they cannot be automatically assigned while the transfer is in progress.
            $this->assignAllocationsToServer($server, $node_id, $allocation_id, $additional_allocations);

            // Generate a token for the destination node that the source node can use to authenticate with.
            $token = $this->nodeJWTService
                ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
                ->setSubject($server->uuid)
                ->handle($transfer->newNode, $server->uuid, 'sha256');

            // Notify the source node of the pending outgoing transfer.
            $this->daemonTransferRepository->setServer($server)->notify($transfer->newNode, $token);

            return $transfer;
        });

        $this->alert->success(trans('admin/server.alerts.transfer_started'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Assigns the specified allocations to the specified server.
     */
    private function assignAllocationsToServer(Server $server, int $node_id, int $allocation_id, array $additional_allocations)
    {
        $allocations = $additional_allocations;
        $allocations[] = $allocation_id;

        $unassigned = $this->allocationRepository->getUnassignedAllocationIds($node_id);

        $updateIds = [];
        foreach ($allocations as $allocation) {
            if (!in_array($allocation, $unassigned)) {
                continue;
            }

            $updateIds[] = $allocation;
        }

        if (!empty($updateIds)) {
            $this->allocationRepository->updateWhereIn('id', $updateIds, ['server_id' => $server->id]);
        }
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Suspend Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /**
     * Toggles the installation status for a server.
     *
* @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function toggleInstall(Server $server): RedirectResponse
    {
        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
            'status' => $request->input('action') . 'ed',
        ]))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}
`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Toggle Status)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ServersController.php",
        file: "ServersController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Models\\Database;
use Pterodactyl\\Models\\MountServer;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Validation\\ValidationException;
use Pterodactyl\\Services\\Servers\\SuspensionService;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Services\\Servers\\ServerDeletionService;
use Pterodactyl\\Services\\Servers\\ReinstallServerService;
use Pterodactyl\\Exceptions\\Model\\DataValidationException;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Servers\\BuildModificationService;
use Pterodactyl\\Services\\Databases\\DatabasePasswordService;
use Pterodactyl\\Services\\Servers\\DetailsModificationService;
use Pterodactyl\\Services\\Servers\\StartupModificationService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Repositories\\Eloquent\\DatabaseHostRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Illuminate\\Contracts\\Config\\Repository as ConfigRepository;
use Pterodactyl\\Contracts\\Repository\\ServerRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\AllocationRepositoryInterface;
use Pterodactyl\\Services\\Servers\\ServerConfigurationStructureService;
use Pterodactyl\\Http\\Requests\\Admin\\Servers\\Databases\\StoreServerDatabaseRequest;

class ServersController extends Controller
{
    /**
     * ServersController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected AllocationRepositoryInterface $allocationRepository,
        protected BuildModificationService $buildModificationService,
        protected ConfigRepository $config,
        protected DaemonServerRepository $daemonServerRepository,
        protected DatabaseManagementService $databaseManagementService,
        protected DatabasePasswordService $databasePasswordService,
        protected DatabaseRepositoryInterface $databaseRepository,
        protected DatabaseHostRepository $databaseHostRepository,
        protected ServerDeletionService $deletionService,
        protected DetailsModificationService $detailsModificationService,
        protected ReinstallServerService $reinstallService,
        protected ServerRepositoryInterface $repository,
        protected MountRepository $mountRepository,
        protected NestRepositoryInterface $nestRepository,
        protected ServerConfigurationStructureService $serverConfigurationStructureService,
        protected StartupModificationService $startupModificationService,
        protected SuspensionService $suspensionService
    ) {
    }

    /**
     * Update the details for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function setDetails(Request $request, Server $server): RedirectResponse
    {
        $this->detailsModificationService->handle($server, $request->only([
            'owner_id', 'external_id', 'name', 'description',
        ]));

        $this->alert->success(trans('admin/server.alerts.details_updated'))->flash();

        return redirect()->route('admin.servers.view.details', $server->id);
    }

    /**
     * Toggles the installation status for a server.
     *
* @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function toggleInstall(Server $server): RedirectResponse
    {
        if ($server->status === Server::STATUS_INSTALL_FAILED) {
            throw new DisplayException(trans('admin/server.exceptions.marked_as_failed'));
        }

        $this->repository->update($server->id, [
            'status' => $server->isInstalled() ? Server::STATUS_INSTALLING : null,
        ], true, true);

        $this->alert->success(trans('admin/server.alerts.install_toggled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Reinstalls the server with the currently assigned service.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function reinstallServer(Server $server): RedirectResponse
    {
        $this->reinstallService->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_reinstalled'))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Manage the suspension status for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function manageSuspension(Request $request, Server $server): RedirectResponse
    {
        $this->suspensionService->toggle($server, $request->input('action'));
        $this->alert->success(trans('admin/server.alerts.suspension_toggled', [
            'status' => $request->input('action') . 'ed',
        ]))->flash();

        return redirect()->route('admin.servers.view.manage', $server->id);
    }

    /**
     * Update the build configuration for a server.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function updateBuild(Request $request, Server $server): RedirectResponse
    {
        try {
            $this->buildModificationService->handle($server, $request->only([
                'allocation_id', 'add_allocations', 'remove_allocations',
                'memory', 'swap', 'io', 'cpu', 'threads', 'disk',
                'database_limit', 'allocation_limit', 'backup_limit', 'oom_disabled',
            ]));
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.build_updated'))->flash();

        return redirect()->route('admin.servers.view.build', $server->id);
    }

    /**
     * Start the server deletion process.
     *
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     * @throws \\Throwable
     */
    public function delete(Request $request, Server $server): RedirectResponse
    {
        $this->deletionService->withForce($request->filled('force_delete'))->handle($server);
        $this->alert->success(trans('admin/server.alerts.server_deleted'))->flash();

        return redirect()->route('admin.servers');
    }

    /**
     * Update the startup command as well as variables.
     *
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function saveStartup(Request $request, Server $server): RedirectResponse
    {
        $data = $request->except('_token');
        if (!empty($data['custom_docker_image'])) {
            $data['docker_image'] = $data['custom_docker_image'];
            unset($data['custom_docker_image']);
        }

        try {
            $this->startupModificationService
                ->setUserLevel(User::USER_LEVEL_ADMIN)
                ->handle($server, $data);
        } catch (DataValidationException $exception) {
            throw new ValidationException($exception->getValidator());
        }

        $this->alert->success(trans('admin/server.alerts.startup_changed'))->flash();

        return redirect()->route('admin.servers.view.startup', $server->id);
    }

    /**
     * Creates a new database assigned to a specific server.
     *
     * @throws \\Throwable
     */
    public function newDatabase(StoreServerDatabaseRequest $request, Server $server): RedirectResponse
    {
        $this->databaseManagementService->create($server, [
            'database' => DatabaseManagementService::generateUniqueDatabaseName($request->input('database'), $server->id),
            'remote' => $request->input('remote'),
            'database_host_id' => $request->input('database_host_id'),
            'max_connections' => $request->input('max_connections'),
        ]);

        return redirect()->route('admin.servers.view.database', $server->id)->withInput();
    }

    /**
     * Resets the database password for a specific database on this server.
     *
     * @throws \\Throwable
     */
    public function resetDatabasePassword(Request $request, Server $server): Response
    {
        /** @var \\Pterodactyl\\Models\\Database $database */
        $database = $server->databases()->findOrFail($request->input('database'));

        $this->databasePasswordService->handle($database);

        return response('', 204);
    }

    /**
     * Deletes a database from a server.
     *
     * @throws \\Exception
     */
    public function deleteDatabase(Server $server, Database $database): Response
    {
        $this->databaseManagementService->delete($database);

        return response('', 204);
    }

    /**
     * Add a mount to a server.
     *
     * @throws \\Throwable
     */
    public function addMount(Request $request, Server $server): RedirectResponse
    {
        $mountServer = (new MountServer())->forceFill([
            'mount_id' => $request->input('mount_id'),
            'server_id' => $server->id,
        ]);

        $mountServer->saveOrFail();

        $this->alert->success('Mount was added successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }

    /**
     * Remove a mount from a server.
     */
    public function deleteMount(Server $server, Mount $mount): RedirectResponse
    {
        MountServer::where('mount_id', $mount->id)->where('server_id', $server->id)->delete();

        $this->alert->success('Mount was removed successfully.')->flash();

        return redirect()->route('admin.servers.view.mounts', $server->id);
    }
}`
      },
      {
        name: "PROTECT1 ANTI UPDATE MANAGE (Anti Button Reinstall Status)",
        path: "/var/www/pterodactyl/app/Services/Servers/ReinstallServerService.php",
        file: "ReinstallServerService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Pterodactyl\\Models\\Server;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;

class ReinstallServerService
{
    /**
     * ReinstallService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository
    ) {
    }

    /**
     * Reinstall a server on the remote daemon.
     *
     * @throws \\Throwable
     */
    public function handle(Server $server): Server
    {
        return $this->connection->transaction(function () use ($server) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $this->daemonServerRepository->setServer($server)->reinstall();

            return $server->refresh();
        });
    }
}`
      },
      {
        name: "PROTECT1 (Anti Delete Server)",
        path: "/var/www/pterodactyl/app/Services/Servers/ServerDeletionService.php",
        file: "ServerDeletionService.php",
        code: `<?php

namespace Pterodactyl\\Services\\Servers;

use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Support\\Facades\\Log;
use Illuminate\\Database\\ConnectionInterface;
use Pterodactyl\\Repositories\\Wings\\DaemonServerRepository;
use Pterodactyl\\Services\\Databases\\DatabaseManagementService;
use Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    /**
     * ServerDeletionService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService
    ) {
    }

    /**
     * Set if the server should be forcibly deleted from the panel (ignoring daemon errors) or not.
     */
    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;

        return $this;
    }

    /**
     * Delete a server from the panel and remove any associated databases from hosts.
     *
     * @throws \\Throwable
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function handle(Server $server): void
    {
        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw $exception;
            }

            Log::warning($exception);
        }

        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\\Exception $exception) {
                    if (!$this->force) {
                        throw $exception;
                    }

                    $database->delete();

                    Log::warning($exception);
                }
            }

            $server->delete();
        });
    }
}`
      },
      {
        name: "PROTECT2 (ANTI INTIP USERS & ANTI CADMIN)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/UserController.php",
        file: "UserController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\User;
use Pterodactyl\\Models\\Model;
use Illuminate\\Support\\Collection;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Spatie\\QueryBuilder\\QueryBuilder;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Contracts\\Translation\\Translator;
use Pterodactyl\\Services\\Users\\UserUpdateService;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Users\\UserCreationService;
use Pterodactyl\\Services\\Users\\UserDeletionService;
use Pterodactyl\\Http\\Requests\\Admin\\UserFormRequest;
use Pterodactyl\\Http\\Requests\\Admin\\NewUserFormRequest;
use Pterodactyl\\Contracts\\Repository\\UserRepositoryInterface;

class UserController extends Controller
{
    use AvailableLanguages;

    /**
     * UserController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected UserCreationService $creationService,
        protected UserDeletionService $deletionService,
        protected Translator $translator,
        protected UserUpdateService $updateService,
        protected UserRepositoryInterface $repository,
        protected ViewFactory $view
    ) {
    }

    /**
     * Display user index page.
     */
    public function index(Request $request): View
    {
        $users = QueryBuilder::for(
            User::query()->select('users.*')
                ->selectRaw('COUNT(DISTINCT(subusers.id)) as subuser_of_count')
                ->selectRaw('COUNT(DISTINCT(servers.id)) as servers_count')
                ->leftJoin('subusers', 'subusers.user_id', '=', 'users.id')
                ->leftJoin('servers', 'servers.owner_id', '=', 'users.id')
                ->groupBy('users.id')
        )
            ->allowedFilters(['username', 'email', 'uuid'])
            ->allowedSorts(['id', 'uuid'])
            ->paginate(50);

        return $this->view->make('admin.users.index', ['users' => $users]);
    }

    /**
     * Display new user page.
     */
    public function create(): View
    {
        return $this->view->make('admin.users.new', [
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Display user view page.
     */
    public function view(User $user): View
    {
        return $this->view->make('admin.users.view', [
            'user' => $user,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Delete a user from the system.
     *
     * @throws \\Exception
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function delete(Request $request, User $user): RedirectResponse
    {
        if ($request->user()->id === $user->id) {
            throw new DisplayException($this->translator->get('admin/user.exceptions.user_has_servers'));
        }

        $this->deletionService->handle($user);

        return redirect()->route('admin.users');
    }

    /**
     * Create a user.
     *
     * @throws \\Exception
     * @throws \\Throwable
     */
    public function store(NewUserFormRequest $request): RedirectResponse
    {
        $user = $this->creationService->handle($request->normalize());
        $this->alert->success($this->translator->get('admin/user.notices.account_created'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Update a user on the system.
     *
* @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(UserFormRequest $request, User $user): RedirectResponse
    {
        $this->updateService
            ->setUserLevel(User::USER_LEVEL_ADMIN)
            ->handle($user, $request->normalize());

        $this->alert->success(trans('admin/user.notices.account_updated'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Get a JSON response of users on the system.
     */
    public function json(Request $request): Model|Collection
    {
        $users = QueryBuilder::for(User::query())->allowedFilters(['email'])->paginate(25);

        // Handle single user requests.
        if ($request->query('user_id')) {
            $user = User::query()->findOrFail($request->input('user_id'));
            $user->md5 = md5(strtolower($user->email));

            return $user;
        }

        return $users->map(function ($item) {
            $item->md5 = md5(strtolower($item->email));

            return $item;
        });
    }
}`
      },      
      {
        name: "PROTECT3 (ANTI INTIP LOCATION)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/LocationController.php",
        file: "LocationController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Illuminate\\View\\View;
use Pterodactyl\\Models\\Location;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Exceptions\\DisplayException;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\LocationFormRequest;
use Pterodactyl\\Services\\Locations\\LocationUpdateService;
use Pterodactyl\\Services\\Locations\\LocationCreationService;
use Pterodactyl\\Services\\Locations\\LocationDeletionService;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class LocationController extends Controller
{
    /**
     * LocationController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected LocationCreationService $creationService,
        protected LocationDeletionService $deletionService,
        protected LocationRepositoryInterface $repository,
        protected LocationUpdateService $updateService,
        protected ViewFactory $view
    ) {
    }

    /**
     * Return the location overview page.
     */
    public function index(): View
    {
        return $this->view->make('admin.locations.index', [
            'locations' => $this->repository->getAllWithDetails(),
        ]);
    }

    /**
     * Return the location view page.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(int $id): View
    {
        return $this->view->make('admin.locations.view', [
            'location' => $this->repository->getWithNodes($id),
        ]);
    }

    /**
     * Handle request to create new location.
     *
     * @throws \\Throwable
     */
    public function create(LocationFormRequest $request): RedirectResponse
    {
        $location = $this->creationService->handle($request->normalize());
        $this->alert->success('Location was created successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    /**
     * Handle request to update or delete location.
     *
     * @throws \\Throwable
     */
    public function update(LocationFormRequest $request, Location $location): RedirectResponse
    {
        if ($request->input('action') === 'delete') {
            return $this->delete($location);
        }

        $this->updateService->handle($location->id, $request->normalize());
        $this->alert->success('Location was updated successfully.')->flash();

        return redirect()->route('admin.locations.view', $location->id);
    }

    /**
     * Delete a location from the system.
     *
     * @throws \\Exception
     * @throws \\Pterodactyl\\Exceptions\\DisplayException
     */
    public function delete(Location $location): RedirectResponse
    {
        try {
            $this->deletionService->handle($location->id);

            return redirect()->route('admin.locations');
        } catch (DisplayException $ex) {
            $this->alert->danger($ex->getMessage())->flash();
        }

        return redirect()->route('admin.locations.view', $location->id);
    }
}`
      },
      {
        name: "PROTECT4 (ANTI INTIP NODES)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Nodes/NodeController.php",
        file: "NodeController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nodes;

use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Node;
use Spatie\\QueryBuilder\\QueryBuilder;
use Pterodactyl\\Http\\Controllers\\Controller;
use Illuminate\\Contracts\\View\\Factory as ViewFactory;

class NodeController extends Controller
{
    /**
     * NodeController constructor.
     */
    public function __construct(private ViewFactory $view)
    {
    }

    /**
     * Returns a listing of nodes on the system.
     */
    public function index(Request $request): View
    {
        $nodes = QueryBuilder::for(
            Node::query()->with('location')->withCount('servers')
        )
            ->allowedFilters(['uuid', 'name'])
            ->allowedSorts(['id'])
            ->paginate(25);

        return $this->view->make('admin.nodes.index', ['nodes' => $nodes]);
    }
}`
      },
      {
        name: "PROTECT5 (ANTI INTIP NEST)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Nests/NestController.php",
        file: "NestController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Nests;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Nests\\NestUpdateService;
use Pterodactyl\\Services\\Nests\\NestCreationService;
use Pterodactyl\\Services\\Nests\\NestDeletionService;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Nest\\StoreNestFormRequest;

class NestController extends Controller
{
    /**
     * NestController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestCreationService $nestCreationService,
        protected NestDeletionService $nestDeletionService,
        protected NestRepositoryInterface $repository,
        protected NestUpdateService $nestUpdateService,
        protected ViewFactory $view
    ) {
    }

    /**
     * Render nest listing page.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function index(): View
    {
        return $this->view->make('admin.nests.index', [
            'nests' => $this->repository->getWithCounts(),
        ]);
    }

    /**
     * Render nest creation page.
     */
    public function create(): View
    {
        return $this->view->make('admin.nests.new');
    }

    /**
     * Handle the storage of a new nest.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     */
    public function store(StoreNestFormRequest $request): RedirectResponse
    {
        $nest = $this->nestCreationService->handle($request->normalize());
        $this->alert->success(trans('admin/nests.notices.created', ['name' => htmlspecialchars($nest->name)]))->flash();

        return redirect()->route('admin.nests.view', $nest->id);
    }

    /**
     * Return details about a nest including all the eggs and servers per egg.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(int $nest): View
    {
        return $this->view->make('admin.nests.view', [
            'nest' => $this->repository->getWithEggServers($nest),
        ]);
    }

    /**
     * Handle request to update a nest.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(StoreNestFormRequest $request, int $nest): RedirectResponse
    {
        $this->nestUpdateService->handle($nest, $request->normalize());
        $this->alert->success(trans('admin/nests.notices.updated'))->flash();

        return redirect()->route('admin.nests.view', $nest);
    }

    /**
     * Handle request to delete a nest.
     *
     * @throws \\Pterodactyl\\Exceptions\\Service\\HasActiveServersException
     */
    public function destroy(int $nest): RedirectResponse
    {
        $this->nestDeletionService->handle($nest);
        $this->alert->success(trans('admin/nests.notices.deleted'))->flash();

        return redirect()->route('admin.nests');
    }
}`
      },
      {
        name: "PROTECT6 (ANTI INTIP SETTINGS)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/Settings/IndexController.php",
        file: "IndexController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin\\Settings;

use Illuminate\\View\\View;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\Contracts\\Console\\Kernel;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Traits\\Helpers\\AvailableLanguages;
use Pterodactyl\\Services\\Helpers\\SoftwareVersionService;
use Pterodactyl\\Contracts\\Repository\\SettingsRepositoryInterface;
use Pterodactyl\\Http\\Requests\\Admin\\Settings\\BaseSettingsFormRequest;

class IndexController extends Controller
{
    use AvailableLanguages;

    /**
     * IndexController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private SoftwareVersionService $versionService,
        private ViewFactory $view
    ) {
    }

    /**
     * Render the UI for basic Panel settings.
     */
    public function index(): View
    {
        return $this->view->make('admin.settings.index', [
            'version' => $this->versionService,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /**
     * Handle settings update.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function update(BaseSettingsFormRequest $request): RedirectResponse
    {
        foreach ($request->normalize() as $key => $value) {
            $this->settings->set('settings::' . $key, $value);
        }

        $this->kernel->call('queue:restart');
        $this->alert->success('Panel settings have been updated successfully and the queue worker was restarted to apply these changes.')->flash();

        return redirect()->route('admin.settings');
    }
}`
      },
      {
        name: "PROTECT7 (ANTI AKSES FILE & DOWNLOAD)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/FileController.php",
        file: "FileController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Carbon\\CarbonImmutable;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Server;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Nodes\\NodeJWTService;
use Pterodactyl\\Repositories\\Wings\\DaemonFileRepository;
use Pterodactyl\\Transformers\\Api\\Client\\FileObjectTransformer;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\CopyFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\PullFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\ListFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\ChmodFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\DeleteFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\RenameFileRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\CreateFolderRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\CompressFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\DecompressFilesRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\GetFileContentsRequest;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\Files\\WriteFileContentRequest;

class FileController extends ClientApiController
{
    /**
     * FileController constructor.
     */
    public function __construct(
        private NodeJWTService $jwtService,
        private DaemonFileRepository $fileRepository
    ) {
        parent::__construct();
    }

    /**
     * Returns a listing of files in a given directory.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function directory(ListFilesRequest $request, Server $server): array
    {
        $contents = $this->fileRepository
            ->setServer($server)
            ->getDirectory($request->get('directory') ?? '/');

        return $this->fractal->collection($contents)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    /**
     * Return the contents of a specified file for the user.
     *
     * @throws \\Throwable
     */
    public function contents(GetFileContentsRequest $request, Server $server): Response
    {
        $response = $this->fileRepository->setServer($server)->getContent(
            $request->get('file'),
            config('pterodactyl.files.max_edit_size')
        );

        Activity::event('server:file.read')->property('file', $request->get('file'))->log();

        return new Response($response, Response::HTTP_OK, ['Content-Type' => 'text/plain']);
    }

    /**
     * Generates a one-time token with a link that the user can use to
     * download a given file.
     *
     * @throws \\Throwable
     */
    public function download(GetFileContentsRequest $request, Server $server): array
    {
        $token = $this->jwtService
            ->setExpiresAt(CarbonImmutable::now()->addMinutes(15))
            ->setUser($request->user())
            ->setClaims([
                'file_path' => rawurldecode($request->get('file')),
                'server_uuid' => $server->uuid,
            ])
            ->handle($server->node, $request->user()->id . $server->uuid);

        Activity::event('server:file.download')->property('file', $request->get('file'))->log();

        return [
            'object' => 'signed_url',
            'attributes' => [
                'url' => sprintf(
                    '%s/download/file?token=%s',
                    $server->node->getConnectionAddress(),
                    $token->toString()
                ),
            ],
        ];
    }

    /**
     * Writes the contents of the specified file to the server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function write(WriteFileContentRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->putContent($request->get('file'), $request->getContent());

        Activity::event('server:file.write')->property('file', $request->get('file'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Creates a new folder on the server.
     *
     * @throws \\Throwable
     */
    public function create(CreateFolderRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository
            ->setServer($server)
            ->createDirectory($request->input('name'), $request->input('root', '/'));

        Activity::event('server:file.create-directory')
            ->property('name', $request->input('name'))
            ->property('directory', $request->input('root'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Renames a file on the remote machine.
     *
     * @throws \\Throwable
     */
    public function rename(RenameFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository
            ->setServer($server)
            ->renameFiles($request->input('root'), $request->input('files'));

        Activity::event('server:file.rename')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Copies a file on the server.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function copy(CopyFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository
            ->setServer($server)
            ->copyFile($request->input('location'));

        Activity::event('server:file.copy')->property('file', $request->input('location'))->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function compress(CompressFilesRequest $request, Server $server): array
    {
        $file = $this->fileRepository->setServer($server)->compressFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.compress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return $this->fractal->item($file)
            ->transformWith($this->getTransformer(FileObjectTransformer::class))
            ->toArray();
    }

    /**
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function decompress(DecompressFilesRequest $request, Server $server): JsonResponse
    {
        set_time_limit(300);

        $this->fileRepository->setServer($server)->decompressFile(
            $request->input('root'),
            $request->input('file')
        );

        Activity::event('server:file.decompress')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('file'))
            ->log();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }

    /**
     * Deletes files or folders for the server in the given root directory.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function delete(DeleteFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->deleteFiles(
            $request->input('root'),
            $request->input('files')
        );

        Activity::event('server:file.delete')
            ->property('directory', $request->input('root'))
            ->property('files', $request->input('files'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Updates file permissions for file(s) in the given root directory.
     *
     * @throws \\Pterodactyl\\Exceptions\\Http\\Connection\\DaemonConnectionException
     */
    public function chmod(ChmodFilesRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->chmodFiles(
            $request->input('root'),
            $request->input('files')
        );

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Requests that a file be downloaded from a remote location by Wings.
     *
     * @throws \\Throwable
     */
    public function pull(PullFileRequest $request, Server $server): JsonResponse
    {
        $this->fileRepository->setServer($server)->pull(
            $request->input('url'),
            $request->input('directory'),
            $request->safe(['filename', 'use_header', 'foreground'])
        );

        Activity::event('server:file.pull')
            ->property('directory', $request->input('directory'))
            ->property('url', $request->input('url'))
            ->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`
      },
      {
        name: "PROTECT8 (ANTI INTIP SERVER)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/ServerController.php",
        file: "ServerController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Pterodactyl\\Models\\Server;
use Pterodactyl\\Transformers\\Api\\Client\\ServerTransformer;
use Pterodactyl\\Services\\Servers\\GetUserPermissionsService;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\GetServerRequest;

class ServerController extends ClientApiController
{
    /**
     * ServerController constructor.
     */
    public function __construct(private GetUserPermissionsService $permissionsService)
    {
        parent::__construct();
    }

    /**
     * Transform an individual server into a response that can be consumed by a
     * client using the API.
     */
    public function index(GetServerRequest $request, Server $server): array
    {
        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->addMeta([
                'is_server_owner' => $request->user()->id === $server->owner_id,
                'user_permissions' => $this->permissionsService->handle($server, $request->user()),
            ])
            ->toArray();
    }
}`
      },
      {
        name: "PROTECT9 (ANTI INTIP APIKEY)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/ApiController.php",
        file: "ApiController.php",
        code: `<?php  
  
namespace Pterodactyl\\Http\\Controllers\\Admin;  
  
use Illuminate\\View\\View;  
use Illuminate\\Http\\Request;  
use Illuminate\\Http\\Response;  
use Pterodactyl\\Models\\ApiKey;  
use Illuminate\\Http\\RedirectResponse;  
use Prologue\\Alerts\\AlertsMessageBag;  
use Pterodactyl\\Services\\Acl\\Api\\AdminAcl;  
use Illuminate\\View\\Factory as ViewFactory;  
use Pterodactyl\\Http\\Controllers\\Controller;  
use Pterodactyl\\Services\\Api\\KeyCreationService;  
use Pterodactyl\\Contracts\\Repository\\ApiKeyRepositoryInterface;  
use Pterodactyl\\Http\\Requests\\Admin\\Api\\StoreApplicationApiKeyRequest;  
  
class ApiController extends Controller  
{  
    /**  
     * ApiController constructor.  
     */  
    public function __construct(  
        private AlertsMessageBag $alert,  
        private ApiKeyRepositoryInterface $repository,  
        private KeyCreationService $keyCreationService,  
        private ViewFactory $view,  
    ) {  
    }  
  
    /**  
     * Render view showing all of a user's application API keys.  
     */  
    public function index(Request $request): View  
    {  
        return $this->view->make('admin.api.index', [  
            'keys' => $this->repository->getApplicationKeys($request->user()),  
        ]);  
    }  
  
    /**  
     * Render view allowing an admin to create a new application API key.  
     *  
     * @throws \\ReflectionException  
     */  
    public function create(): View  
    {  
        $resources = AdminAcl::getResourceList();  
        sort($resources);  
  
        return $this->view->make('admin.api.new', [  
            'resources' => $resources,  
            'permissions' => [  
                'r' => AdminAcl::READ,  
                'rw' => AdminAcl::READ | AdminAcl::WRITE,  
                'n' => AdminAcl::NONE,  
            ],  
        ]);  
    }  
  
    /**  
     * Store the new key and redirect the user back to the application key listing.  
     *  
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException  
     */  
    public function store(StoreApplicationApiKeyRequest $request): RedirectResponse  
    {  
        $this->keyCreationService->setKeyType(ApiKey::TYPE_APPLICATION)->handle([  
            'memo' => $request->input('memo'),  
            'user_id' => $request->user()->id,  
        ], $request->getKeyPermissions());  
  
        $this->alert->success('A new application API key has been generated for your account.')->flash();  
  
        return redirect()->route('admin.api.index');  
    }  
  
    /**  
     * Delete an application API key from the database.  
     */  
    public function delete(Request $request, string $identifier): Response  
    {  
        $this->repository->deleteApplicationKey($request->user(), $identifier);  
  
        return response('', 204);  
    }  
}`
      },
      {
        name: "PROTECT10 (ANTI CREATE CAPIKEY)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/ApiKeyController.php",
        file: "ApiKeyController.php",
        code: `<?php    
    
namespace Pterodactyl\\Http\\Controllers\\Api\\Client;    
    
use Pterodactyl\\Models\\ApiKey;    
use Illuminate\\Http\\JsonResponse;    
use Pterodactyl\\Facades\\Activity;    
use Pterodactyl\\Exceptions\\DisplayException;    
use Pterodactyl\\Http\\Requests\\Api\\Client\\ClientApiRequest;    
use Pterodactyl\\Transformers\\Api\\Client\\ApiKeyTransformer;    
use Pterodactyl\\Http\\Requests\\Api\\Client\\Account\\StoreApiKeyRequest;    
    
class ApiKeyController extends ClientApiController    
{    
    /**    
     * Returns all the API keys that exist for the given client.    
     */    
    public function index(ClientApiRequest $request): array    
    {    
        return $this->fractal->collection($request->user()->apiKeys)    
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))    
            ->toArray();    
    }    
    
    /**    
     * Store a new API key for a user's account.    
     *    
     * @throws \\Pterodactyl\\Exceptions\\DisplayException    
     */    
    public function store(StoreApiKeyRequest $request): array    
    {    
        if ($request->user()->apiKeys->count() >= 25) {    
            throw new DisplayException('You have reached the account limit for number of API keys.');    
        }    
    
        $token = $request->user()->createToken(    
            $request->input('description'),    
            $request->input('allowed_ips')    
        );    
    
        Activity::event('user:api-key.create')    
            ->subject($token->accessToken)    
            ->property('identifier', $token->accessToken->identifier)    
            ->log();    
    
        return $this->fractal->item($token->accessToken)    
            ->transformWith($this->getTransformer(ApiKeyTransformer::class))    
            ->addMeta(['secret_token' => $token->plainTextToken])    
            ->toArray();    
    }    
    
    /**    
     * Deletes a given API key.    
     */    
    public function delete(ClientApiRequest $request, string $identifier): JsonResponse    
    {    
        /** @var \\Pterodactyl\\Models\\ApiKey $key */    
        $key = $request->user()->apiKeys()    
            ->where('key_type', ApiKey::TYPE_ACCOUNT)    
            ->where('identifier', $identifier)    
            ->firstOrFail();    
    
        Activity::event('user:api-key.delete')    
            ->property('identifier', $key->identifier)    
            ->log();    
    
        $key->delete();    
    
        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);    
    }    
}`
      },
      {
        name: "PROTECT11 (ANTI INTIP DATABASE)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/DatabaseController.php",
        file: "DatabaseController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Exception;
use Illuminate\\View\\View;
use Pterodactyl\\Models\\DatabaseHost;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Services\\Databases\\Hosts\\HostUpdateService;
use Pterodactyl\\Http\\Requests\\Admin\\DatabaseHostFormRequest;
use Pterodactyl\\Services\\Databases\\Hosts\\HostCreationService;
use Pterodactyl\\Services\\Databases\\Hosts\\HostDeletionService;
use Pterodactyl\\Contracts\\Repository\\DatabaseRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\DatabaseHostRepositoryInterface;

class DatabaseController extends Controller
{
    /**
     * DatabaseController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert,
        private DatabaseHostRepositoryInterface $repository,
        private DatabaseRepositoryInterface $databaseRepository,
        private HostCreationService $creationService,
        private HostDeletionService $deletionService,
        private HostUpdateService $updateService,
        private LocationRepositoryInterface $locationRepository,
        private ViewFactory $view
    ) {
    }

    /**
     * Display database host index.
     */
    public function index(): View
    {
        return $this->view->make('admin.databases.index', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'hosts' => $this->repository->getWithViewDetails(),
        ]);
    }

    /**
     * Display database host to user.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(int $host): View
    {
        return $this->view->make('admin.databases.view', [
            'locations' => $this->locationRepository->getAllWithNodes(),
            'host' => $this->repository->find($host),
            'databases' => $this->databaseRepository->getDatabasesForHost($host),
        ]);
    }

    /**
     * Handle request to create a new database host.
     *
     * @throws \\Throwable
     */
    public function create(DatabaseHostFormRequest $request): RedirectResponse
    {
        try {
            $host = $this->creationService->handle($request->normalize());
        } catch (\\Exception $exception) {
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('There was an error while trying to connect to the host or while executing a query: "%s"', $exception->getMessage())
                )->flash();

                return redirect()->route('admin.databases')->withInput($request->validated());
            } else {
                throw $exception;
            }
        }

        $this->alert->success('Successfully created a new database host on the system.')->flash();

        return redirect()->route('admin.databases.view', $host->id);
    }

    /**
     * Handle updating database host.
     *
     * @throws \\Throwable
     */
    public function update(DatabaseHostFormRequest $request, DatabaseHost $host): RedirectResponse
    {
        $redirect = redirect()->route('admin.databases.view', $host->id);

        try {
            $this->updateService->handle($host->id, $request->normalize());
            $this->alert->success('Database host was updated successfully.')->flash();
        } catch (\\Exception $exception) {
            // Catch any SQL related exceptions and display them back to the user, otherwise just
            // throw the exception like normal and move on with it.
            if ($exception instanceof \\PDOException || $exception->getPrevious() instanceof \\PDOException) {
                $this->alert->danger(
                    sprintf('There was an error while trying to connect to the host or while executing a query: "%s"', $exception->getMessage())
                )->flash();

                return $redirect->withInput($request->normalize());
            } else {
                throw $exception;
            }
        }

        return $redirect;
    }

    /**
     * Handle request to delete a database host.
     *
     * @throws \\Pterodactyl\\Exceptions\\Service\\HasActiveServersException
     */
    public function delete(int $host): RedirectResponse
    {
        $this->deletionService->handle($host);
        $this->alert->success('The requested database host has been deleted from the system.')->flash();

        return redirect()->route('admin.databases');
    }
}`
      },
      {
        name: "PROTECT12 (ANTI INTIP MOUNTS)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Admin/MountController.php",
        file: "MountController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Admin;

use Ramsey\\Uuid\\Uuid;
use Illuminate\\View\\View;
use Illuminate\\Http\\Request;
use Pterodactyl\\Models\\Nest;
use Illuminate\\Http\\Response;
use Pterodactyl\\Models\\Mount;
use Pterodactyl\\Models\\Location;
use Illuminate\\Http\\RedirectResponse;
use Prologue\\Alerts\\AlertsMessageBag;
use Illuminate\\View\\Factory as ViewFactory;
use Pterodactyl\\Http\\Controllers\\Controller;
use Pterodactyl\\Http\\Requests\\Admin\\MountFormRequest;
use Pterodactyl\\Repositories\\Eloquent\\MountRepository;
use Pterodactyl\\Contracts\\Repository\\NestRepositoryInterface;
use Pterodactyl\\Contracts\\Repository\\LocationRepositoryInterface;

class MountController extends Controller
{
    /**
     * MountController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected NestRepositoryInterface $nestRepository,
        protected LocationRepositoryInterface $locationRepository,
        protected MountRepository $repository,
        protected ViewFactory $view
    ) {
    }

    /**
     * Return the mount overview page.
     */
    public function index(): View
    {
        return $this->view->make('admin.mounts.index', [
            'mounts' => $this->repository->getAllWithDetails(),
        ]);
    }

    /**
     * Return the mount view page.
     *
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function view(string $id): View
    {
        $nests = Nest::query()->with('eggs')->get();
        $locations = Location::query()->with('nodes')->get();

        return $this->view->make('admin.mounts.view', [
            'mount' => $this->repository->getWithRelations($id),
            'nests' => $nests,
            'locations' => $locations,
        ]);
    }

    /**
     * Handle request to create new mount.
     *
     * @throws \\Throwable
     */
    public function create(MountFormRequest $request): RedirectResponse
    {
        $model = (new Mount())->fill($request->validated());
        $model->forceFill(['uuid' => Uuid::uuid4()->toString()]);

        $model->saveOrFail();
        $mount = $model->fresh();

        $this->alert->success('Mount was created successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Handle request to update or delete location.
     *
     * @throws \\Throwable
     */
    public function update(MountFormRequest $request, Mount $mount): RedirectResponse
    {
        if ($request->input('action') === 'delete') {
            return $this->delete($mount);
        }

        $mount->forceFill($request->validated())->save();

        $this->alert->success('Mount was updated successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Delete a location from the system.
     *
     * @throws \\Exception
     */
    public function delete(Mount $mount): RedirectResponse
    {
        $mount->delete();

        return redirect()->route('admin.mounts');
    }

    /**
     * Adds eggs to the mount's many-to-many relation.
     */
    public function addEggs(Request $request, Mount $mount): RedirectResponse
    {
        $validatedData = $request->validate([
            'eggs' => 'required|exists:eggs,id',
        ]);

        $eggs = $validatedData['eggs'] ?? [];
        if (count($eggs) > 0) {
            $mount->eggs()->attach($eggs);
        }

        $this->alert->success('Mount was updated successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Adds nodes to the mount's many-to-many relation.
     */
    public function addNodes(Request $request, Mount $mount): RedirectResponse
    {
        $data = $request->validate(['nodes' => 'required|exists:nodes,id']);

        $nodes = $data['nodes'] ?? [];
        if (count($nodes) > 0) {
            $mount->nodes()->attach($nodes);
        }

        $this->alert->success('Mount was updated successfully.')->flash();

        return redirect()->route('admin.mounts.view', $mount->id);
    }

    /**
     * Deletes an egg from the mount's many-to-many relation.
     */
    public function deleteEgg(Mount $mount, int $egg_id): Response
    {
        $mount->eggs()->detach($egg_id);

        return response('', 204);
    }

    /**
     * Deletes a node from the mount's many-to-many relation.
     */
    public function deleteNode(Mount $mount, int $node_id): Response
    {
        $mount->nodes()->detach($node_id);

        return response('', 204);
    }
}`
      },
      {
        name: "PROTECT13 (ANTI BUTTON TWO FACTOR)",
        path: "/var/www/pterodactyl/app/Http/Controllers/Api/Client/TwoFactorController.php",
        file: "TwoFactorController.php",
        code: `<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client;

use Carbon\\Carbon;
use Illuminate\\Http\\Request;
use Illuminate\\Http\\Response;
use Illuminate\\Http\\JsonResponse;
use Pterodactyl\\Facades\\Activity;
use Pterodactyl\\Services\\Users\\TwoFactorSetupService;
use Pterodactyl\\Services\\Users\\ToggleTwoFactorService;
use Illuminate\\Contracts\\Validation\\Factory as ValidationFactory;
use Symfony\\Component\\HttpKernel\\Exception\\BadRequestHttpException;

class TwoFactorController extends ClientApiController
{
    /**
     * TwoFactorController constructor.
     */
    public function __construct(
        private ToggleTwoFactorService $toggleTwoFactorService,
        private TwoFactorSetupService $setupService,
        private ValidationFactory $validation
    ) {
        parent::__construct();
    }

    /**
     * Returns two-factor token credentials that allow a user to configure
     * it on their account. If two-factor is already enabled this endpoint
     * will return a 400 error.
     *
     * @throws \\Pterodactyl\\Exceptions\\Model\\DataValidationException
     * @throws \\Pterodactyl\\Exceptions\\Repository\\RecordNotFoundException
     */
    public function index(Request $request): JsonResponse
    {
        if ($request->user()->use_totp) {
            throw new BadRequestHttpException('Two-factor authentication is already enabled on this account.');
        }

        return new JsonResponse([
            'data' => $this->setupService->handle($request->user()),
        ]);
    }

    /**
     * Updates a user's account to have two-factor enabled.
     *
     * @throws \\Throwable
     * @throws \\Illuminate\\Validation\\ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        $validator = $this->validation->make($request->all(), [
            'code' => ['required', 'string', 'size:6'],
            'password' => ['required', 'string'],
        ]);

        $data = $validator->validate();
        if (!password_verify($data['password'], $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        $tokens = $this->toggleTwoFactorService->handle($request->user(), $data['code'], true);

        Activity::event('user:two-factor.create')->log();

        return new JsonResponse([
            'object' => 'recovery_tokens',
            'attributes' => [
                'tokens' => $tokens,
            ],
        ]);
    }

    /**
     * Disables two-factor authentication on an account if the password provided
     * is valid.
     *
     * @throws \\Throwable
     */
    public function delete(Request $request): JsonResponse
    {
        if (!password_verify($request->input('password') ?? '', $request->user()->password)) {
            throw new BadRequestHttpException('The password provided was not valid.');
        }

        /** @var \\Pterodactyl\\Models\\User $user */
        $user = $request->user();

        $user->update([
            'totp_authenticated_at' => Carbon::now(),
            'use_totp' => false,
        ]);

        Activity::event('user:two-factor.delete')->log();

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }
}`
      },                                   
      {
        name: "PROTECT14 (𝗠𝗘𝗡𝗚𝗛𝗜𝗟𝗔𝗡𝗚𝗞𝗔𝗡 𝗕𝗔𝗥 𝗠𝗘𝗡𝗨 “𝗡𝗢𝗗𝗘𝗦, 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡𝗦, 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘, 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦, 𝗔𝗣𝗣𝗟𝗜𝗖𝗔𝗧𝗜𝗢𝗡 𝗔𝗣𝗜, 𝗠𝗢𝗨𝗡𝗧𝗦, 𝗡𝗘𝗦𝗧)",
        path: "/var/www/pterodactyl/resources/views/layouts/admin.blade.php",
        file: "admin.blade.php",
        code: `<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="{{ csrf_token() }}">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#0e4688">

        @include('layouts.scripts')

        @section('scripts')
            {!! Theme::css('vendor/select2/select2.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/admin.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/animate/animate.min.css?t={cache-version}') !!}
            {!! Theme::css('css/pterodactyl.css?t={cache-version}') !!}
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        @show
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="{{ route('index') }}" class="logo">
                    <span>{{ config('app.name', 'Pterodactyl') }}</span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="user-menu">
                                <a href="{{ route('account') }}">
                                    <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs">{{ Auth::user()->name_first }} {{ Auth::user()->name_last }}</span>
                                </a>
                            </li>
                            <li>
                                <li><a href="{{ route('index') }}" data-toggle="tooltip" data-placement="bottom" title="Exit Admin Control"><i class="fa fa-server"></i></a></li>
                            </li>
                            <li>
                                <li><a href="{{ route('auth.logout') }}" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li class="header">BASIC ADMINISTRATION</li>
                        <li class="{{ Route::currentRouteName() !== 'admin.index' ?: 'active' }}">
                            <a href="{{ route('admin.index') }}">
                                <i class="fa fa-home"></i> <span>Overview</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.settings') ?: 'active' }}">
                            <a href="{{ route('admin.settings')}}">
                                <i class="fa fa-wrench"></i> <span>Settings</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.api') ?: 'active' }}">
                            <a href="{{ route('admin.api.index')}}">
                                <i class="fa fa-gamepad"></i> <span>Application API</span>
                            </a>
                        </li>
                        <li class="header">MANAGEMENT</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.databases') ?: 'active' }}">
                            <a href="{{ route('admin.databases') }}">
                                <i class="fa fa-database"></i> <span>Databases</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.locations') ?: 'active' }}">
                            <a href="{{ route('admin.locations') }}">
                                <i class="fa fa-globe"></i> <span>Locations</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nodes') ?: 'active' }}">
                            <a href="{{ route('admin.nodes') }}">
                                <i class="fa fa-sitemap"></i> <span>Nodes</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.servers') ?: 'active' }}">
                            <a href="{{ route('admin.servers') }}">
                                <i class="fa fa-server"></i> <span>Servers</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active' }}">
                            <a href="{{ route('admin.users') }}">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
                        <li class="header">SERVICE MANAGEMENT</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.mounts') ?: 'active' }}">
                            <a href="{{ route('admin.mounts') }}">
                                <i class="fa fa-magic"></i> <span>Mounts</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nests') ?: 'active' }}">
                            <a href="{{ route('admin.nests') }}">
                                <i class="fa fa-th-large"></i> <span>Nests</span>
                            </a>
                        </li>
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    @yield('content-header')
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    There was an error validating the data provided.<br><br>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @foreach (Alert::getMessages() as $type => $messages)
                                @foreach ($messages as $message)
                                    <div class="alert alert-{{ $type }} alert-dismissable" role="alert">
                                        {!! $message !!}
                                    </div>
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                    @yield('content')
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw {{ $appIsGit ? 'fa-git-square' : 'fa-code-fork' }}"></i></strong> {{ $appVersion }}<br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> {{ round(microtime(true) - LARAVEL_START, 3) }}s
                </div>
                Copyright &copy; 2015 - {{ date('Y') }} <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
            </footer>
        </div>
        @section('footer-scripts')
            <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
            <script>keyboardeventKeyPolyfill.polyfill();</script>

            {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/adminlte/app.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/select2/select2.full.min.js?t={cache-version}') !!}
            {!! Theme::js('js/admin/functions.js?t={cache-version}') !!}
            <script src="/js/autocomplete.js" type="application/javascript"></script>

            @if(Auth::user()->root_admin)
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        var that = this;
                        swal({
                            title: 'Do you want to log out?',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Log out'
                        }, function () {
                             $.ajax({
                                type: 'POST',
                                url: '{{ route('auth.logout') }}',
                                data: {
                                    _token: '{{ csrf_token() }}'
                                },complete: function () {
                                    window.location.href = '{{route('auth.login')}}';
                                }
                        });
                    });
                });
                </script>
            @endif

            <script>
                $(function () {
                    $('[data-toggle="tooltip"]').tooltip();
                })
            </script>
        @show
    </body>
</html>`
      },
    ];

    // ========================= UPLOAD SEMUA PROTEKSI =========================
    let successCount = 0;

    for (const file of protectFiles) {
      try {
        const tempFile = path.join(__dirname, file.file);
        fs.writeFileSync(tempFile, file.code);
        await ssh.putFile(tempFile, file.path);
        fs.unlinkSync(tempFile);
        successCount++;
        await bot.sendMessage(chatId, `✅ *${file.name}* berhasil dipasang!\n📂 \`${file.path}\``, {
          parse_mode: "Markdown",
        });
      } catch (err) {
        await bot.sendMessage(
          chatId,
          `❌ Gagal memasang *${file.name}*\nError: \`${err.message}\``,
          { parse_mode: "Markdown" }
        );
      }
    }

    ssh.dispose();

await bot.sendMessage(
  chatId,
  `🧩 *INSTALASI PROTECT ALL SELESAI!*\n
✅ Berhasil: ${successCount}/${protectFiles.length} file\n
⚙️ Semua fitur keamanan aktif untuk panelmu.\n\n©Protect By @wilzzofficial`,
  { parse_mode: "Markdown" }
);

    console.log(`🟢 InstallProtectAll selesai untuk user ${userId} di VPS ${session.host}`);
  } catch (err) {
    console.error("❌ ERROR INSTALLPROTECTALL:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal menjalankan instalasi ProtectAll.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
// ====================================================
// 🧠 AUTO RESTART (ANTI HANG)
// ====================================================
setInterval(() => {
  const used = process.memoryUsage().heapUsed / 1024 / 1024;
  if (used > 500) {
    console.log("⚠️ Memory tinggi, restart otomatis...");
    process.exit(1);
  }
}, 30000);

//##################################//

bot.getMe().then(async () => {
  console.clear();

  const developer = config.authorName;
  const botversion = config.version;

  // 🌌 Tampilan Cyber Boot Logo (WOW Style)
  console.log(chalk.cyanBright(`
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀
⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀
⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉
`));
  console.log(chalk.bold.white("        𝐍𝐃𝐘𝐙 - 𝐎𝐅𝐅𝐂\n"));
  console.log(chalk.white.bold("DEVELOPER    : ") + chalk.cyan(developer));
  console.log(chalk.white.bold("VERSION      : ") + chalk.green(botversion));
  console.log(chalk.greenBright("\nBot Berhasil Tersambung [✓]\n"));

  // 🔔 Kirim notifikasi ke owner
  bot.sendMessage(config.OWNER_ID, "*✅ Bot Telegram Berhasil Tersambung!*", { parse_mode: "Markdown" });
});

// ==================== ⚡ SYSTEM LOG : USER COMMAND DETECTED (CYBER NDY EDITION) ====================
bot.on("message", async (msg) => {
  try {
    if (!msg.text || !msg.from) return;
    const text = msg.text.trim();

    // Hanya notif untuk command "/"
    if (!text.startsWith("/")) return;

    const command = text.split(" ")[0].toLowerCase();
    const userId = msg.from.id.toString();
    const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
    const fullName = `${msg.from.first_name || ""} ${msg.from.last_name || ""}`.trim();
    const fiturDipakai = command;

    const moment = require("moment-timezone");
    const waktu = moment().tz("Asia/Jakarta").format("DD-MM-YYYY HH:mm:ss");

    const chatType =
      msg.chat.type === "private"
        ? "📩 Private Chat"
        : msg.chat.title
        ? `👥 Group: *${msg.chat.title}*`
        : "🌐 Unknown Zone";

    const locationInfo =
      msg.chat.type === "private"
        ? "📩 Mode     : *Private Chat*"
        : `👥 Grup     : *${msg.chat.title}*\n┃ 🆔 Group ID : \`${msg.chat.id}\``;

    // Skip notif untuk owner
    if (userId === config.OWNER_ID.toString()) return;

    const notifText = `
╔═══ 𓆩⚡𓆪 𝗨𝗦𝗘𝗥 𝗕𝗔𝗥𝗨 𝗗𝗘𝗧𝗘𝗞𝗧𝗘𝗞𝗧𝗘𝗗 𓆩⚡𓆪 ═══╗

📥 *Seseorang baru saja mengakses bot!*

┣━〔 👤 PROFIL 〕
┃ 🧍 Nama     : *${fullName}*
┃ 🔗 Username : ${msg.from.username ? `[@${msg.from.username}](https://t.me/${msg.from.username})` : "Tidak tersedia"}
┃ 🆔 User ID  : \`${msg.from.id}\`
┃ 🕐 Waktu    : ${waktu}
┃ 📡 Status   : *LIVE CONNECTED*
┃ ${locationInfo.split("\n").join("\n┃ ")}
┃ 💬 *Command:* \`${fiturDipakai}\`

┣━〔 ⚙️ SYSTEM LOG 〕
┃ 🤖 Bot     : ${config.botName}
┃ 🔋 Mode    : Public + Real-Time
┃ 🚀 Access  : Premium Service
┃ 🧠 Logger  : Aktif ✅
┃ 🛰️ Channel : ${chatType}

╚═══ ✦ SYSTEM ALERT NDY 2025 ✦ ═══╝`;

    await bot.sendMessage(config.OWNER_ID, notifText, {
      parse_mode: "Markdown",
      disable_web_page_preview: true,
    });
  } catch (err) {
    console.error("❌ Gagal kirim notif ke owner:", err);
  }
});

//##################################//

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log("Update File:", __filename);
  delete require.cache[file];
  require(file);
});