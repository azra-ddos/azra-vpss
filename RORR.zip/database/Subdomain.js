// ./Control/Subdomain.js
module.exports = {
  domains: {
     "unix.biz.id": {
      zone: "c02121177bbabcc553b617354cd21d8e",
      apitoken: "4HI-JH1jJgl-PcAq9hPrSyp1i8LZxq_kKRSlc8AF"
      },
    "kedai-panel.my.id": {
      zone: "5d00f56aee3afd9cc4e0666bc8f23746",
      apitoken: "mjR4BdiOo6aFO3uPl8BTgZIgOMH3asLbgVsOpEfO"
    },
    "sainsproject.biz.id": {
      zone: "8211830a7911e9028f38018243ea360d",
      apitoken: "XLllrPcIOIC-S4yQP2iaJ9GELQVrL5agcAtEyGXN"
    },
    "agcloud.my.id": {
      zone: "09c637a74efd85e94e035eeae2aa3c31", 
      apitoken: "Hi5A5xlLHR8q1glXHCAB1p-hOMf2Z1AVgLkFwwRn"
    },
    "mypanel.web.id": {
      zone: "b8233801ad0b684d315c19b4b3963463",
      apitoken: "Jxwpvdw2IkwtuS-Dv97c0DQFZOQcrvDaM31HtiiU"
    },
    "panelku-vip.my.id": {
      zone: "0d9911cf588f189a626249a082af24be",
      apitoken: "jsli552xYmcVeVyX2-ulWeepLK_-XCqiar0PxO7l"
    },
    "servemcpec.my.id": {
      zone: "bb0b767035e14c69cecfdd3eb757b322", 
      apitoken: "S9-2ht3ZxW0B8JjkTI720WaM743nvJKwXfMw3pXI"
    },
    "storedigital.web.id": {
      zone: "2ce8a2f880534806e2f463e3eec68d31",
      apitoken: "v5_unJTqruXV_x-5uj0dT5_Q4QAPThJbXzC2MmOQ"
    },
    "xnxxx.tech": {
      zone: "639f9cde20c22b1d2f33b2fee54f8f59",
      apitoken: "MtWI3a9-9Za-fGKmwl0uNznqM94eljKgobkF36h1"
    },
    "tamaoffc.biz.id": {
      zone: "177538af7fb12443a80892554d01206f",
      apitoken: "ZaVSjxa96NQDV6lQgspAVsVXrvVzdOpqL1z6PG0Z"
    },
    "zerohiro.biz.id": {
      zone: "e74bccf4e00a78ba79d0c1ea07d39afe",
      apitoken: "C3FXhOF4J9djIXEJMBJb0FnLdtKsMEf2wAiuZ8vV"
    },
    "vhon-offcial.biz.id": {
      zone: "4ae62ec77fd01d966f1dff7f393d7162",
      apitoken: "C3FXhOF4J9djIXEJMBJb0FnLdtKsMEf2wAiuZ8vV"
    },
    "zwmhost.biz.id": {
      zone: "7753f88eda4db1674254c9eefc47e184",
      apitoken: "C3FXhOF4J9djIXEJMBJb0FnLdtKsMEf2wAiuZ8vV"
    },
    "mamhost.biz.id": {
      zone: "d88dccee1fd5fd2dcd47ddb7c91e2591",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    "orang-gantengg.biz.id": {
      zone: "a9dd58ec424aa4bb2439d0c569d07573",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    "xyzmam.biz.id": {
      zone: "49bb8266d07adee6b8b0999db470f45d",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    "xyzmamhost.my.id": {
      zone: "0b61c1c8287675fcbc9c5894cb3d1b92",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    "mypanelstore.web.id": {
      zone: "c61c442d70392500611499c5af816532",
      apitoken: "gqg5B6_1UQhb72wg4zS1U7AGNbofMYRXT8zFiKZC"
    },
    "zero-hosting.my.id": {
      zone: "0885a91405436a41a6b0a26c05da9a74",
      apitoken: "C3FXhOF4J9djIXEJMBJb0FnLdtKsMEf2wAiuZ8vV"
    },
    "myzoku.my.id": {
      zone: "b95b2842510f342cfccfd66ae4f31d09",
      apitoken: "C3FXhOF4J9djIXEJMBJb0FnLdtKsMEf2wAiuZ8vV"
    },
    "tokopanellku.my.id": {
      zone: "0ec1fbe7f2ed72f4bb6bac2966dd5e8f",
      apitoken: "xU3SFxk8OivJRJJKSOMtEN-O44tGs5zmxAxJmcC9"
    },
    "sellerpanel-vvip.my.id": {
      zone: "07b3f89c493f317d96d34de224019970",
      apitoken: "9irVbHQVIGZcD5-muBytl-B5h48S33pNZRsz3ziy"
    },
    "pterohost.my.id": {
      zone: "1bb268eff31c9811b1eb051431485358",
      apitoken: "C6vyp_OsbVAnLQ_18_BZdbQ_o_hUupJEQNdT6jgY"
    },
    "mypanel-private.my.id": {
      zone: "fdaa66d6ca9956e7d84fb4b8e01e66e1",
      apitoken: "lvZ0-W_45jZfiik2RX_TGNkFPwCPSxZVpbvJ29aG"
    },
    "barmodsdomain.my.id": {
      zone: "05478e906fa1556f81ae0eaf86816060",
      apitoken: "nkIplLsfGW-FSUYEpbSt3_I2-a9JIWZIvGO5W6xN"
    },
    "jokowii.my.id": {
      zone: "67a887a21f43fea088a47902a436c400", 
      apitoken: "FwLKNhNL5LhI_LhAzH7pD-v6BrIcQ5dsdKRtaytS"
    },
    "marketrikishop.my.id": {
      zone: "33970794e3373167a9c9556ad19fdb6a",
      apitoken: "TWf7dzMAu1dOc0XNuE98auJiSryxkUkQBbJpkwgr"
    },
    "panelku-ptero.my.id": {
      zone: "ea719beeec3cfe39b58f0195f848498f",
      apitoken: "Gb8j0xFasrWB1k80b4BFrIL_f2IgAQ5n66CamFbP"
    },
    "prabowoo.my.id": {
      zone: "af679c959583e9eff1685ef4c7cbf048", 
      apitoken: "gGQeMyeo8jM5xNGMsfChkwrawZ3UiX3QUnBnvwTe"
    },
    "publicserver.my.id": {
      zone: "b1b16801d28009e899a843b0c8faee34",
      apitoken: "y_0WKCNCnOgx0sgbcQr-puVTXyTQPN9KErR9vlzN"
    },
    "rexxaoffc.my.id": {
      zone: "f972ed410a833b28c8b5f166d6620d6a", 
      apitoken: "liq8sBPHwvbU2jWQYTCjo4BXafVPeopkAU4avUlP"
    },
    "rikionline.shop": {
      zone: "082ec80d7367d6d4f7c52600034ac635", 
      apitoken: "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
    },
    "storeid.my.id": {
      zone: "c651c828a01962eb3c530513c7ad7dcf",
      apitoken: "N-D6fN6la7jY0AnvbWn9FcU6ZHuDitmFXd-JF04g"
    },
    "varrtzy.xyz": {
      zone: "2d45a678eab00687ebcb1111beffaf2b",
      apitoken: "CQ4aK4fwUmH3RbM52vI5myFv-IxTIFTsguvRnGpi"
    },
    "panelzeroneoffc.my.id": {
      zone: "7d3d2d5ad350646779ba5341a441979d",
      apitoken: "d6454a29c1b0314f820a2fa8978f6b7a"
    },
    "panel-freefire.biz.id": {
        zone: "2d7adf23d5ea185bead30c8ad14e1907",
        apitoken: "le350OqR25wWm5SpSJpcTbalOaTOKJA3FcRV4ohK"
        },
    "apcb.biz.id": {
        zone: "01592fa9553ff4692ed443e5932ff285", 
        apitoken: "le350OqR25wWm5SpSJpcTbalOaTOKJA3FcRV4ohK"
    }, 
    "anti-ddos.me": {
        zone: "3f33f6c4b5a3dd00ed16d1eb7677338e", 
        apitoken: "le350OqR25wWm5SpSJpcTbalOaTOKJA3FcRV4ohK"
    },
    "dotco.biz.id": {
        zone: "a1e0d8b532189b712059cdfd9d927932", 
        apitoken: "dQ2NghSOMGpMh6JSyo0csVCHLf8UbckQ6StlV2Z2"
    }, 
    "dooxskull.shop": {
        zone: "f26d597c0024af18424b75db87b66a8f", 
        apitoken: "7ujiy5Acsu_K7_q_oxGz-QLPT5PqR9JUlJjh8ygl"
    },
    "bokepp.biz.id": {
        zone: "46b8cab5631c6c23c5ec4a7ef1f10803", 
        apitoken: "A8df8PxnKIcxLUTE7XS4TRZBoLslvt4XjJb1XEyi"
    }, 
    "gacorr.biz.id": {
        zone: "cff22ce1965394f1992c8dba4c3db539",
        apitoken: "v9kYfj5g2lcacvBaJHA_HRgNqBi9UlsVy0cm_EhT"
    },
    "cafee.my.id": {
        zone: "0d7044fc3e0d66189724952fa3b850ce", 
        apitoken: "wAOEzAfvb-L3vKYE2Xg8svJpHfNS_u2noWSReSzJ"
    }, 
    "vipstoree.my.id": {
        zone: "72fd03404485ddba1c753fc0bf47f0b3",
        apitoken: "J2_c07ypFEaen92RMS7irszQSrgZ_VFMfgNgzmp0"
    },
    "mafiapnel.my.id": {
        zone: "34e28e0546feabb87c023f456ef033bf", 
        apitoken: "bHNaEBwaVSdNklVFzPSkSegxOd9OtKzWtY7P9Zwt"
    },
    "centzzcloud.my.id": {
        zone: "749f1d7d69e9329195761b570010c00f", 
        apitoken: "9Su8A1EDXnt9-yGDb7YSGlY_ogJAw2vR9IDtpFrQ"
    },
    "chizyy.my.id": {
        zone: "057cbf622eed270982769d5557dcee59",
        apitoken: "BUg6UBu_68M1fG21nD6QzZkkpa9_Zp3hP54LsxX3"
    },
    "sevsbotz.xyz": {
        zone: "594ebd64574548c2cdda04f500059bf3",
        apitoken: "IDjXUZTsJejkc4hGIU3j-_7h7_i531MxOlb3drVf"
    },
    "privatesrvr.xyz": {
        zone: "b488e5d4635431243cab94d5fec4a3d2",
        apitoken: "Wv6SqCo8772I6WG-EGnD4w272sJsYVSXd-LpPc7C"
    },
    "cupenpendiem.shop": {
        zone: "a70c572f7c8f8bc0ad5ac2552e42e516", 
        apitoken: "VEtKD6sBAvgwQd1pYBV957Rno1feXoxqXPo1biij"
    }, 
    "publicserver.my.id": {
        zone: "b1b16801d28009e899a843b0c8faee34",
        apitoken: "y_0WKCNCnOgx0sgbcQr-puVTXyTQPN9KErR9vlzN"
    },
    "hostingers-vvip.my.id": {
        zone: "2341ae01634b852230b7521af26c261f", 
        apitoken: "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
    },
    "ekiofficial.my.id": {
        zone: "df33365b44b11cbe51570a7ed981cae5", 
        apitoken: "rMJGbyeuwFVZJifsB3rIX-nRpIOOa4Wkrhu7V5Jo"
    },
    "ekiofficial.web.id": {
        zone: "e1b037c00268cae95076b58f7f78b1f6", 
        apitoken: "EJO7mHrBORH9XoQrnUvBqotMYxNm5bjB5UO2PeQE"
    },
    "eki-panelpvrt.my.id": {
        zone: "6b4cb792b77b6118e91d8604253ca572", 
        apitoken: "DsftwwFCAKrbSo-9r9hxqcscMw8Xvx8gQzTXMSz4"
    },
    "hostingers-vvip.my.id": {
        zone: "2341ae01634b852230b7521af26c261f",
        apitoken: "Ztw1ouD8_lJf-QzRecgmijjsDJODFU4b-y697lPw"
    },
    "hostingnusantara.my.id": {
        zone: "156715abae5f34849a0f936753c986c8",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostpanel.biz.id": {
        zone: "76acbc398ab09c2bc0b179a7fa9ef488",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "hostsatoruu.biz.id": {
        zone: "30ea1aac05ca26dda61540e172f52ff4", 
        apitoken: "eZp1wNcc0Mj-btUQQ1cDIek2NZ6u1YW1Bxc2SB3z"
    },
    "jstpiwz.my.id": {
        zone: "f1901becfbd79f39048f7698de71d53b",
        apitoken: "g8_D70UKwk0hBeuPqdXgWmZcoNjwXMkfd3OEUL4k"
    },
    "jokowii.my.id": {
        zone: "67a887a21f43fea088a47902a436c400", 
        apitoken: "FwLKNhNL5LhI_LhAzH7pD-v6BrIcQ5dsdKRtaytS"
    },
    "kenz-host.my.id": {
        zone: "df24766ae8eeb04b330b71b5facde5f4",
        apitoken: "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
    },
    "lexcz.me": {
        zone: "7a4e7ca1131daf5a4c7ef03191432a6a",
        apitoken: "DTxnQFaoI9p2YtZUL7PLikauBvXcL_CWzpBbQx2b"
    },
    "lexczalok.xyz": {
        zone: "dd510b41fc4d7074c5be6f47f9f5b722",
        apitoken: "IsRLdOOP7OVrB95PUWaW_eq1n5T2T8OUcnwGhP_q"
    },
    "marketrikishop.my.id": {
        zone: "33970794e3373167a9c9556ad19fdb6a",
        apitoken: "TWf7dzMAu1dOc0XNuE98auJiSryxkUkQBbJpkwgr"
    },
    "pakvinsen.me": {
        zone: "3b8cb89265c0e026abaf3bc50ed57e76", 
        apitoken: "ttt0IHK50UKP2HltWUauuyDzkVPqnOEkx7M-5CFs"
    },
    "panelpro.fun": {
        zone: "a5c4697e86cf1cda49c0f81a699a690e",
        apitoken: "k-ZxmwqjyZf7iu4zNSJDTIx2tH6JZ--JQgfZReM9"
    },
    "panelpublic.biz.id": {
        zone: "92ed47fdfb94db589708b8057d44087f",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "prabowoo.my.id": {
        zone: "af679c959583e9eff1685ef4c7cbf048", 
        apitoken: "gGQeMyeo8jM5xNGMsfChkwrawZ3UiX3QUnBnvwTe"
    },
    "pterodactyl-panel.web.id": {
        zone: "d69feb7345d9e4dd5cfd7cce29e7d5b0",
        apitoken: "32zZwadzwc7qB4mzuDBJkk1xFyoQ2Grr27mAfJcB"
    },
    "pterodaytl.my.id": {
        zone: "828ef14600aaaa0b1ea881dd0e7972b2",
        apitoken: "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
    },
    "storedigital.web.id": {
        zone: "2ce8a2f880534806e2f463e3eec68d31",
        apitoken: "v5_unJTqruXV_x-5uj0dT5_Q4QAPThJbXzC2MmOQ"
    },
    "storeid.my.id": {
        zone: "c651c828a01962eb3c530513c7ad7dcf",
        apitoken: "N-D6fN6la7jY0AnvbWn9FcU6ZHuDitmFXd-JF04g"
    },
    "store-panell.my.id": {
        zone: "0189ecfadb9cf2c4a311c0a3ec8f0d5c", 
        apitoken: "eVI-BXIXNEQtBqLpdvuitAR5nXC2bLj6jw365JPZ"
    }, 
    "tamaoffc.biz.id": {
        zone: "177538af7fb12443a80892554d01206f",
        apitoken: "ZaVSjxa96NQDV6lQgspAVsVXrvVzdOpqL1z6PG0Z"
    },
    "tokopanelkishop.biz.id": {
        zone: "d87d4f320d9902f31fbbcc5ee23fafe8",
        apitoken: "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
    },
    "wannhosting.biz.id": {
        zone: "4e6fe33fb08c27d97389cad0246bfd9b",
        apitoken: "75HrVBzSVObD611RkuNS1ZKsL5A_b8kuiCs26-f9"
    },   
    "wannhosting.my.id": {
        zone: "0b36d11edd793b3f702e0591f0424339",
        apitoken: "OsSjhDZLdHImYTX8fdeiP1wocKwVnoPw5EiI85IF"
    }, 
    "webpanelku.my.id": {
        zone: "b41c3bb25273c4059b542c381250c9f9",
        apitoken: "GuT5rNQSr_V2kxb-QZdJ4YbFlEvzE-upzhey9Ezl"
    },
    "xnxxx.tech": {
        zone: "639f9cde20c22b1d2f33b2fee54f8f59",
        apitoken: "MtWI3a9-9Za-fGKmwl0uNznqM94eljKgobkF36h1"
    },
    "xyro.me": {
        zone: "a1c08ecd2f96516f2a85250b98850e8b", 
        apitoken: "f3IBOeIjRHYSsRhzxBO7yiwl-Twn3fqjmdkLdwlf"
    }, 
    "xyro.web.id": {
        zone: "46d0cd33a7966f0be5afdab04b63e695", 
        apitoken: "CygwSHXRSfZnsi1qZmyB8s4qHC12jX_RR4mTpm62"
    }, 
    "xyroku.my.id": {
        zone: "f6d1a73a272e6e770a232c39979d5139", 
        apitoken: "0Mae_Rtx1ixGYenzFcNG9bbPd-rWjoRwqN2tvNzo"
    }, 
    "xpanelprivate.my.id": {
        zone: "f6bd04c23d4de3ec6d60d8eeabe1ff40", 
        apitoken: "su_zz3Amd5WkrOv95OA6uQb1Y6ky6qVtjkhQnPCi"
    },
    "zainhosting.my.id": {
        zone: "c3eeb2afb2e4073fe4c55ad7145395e9", 
        apitoken: "RNlg5vrTwt73uAPTYAad_nJzBmDhhjbUZKiWFORZ"
    },
    "zhirastoreid.me": {
        zone: "fc6c7f786d01a0c7558a313549134a06", 
        apitoken: "STOIGXwGftk-OjdgCbqpCDaBWCYUpo5RgvmJ-rXe"
    },
    "zyydev.my.id": {
        zone: "337aaf9a6689c7a7145480ef3ccaffdb",
        apitoken: "jnNO465SjNC-Ss6CDM2WDIy7jwzbKWHJuOXA5xak"
    },
    "loveme.my.id": {
        zone: "91d8ac3650cf245d3119a4f32dbfe03d",
        apitoken: "Pnx3iE-AInXIyK2Ntxnsi149j6qdQ9YGMdca_j9b"
    }
  }
};
